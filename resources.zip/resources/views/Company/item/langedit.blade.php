@extends('Admin.layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('assets/vendors/iconfonts/font-awesome/css/font-awesome.min.css')}}">

@endsection
@section('content')
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">@lang('lang.Add')</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">@lang('admin.home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">

                        </li>
                    </ol>
                </div>
            </div>


            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">

                            <div class="modal-body">
                                @if(session('okeys'))
                                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">ХЂХЎХЅХїХЎХїХѕХҐЦЃ Х±ХҐЦЂ ХЎХѕХҐХ¬ХЎЦЃХёЦ‚ХґХЁ</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">Г—</span></div></div>
                                @endif<ul class="navbar-nav d-none d-md-block">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" id="LanguageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                                            <i class="flag-icon flag-icon-@if($lang=='en')us @else{{$lang}}@endif"></i>
                                            @if($lang=='am')
                               Armenia
                                            @elseif($lang=='ru')
                                       Russia
                                            @elseif($lang=='en')
                                     English
                                            @endif
                                        </a>
                                        <form action="{{route('itemslang',$product->product_id)}}" method="post">
                                            @csrf
                                        <div class="dropdown-menu navbar-dropdown pb-0" aria-labelledby="LanguageDropdown">

                                            <a class="dropdown-item preview-item px-3 py-0">
                                                <div class="preview-thumbnail">
                                                    <div class="preview-icon">
                                                        <i class="flag-icon flag-icon-am"></i>
                                                    </div>
                                                </div>
                                                <div class="preview-item-content">
                                                    <button type="submit" name="lang" value="am" class="font-weight-light mb-0 small-text">
                                                     Armenia
                                                    </button>
                                                </div>
                                            </a>
                                            <a class="dropdown-item preview-item px-3 py-0">
                                                <div class="preview-thumbnail">
                                                    <div class="preview-icon">
                                                        <i class="flag-icon flag-icon-ru"></i>
                                                    </div>
                                                </div>
                                                <div class="preview-item-content">
                                                    <button type="submit" name="lang" value="ru" class="font-weight-light mb-0 small-text">
                                                     Russia
                                                    </button>
                                                </div>
                                            </a>
                                            <a class="dropdown-item preview-item px-3 py-0">
                                                <div class="preview-thumbnail">
                                                    <div class="preview-icon">
                                                        <i class="flag-icon flag-icon-us"></i>
                                                    </div>
                                                </div>
                                                <div class="preview-item-content">
                                                    <button type="submit" name="lang" value="en" class="font-weight-light mb-0 small-text">
                                                    English
                                                    </button>
                                                </div>
                                            </a>
                                        </div>
                                        </form>
                                    </li>
                                </ul>
                                <form action="{{route('langcreate')}}" method="post">
                                    @csrf
@method('post')
                                    <div class="form-group {{ $errors->has('title') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.title')</label>
                                        <input type="text" name="title"  value="" class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                        @error('title')
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
                                                    </p>
                                            </span>
                                        @enderror
                                    </div>

                                    <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.description')</label>

                                        <textarea rows="4" name="description" class="form-control" id="basic-textarea"></textarea>
                                        @error('description')
                                        <br>
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
                                                    </p>
                                                </span>
                                        @enderror
                                    </div>


                                    <input type="hidden" name="lang" value="{{$lang}}">
                                    <input type="hidden" name="product_id" value="{{$product->product_id}}">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i>@lang('lang.change')</button>
                                    </div>
                                            </form>
                            </div>
                        </div>
                    </div>
                </div>






            </div>
        </div>
    </div>




@endsection
@section('js')

    <script src="{{asset('assets/js/form-addons.js')}}"></script>



@endsection
