        @extends('Company.item.layouts.app')
        @section('css')
            <link rel="stylesheet" href="{{asset('assets/vendors/iconfonts/font-awesome/css/font-awesome.min.css')}}">

        @endsection
        @section('content')

            <div class="col-md-9">
                <div class="row pt-2 pb-2">
                    <div class="col-sm-9">
                        <h4 class="page-title">@lang('lang.Add')</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('companyindex')}}">@lang('admin.home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">

                            </li>
                        </ol>
                    </div>
                </div>


                <div class="row left-section">
                    <div class="col-lg-12">
                        <div class="card">

                                        <form action="{{route('Production.update',$product->product_id)}}" method="post"
                                              enctype="multipart/form-data">

                                            @csrf
                                            @method('PUt')
                                            @error('food_menu_id')
                                            <br>
                                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել ընտրել  դաշտը.
        </p>
        </span>
                                            @enderror

                                            <select class="menu" name="section_id">
                                                <option hidden value="{{$product->sections_id}}">{{$product->name_am}}</option>
                                                @foreach($sectionmain as $sectionmenu)
                                                    <option
                                                        value="{{$sectionmenu->sections_id??null}}">{{$sectionmenu->name_am??null}}</option>
                                                @endforeach
                                            </select>

                                            <select class="listmenuchek" name="food_menu_id">
                                                <option hidden selected
                                                        value="{{$product->food_menu_id}}">{{$product->food_name_am}}</option>
                                            </select>

                                            <select name="status">

                                                <option value="{{$productstatus->status}}"
                                                        hidden>{{$productstatus->status}}</option>
                                                <option value="active">Active</option>
                                                <option value="inactive">Inactive</option>
                                            </select>

                                            <input type="hidden" name="lang" value="{{$product->lang}}">
                                            <div class="form-group {{ $errors->has('alians') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('admin.alians')</label>
                                                <input type="text" name="alians" value="{{$product->alians}}"
                                                       class="form-control" id="input-1" placeholder="@lang('admin.alians')">

                                            </div>
                                            <div class="form-group {{ $errors->has('title_am') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('lang.title') Armenia</label>
                                                <input type="text" name="title_am" value="{{$product->title_am}}"
                                                       class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                                @error('title')
                                                <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
        </p>
        </span>
                                                @enderror
                                            </div>
                                            <div class="form-group {{ $errors->has('title_ru') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('lang.title') Russia</label>
                                                <input type="text" name="title_ru" value="{{$product->title_ru}}"
                                                       class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                                @error('title')
                                                <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
        </p>
        </span>
                                                @enderror
                                            </div>
                                            <div class="form-group {{ $errors->has('title_en') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('lang.title') English</label>
                                                <input type="text" name="title_en" value="{{$product->title_en}}"
                                                       class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                                @error('title')
                                                <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
        </p>
        </span>
                                                @enderror
                                            </div>

                                            <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('lang.description') Armenia</label>

                                                <textarea rows="4" name="description_am" class="form-control"
                                                          id="basic-textarea">{{$product->description_am}}</textarea>
                                                @error('description')
                                                <br>
                                                <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
        </p>
        </span>
                                                @enderror
                                            </div>
                                            <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('lang.description') Russia</label>

                                                <textarea rows="4" name="description_ru" class="form-control"
                                                          id="basic-textarea">{{$product->description_ru}}</textarea>
                                                @error('description')
                                                <br>
                                                <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
        </p>
        </span>
                                                @enderror
                                            </div>
                                            <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                                                <label for="input-1">@lang('lang.description') English</label>

                                                <textarea rows="4" name="description_en" class="form-control"
                                                          id="basic-textarea">{{$product->description_en}}</textarea>
                                                @error('description')
                                                <br>
                                                <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
        </p>
        </span>
                                                @enderror
                                            </div>


                                            <div class="form-group">
                                                <label for="input-1">price new</label>
                                                <input type="number" name="price_new" class="form-control"
                                                       value="{{$product->price_new}}" id="input-1"
                                                       placeholder="@lang('lang.price')">
                                            </div>
                                            <div class="col-6">
                                                <label for="input-1">Old % price</label>

                                                <input type="number" name="price_old" class="form-control"
                                                       value="{{$product->price_old}}" id="input-1"
                                                       placeholder="@lang('lang.price') Old Price Դ">
                                            </div>


                                            <div class="form-group">
                                                <label>Images</label>
                                                <input class="form-control" type="file" name="images">
                                            </div>
                                            <input type="hidden" name="product_id" value="{{$product->product_id}}">

                                            <div class="form-group">
                                                <img src="{{asset('myproduct/'.$product->images)}}" alt=""></div>

                                            <div class="form-group">

                                                <label>Ավելացնել Ավելի շատ նկարներ</label>
                                                <input class="form-control" type="file" name="image[]" multiple>
                                            </div>

                                            <input type="hidden" name="product_id" value="{{$product->product_id}}">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i>Հաստատել
                                                </button>
                                            </div>

                                        </form>
                                        <div class="row">
                                            @foreach($images as $imagess)
                                                <div class="col-3">
                                                    <img src="{{asset('myproduct/'.$imagess->image)}}" style="width: 120px;"
                                                         alt="">

                                                    <form action="{{route('imgdelete',$imagess->id)}}" method="post">
                                                        @csrf
                                                        <button type="submit" class="btn" style="width: 5px;">X</button>
                                                    </form>
                                                </div>
                                            @endforeach
                                        </div>
                        </div>
                    </div>
                </div>
            </div>










        @endsection
        @section('js')


       
                <script>
                    $(document).ready(function () {
                        $('.menu').change(function () {
                            var id = $(this).val();

                            $.ajax({
                                type: 'get',
                                url: '{{url('My/Menu/Select/')}}/' + id,
                                data: '_token = <?php echo csrf_token() ?>',
                                dataType: 'html',
                                contentType: false,
                                processData: false,

                                success: function (data) {
                                    $(".listmenuchek").html(data);
                                }
                            });


                        });

                    });

                </script>


        @endsection
        �������������������������������������
