@include('Admin.include.header')
<style>
    .inputborder{
        border: 1px solid black;
    }
</style>

    <!-- Side Menu Area -->


    <!-- Layout Container -->


        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('companyindex')}}">Գլխավոր</a></li>
                        <li class="breadcrumb-item"><a href="{{route('Production.index')}}">Ապրանքատեսակ</a></li>

                    </ol>
                </nav>
            </div>
        </div>

        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="inbox--area bg-boxshadow mb-50">
                            <div class="row">
                                <div class="col-12 col-lg-3">
                                    <div class="ibox mb-50">
                                        <div class="ibox-content mailbox-content">

                                            <a class="btn btn-block btn-primary compose-mail" href="{{route('Production.create')}}">Ավելացնել Ապրանքատեսակ</a>

                                            <br>
                                            <br>

                                                <li type="none"><a href="{{route('Production.index')}}"> <i class="fa fa-reply-all "></i> Բոլոր ապրանքները </a></li>


                                        <!-- Title -->
                                            <div class="categori-title mt-30">
                                                <h6>Մենյու</h6>
                                            </div>
                                            <!-- List -->

                                            @if(isset($category)!=null)

                                            <ul class="category-list" style="padding: 0">
                                                @foreach($category as $categories)

                                                        <li><a href="{{route('filterfindmenu',$categories->id)}}"> <i class="fa fa-circle text-danger"></i>{{$categories->food_name_am}}</a></li>


                                                @endforeach
                                            </ul>
                                            @endif
                                            <div class="clearfix"></div>


                                        </div>
                                    </div>
                                </div>
  <div class="col-9 col-lg-9">
                                @yield('content')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



@include('Admin.include.footer')
