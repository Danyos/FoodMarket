@extends('Company.item.layouts.app')

@section('content')



                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif
                <div class="card-body">
                    <h4 class="card-title">Ապրանքատեսակներ</h4>
                    <div class="row">
                        <div class="col-11 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>վերնագիր</th>
                                    <th><summary>Ինֆորմացիա</summary></th>
                                    <th>Լուսանկար</th>
                                    <th>Փոփոխել || Դիտել || Ջնջել</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($product as $products)
                                    @if(auth()->user()->rolle!='company')
                                    <form action="{{route('Items.destroy',$products->product_id)}}" method="post" style="display: none">
                                      @else
                                            <form id="destroyform" action="{{route('Production.destroy',$products->product_id)}}" method="post" style="display: none">
                                          @endif
                                        @method('DELETE')
                                        @csrf
                                        <button type="button" class="pdoductdestroybutton badge-dark badge-info" id="del{{$products->product_id}}" style="display: none;" >
                                          </button>
                                    </form>
                                <tr>

                                    <td>{{$products->product_id}}</td>

                                    <td>

                                        <details>
                                                <summary>{{$products->title_am}}</summary>
                                                <p>{{$products->title_ru}}</p>
                                                <p>{{$products->title_en}}</p>

                                        </details>


                                    </td>


                                    <?php $MenuFood=\App\Models\MenuFood::find($products->food_menu_id) ?>
                                    <?php $FoodMarket=\App\Models\FoodMarket::find($products->food_market_id) ?>
                                    <?php $list_menus=\App\Models\Section::where('sections_id',$products->section_id)->first() ?>


                                    <td> <details>
                                        <summary>  {{$list_menus->name_am??' '}}</summary>
                                        <p>  <br><br>
                                                                                        {{$FoodMarket->{'market_name_'.session('locale')}??null }} || <br><br>
                                           {{$MenuFood->{'food_name_'.session('locale')}??null }}  || <br><br>
                                            {{$products->price}} || <br><br>
                                            {{$products->phone}}</p>

                                    </details>

                                    </td>

                                    <td><img src="{{asset('myproduct/'.$products->images)}}" style="width: 80px;" alt=""></td>
                                    <td>

                                        @if($products->product_id)
                                        <label class="badge badge-info" onclick="location.href='{{route('Production.edit',$products->product_id)}}'">Փոփոխել</label>
                                            <label class="badge badge-info" onclick="location.href='{{route('Production.show',$products->product_id)}}'">Դիտել</label>
                                        @endif
                                        <label class="badge badge-info" for="del{{$products->product_id}}">Ջնջել</label>
                                    </td>

                                </tr>
                                    @endforeach

                                </tbody>
                            </table>
                        </div>
                    </div>
                    {{$product->links()}}
                </div>


    @endsection
@section('js')
<script>
    $('.pdoductdestroybutton').click(function(){

        var r = confirm("Ջնջե՞լ ապրանքը");
        if (r == true) {
            $(this).attr('type','submit');
        } else {
        }
    })
</script>
    @endsection
