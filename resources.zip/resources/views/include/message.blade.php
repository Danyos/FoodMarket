@if(session('country'))
    <div class="info-show-panel">
        <div class="show-window">
            <div class="info">
                <h5 class="text-center">Վճարման արդյունքը</h5>
                <hr>
                <div class="alert alert-danger" role="alert">
                    Լրացրեք տարածաշրջանը!
                </div>
                <p class="">

                    <button onclick="hideAlert(this)" data-window=".info-show-panel" class="btn btn-danger closeBtn">Close</button>
                </p>
            </div>
        </div>
    </div>
@endif
@if(session('succses'))
    <div class="info-show-panel">
        <div class="show-window">
            <div class="info">

                <div class="alert alert-success" role="alert">
                    Ուղարկվեց ձեր հայտը
                </div>
                <div class="mb-15"></div>
                <p class="">
                    <button onclick="hideAlert(this)" data-window=".info-show-panel" class="btn btn-danger closeBtn">Close</button>
                </p>
            </div>
        </div>
    </div>
@endif

@if($errors->has('title') or $errors->has('tel') or $errors->has('msg')  or $errors->has('chek'))
    <div class="info-show-panel">
        <div class="show-window">
            <div class="info">
                <h5 class="text-center">Վճարման արդյունքը</h5>
                <hr>
                <div class="" role="alert">
                    @error('msg')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք Նկարագրության դաշտը!
                    </div>
                    @enderror
                    @error('tel')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր հեռախոսահամրի դաշտը!
                    </div>
                    @enderror
                    @error('title')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր անվան դաշտը!
                    </div>
                    @enderror
                    @error('chek')
                    <div class="alert alert-danger" role="alert">
                        Ջեր դիմումը չհաստատվեց
                    </div>
                    @enderror

                </div>
                <p class="">

                    <button onclick="hideAlert(this)" data-window=".info-show-panel" class="btn btn-danger closeBtn">Close</button>
                </p>
            </div>
        </div>
    </div>
@endif

@if($errors->has('own_name') or $errors->has('own_home') or $errors->has('own_street')  or $errors->has('own_phone')or $errors->has('country'))
    <div class="info-show-panel">
        <div class="show-window">
            <div class="info">
                <h5 class="text-center">Վճարման արդյունքը</h5>
                <hr>
                <div class="alert alert-danger" role="alert">
                    @error('own_name')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր անվան դաշտը!
                    </div>
                    @enderror
                    @error('own_home')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր տան դաշտը!
                    </div>
                    @enderror
                    @error('own_street')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր փողոցի դաշտը!
                    </div>
                    @enderror
                    @error('own_phone')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր հեռախոսահամրի դաշտը!
                    </div>
                    @enderror
                    @error('country')
                    <div class="alert alert-danger" role="alert">
                        Լրացրեք ձեր հեռախոսահամրի դաշտը!
                    </div>
                    @enderror

                </div>
                <p class="">

                    <button onclick="hideAlert(this)" data-window=".info-show-panel" class="btn btn-danger closeBtn">Close</button>
                </p>
            </div>
        </div>
    </div>
@endif

@if (session()->has('success'))
    <div CLASS="info-show-panel">
        <div class="show-window">
            <div class="info">
                <h5 class="text-center">Վճարման արդյունքը</h5>
                <hr>
                <div class="alert alert-success" role="alert">
                    Մենք շուտով կկապվենք ձեր հետ․․․
                </div>
                <div class="alert alert-success" role="alert">
                    Շնորհակալություն պատվերի համար։
                </div>
                <p class="">
                    <button class="btn btn-success backBtn" onclick="location.href='{{route('index')}}'">Վերադառնալ գլխավոր էջ</button>
                </p>
            </div>
        </div>
    </div>

@endif

@if ($errors->has('email'))
    <div id="ll" class="modal fade show" aria-modal="true" style="padding-right: 9px; display: block;">
        <div class="modal-dialog reg-dialog" role="document" >
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <!-- REGISTRATION FORM -->

                        <div class="text-center" style="padding:20px 0">
                            <div class="logo"><i class="fa fa-user logregIcon" aria-hidden="true"></i>&nbsp;@lang('lang.logıns')</div>
                            @if ($errors->has('email'))
                                <div class="alert alert-warning">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </div>
                            @endif
                            <div class="login-form-1">
                                <form id="login-form" class="text-left"  role="form" method="POST" action="{{ route('login') }}">
                                    {{ csrf_field() }}
                                    <div class="login-form-main-message" style="margin: 0;"></div>
                                    <div class="main-login-form">
                                        <div class="login-group">
                                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                                <label for="lg_username" class="sr-only">@lang('lang.email')</label>
                                                <input type="text" class="form-control" id="lg_username" name="email" value="{{ old('email') }}" placeholder="@lang('lang.email')">
                                            </div>
                                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} ">
                                                <label for="lg_password" class="sr-only">@lang('lang.password')</label>
                                                <input type="password" class="form-control" id="lg_password"  name="password"  placeholder="@lang('lang.password')">
                                                @if ($errors->has('password'))
                                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                                @endif
                                            </div>
                                            <div class="form-group login-group-checkbox">
                                                <input type="checkbox" id="lg_remember" name="remember" {{ old('remember') ? 'checked' : '' }}>
                                                <label for="lg_remember">@lang('lang.remember')</label>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>


                                    <div class="etc-login-form">
                                        <p><a href="{{ route('password.request') }}">@lang('lang.ForgotYourPassword')</a></p>
                                        <p><a class="btn btn-link" id="regInSig" data-toggle="modal" data-target="#ModalRegistrationForm">@lang('lang.newaccount')</a></p>
                                    </div>
                                </form> </div>
                            <!-- end:Main Form -->
                        </div>
                        <!-- end:Main Form -->
                    </div>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->

@endif

@if(session()->has('error'))
    <div id="ll" class="modal fade show" aria-modal="true" style="padding-right: 9px; display: block;">
        <div class="modal-dialog reg-dialog" role="document" >
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <!-- REGISTRATION FORM -->

                        <div class="text-center" style="padding:20px 0">
                            <div class="logo"><i class="fa fa-user logregIcon" aria-hidden="true"></i>&nbsp;@lang('lang.logıns')</div>
                            @if(session()->has('error'))
                                <div class="alert alert-danger">
                                    {{ session()->get('error') }}
                                </div>
                            @endif

                            <div class="login-form-1">
                                <form id="login-form" class="text-left"  role="form" method="POST" action="{{ route('login') }}">
                                    {{ csrf_field() }}
                                    <div class="login-form-main-message" style="margin: 0;"></div>
                                    <div class="main-login-form">
                                        <div class="login-group">
                                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                                <label for="lg_username" class="sr-only">@lang('lang.email')</label>
                                                <input type="text" class="form-control" id="lg_username" name="email" value="{{ old('email') }}" placeholder="@lang('lang.email')">
                                            </div>
                                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} ">
                                                <label for="lg_password" class="sr-only">@lang('lang.password')</label>
                                                <input type="password" class="form-control" id="lg_password"  name="password"  placeholder="@lang('lang.password')">
                                                @if ($errors->has('password'))
                                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                                @endif
                                            </div>
                                            <div class="form-group login-group-checkbox">
                                                <input type="checkbox" id="lg_remember" name="remember" {{ old('remember') ? 'checked' : '' }}>
                                                <label for="lg_remember">@lang('lang.remember')</label>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>


                                    <div class="etc-login-form">
                                        <p><a href="{{ route('password.request') }}">@lang('lang.ForgotYourPassword')</a></p>
                                        <p><a class="btn btn-link" id="regInSig" data-toggle="modal" data-target="#ModalRegistrationForm">@lang('lang.newaccount')</a></p>
                                    </div>
                                </form> </div>
                            <!-- end:Main Form -->
                        </div>
                        <!-- end:Main Form -->
                    </div>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
@endif

@if(session()->has('successs'))
    <div id="ll" class="modal fade show" aria-modal="true" style="padding-right: 9px; display: block;">
        <div class="modal-dialog reg-dialog" role="document" >
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">×</button>

                            <div class="logo"><i class="fa fa-user logregIcon" aria-hidden="true"></i>&nbsp;@lang('lang.logıns')</div>
                            @if(session()->has('success'))
                                <div class="alert alert-success">
                                    {{ session()->get('success') }}
                                </div>
                            @endif
                            <div class="login-form-1">
                                <form id="login-form" class="text-left"  role="form" method="POST" action="{{ route('login') }}">
                                    {{ csrf_field() }}
                                    <div class="login-form-main-message" style="margin: 0;"></div>
                                    <div class="main-login-form">
                                        <div class="login-group">
                                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                                <label for="lg_username" class="sr-only">@lang('lang.email')</label>
                                                <input type="text" class="form-control" id="lg_username" name="email" value="{{ old('email') }}" placeholder="@lang('lang.email')">
                                            </div>
                                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} ">
                                                <label for="lg_password" class="sr-only">@lang('lang.password')</label>
                                                <input type="password" class="form-control" id="lg_password"  name="password"  placeholder="@lang('lang.password')">
                                                @if ($errors->has('password'))
                                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                                @endif
                                            </div>
                                            <div class="form-group login-group-checkbox">
                                                <input type="checkbox" id="lg_remember" name="remember" {{ old('remember') ? 'checked' : '' }}>
                                                <label for="lg_remember">@lang('lang.remember')</label>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>


                                    <div class="etc-login-form">
                                        <p><a href="{{ route('password.request') }}">@lang('lang.ForgotYourPassword')</a></p>
                                        <p><a class="btn btn-link" id="regInSig" data-toggle="modal" data-target="#ModalRegistrationForm">@lang('lang.newaccount')</a></p>
                                    </div>
                                </form> </div>
                            <!-- end:Main Form -->
                        </div>
                        <!-- end:Main Form -->
                    </div>
                </div>
            </div><!-- /.modal-content -->

@endif
