



    <script>
        $.ajax({
            type:'get',
            url:'{{url('buyshop/count')}}',
            data:'_token = <?php echo csrf_token() ?>',
            dataType : 'html',
            contentType: false,
            processData: false,

            success:function(data) {
                $(".mydish").html(data);
            }
        });
    </script>



