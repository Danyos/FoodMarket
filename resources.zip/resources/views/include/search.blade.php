<form action="{{ route('searchcolums')}}"  method="post" >
    @csrf
    <div class="search-forms">
        <input type="search" class="form-control rest-search" name="search" placeholder=" @lang('lang.search')">
        <button title="Search" type="submit" class="btn-info rest-search-btn"><i class="fa fa-search" aria-hidden="true"></i></button>
    </div>
</form>
