
    <div id="accordion" class="accordion">
        <div class="search-resr">
            @include('include.search')
        </div>
        <div class="card mb-0">
@if($list!=null)
            @foreach($list as $listmils)
                <div class="card-header collapsed" data-toggle="collapse" href="#men{{mb_substr($listmils->name_en, 0, 3)}}{{$listmils->sections_id}}">
                    <a class="card-title">
                        {{$listmils->{'name_'.session('locale')} }}
                    </a>
                </div>
                <hr style="width: 90%;margin: 0 auto;">



                <div id="men{{mb_substr($listmils->name_en, 0, 3)}}{{$listmils->sections_id}}" class="card-body collapse" data-parent="#accordion" >
                    <ul class="navbar-nav subList">

                        <?php $men=\App\MenuFood::where('section_id',$listmils->sections_id)->get()?>

                        @foreach($men as $main)


                            <li class="nav-item subList-item"><a class="lmenhov" href="{{url('/Restaurant/'.$file->menu_market_id.'/section/'.$main->id)}}">
                                    {{$main->{'food_name_'.session('locale')} }}</a></li>

                        @endforeach
                    </ul>
                </div>


            @endforeach
@endif

        </div>
    </div>
