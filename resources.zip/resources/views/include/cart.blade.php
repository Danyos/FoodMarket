<?php
$cart=\Cart::getContent();
?>
<aside>
<?php $total=\Cart::getSubTotal();
$shiptotal=0;
if(\Illuminate\Support\Facades\Session::has('sessioncounrtyid')){
    $updatesitems = \Cart::getContent()->all();
    $arrmarketid=[];
    $arrmarketprice=[];

    foreach( $updatesitems as  $updatesitem) {
        $countequal=0;

        $product = \App\Models\Product::rightJoin('langs', 'products.id', '=', 'langs.product_id')->where('product_id', $updatesitem)->first();
        for($i=0;$i<count($arrmarketid);$i++){
            if($product->food_market_id == intval($arrmarketid[$i]))
            {
                $countequal+=1;
            }
        }
        if($countequal==0){
            array_push($arrmarketid,$product->food_market_id);
            array_push($arrmarketprice,$updatesitem->attributes->marketprice);}
        //

    }

    for($i=0;$i<count($arrmarketprice);$i++){
        $total+=intval($arrmarketprice[$i]) ;
        $shiptotal+=intval($arrmarketprice[$i]) ;
    }

}

?>

<!-- Cart submit form -->
    <form action="{{route('Chekvalidate')}}" method="POST" >
        @csrf
        <div class="checkout-section">
            <p class="text-left"><i style="color: #E9294A;border: 1px solid #E9294A;border-radius:50%;padding: 2px 7px;" class="fa fa-info" aria-hidden="true"></i>&nbsp;Կարմիրով նշված դաշտերը պարտադիր լրացման ենթակա են</p>
            <div id="chekout">

                <input style="border: 1px solid red;" type="text" id="name" name="own_name" value="{{old('own_name')}}" class="form-control myInpMar" placeholder="@lang('lang.name') @lang('lang.surname')" required="required">
                <?php $countriesprice = \App\Models\CountryPrice::get();?>
                <?php $currency=\App\Models\Currency::where('id','1')->first();?>

                <select class="form-control"  style="display: none"  id="secid" form="catform">

                    @foreach($countriesprice as $countryprice)
                        @if(\Illuminate\Support\Facades\Session::has('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                            @if(session('pricetype')=='USD')
                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                @elseif(session('pricetype')=='RUB')
                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                           @else
                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo intval($countryprice->price);?></option>

                            @endif
                        @else
                                @if(session('pricetype')=='USD')

                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                            @elseif(session('pricetype')=='RUB')
                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                            @else
                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo intval($countryprice->price);?></option>


                            @endif @endif

                    @endforeach

                </select>
                <select class="form-control myInpMar" style="border: 1px solid red;" id="catid" form="catform">


                    <option value="0" class="nullcountry">Ընտրեք տարածաշրջանը</option>

                    <?php $countries = \App\Models\Country::get();?>
                    @foreach($countries as $country)
                        @if(\Illuminate\Support\Facades\Session::has('sessioncounrtyid')&& session('sessioncounrtyid')==$country->id)

                            <option value="{{$country->id}}" class="{{$country->id}}" selected>{{$country->{'country_'.session('locale')} }} </option>
                        @else
                            <option value="{{$country->id}}" class="{{$country->id}}" >{{$country->{'country_'.session('locale')} }} </option>
                        @endif
                    @endforeach

                </select>
                <?php $countriesprice = \App\Models\CountryPrice::where('country_id',session('sessioncounrtyid'))->get();?>
                @if(session('sessioncountrysecid')!=null)


                    <select class="form-control" style="display: block" name="catid" id="township" form="catform">
                        @else
                            <select class="form-control" style="display: none;border: 1px solid red;" name="catid" id="township" form="catform">
                                @endif


                                @foreach($countriesprice as $countryprice)
                                    @if(session('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                                        @if(session('pricetype')=='USD')
                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                        @elseif(session('pricetype')=='RUB')
                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                        @else
                                            <option data-itemsecid="{{$countryprice->id}}"  value="{{$countryprice->price}} " class="{{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-{{$countryprice->price}}</option>

                                        @endif
                                    @else
                                        @if(session('pricetype')=='USD')
                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                        @elseif(session('pricetype')=='RUB')
                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                        @else
                                            <option data-itemsecid="{{$countryprice->id}}"  value="{{$countryprice->price}} " class="{{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-{{$countryprice->price}}</option>

                                        @endif
                                    @endif

                                @endforeach

                            </select>
                <input type="text" id="mail" name="own_email"  class="form-control myInpMar" placeholder="@lang('lang.email')">
                <input style="border: 1px solid red;" type="text" id="street" value="{{old('own_street')}}" name="own_street" class="form-control myInpMar" placeholder="Փողոց" required="required">
                <input style="border: 1px solid red;" type="number" id="phone" value="{{old('own_phone')}}" name="own_phone" class="form-control myInpMar" placeholder="+37400000000" required="required">
                <div style="display: flex" class="myInpMar">
                    <input type="text" id="home" name="own_enter" class="form-control" placeholder="@lang('lang.logıns')" >&nbsp;
                    <input type="number" id="home" name="own_floor" value="{{old('own_floor')}}"  class="form-control" placeholder="Հարկ">&nbsp;
                    <input style="border: 1px solid red;" type="text" id="home" name="own_home" class="form-control" placeholder="Բնակարան" required="required">
                </div>

            </div>

        </div>

        <div class=" addcartupade">
            <div class="list-group sc-cart-item-list  ">

                @foreach($cart as $cartget)

                    <div class="sc-cart-item list-group-item remow{{$cartget->id}} celeare">
                        <button type="button" class="sc-cart-remove" data-removid="{{$cartget->id}}">×</button>
                        <img class="img-responsive pull-left" src="{{asset('myproduct/'.$cartget->attributes->images)}}">
                        <h4 class="list-group-item-heading">
                            {{$cartget->id}}    {{$cartget->name}}
                        </h4><p class="list-group-item-text"></p>
                        {{--                                               {{$cartget->attributes->delivery}}--}}
                        @if(session('sessioncounrtyid')!=null)

                            <div style="display: block" class="marketpriceonediv">
                                Առաքում  + <span data-updateidpricea="{{$cartget->id}}" class="marketpriceone pricechangetype">{{$cartget->attributes->marketprice}}</span><span class="currency">@lang('lang.amd')</span>
                            </div>
                        @else
                            <div style="display: none" class="marketpriceonediv">

                                Առաքում  + <span data-updateidpricea="{{$cartget->id}}" class="marketpriceone pricechangetype">{{$cartget->attributes->marketprice}}</span><span class="currency">@lang('lang.amd')</span>
                            </div>
                        @endif
                        <div class="sc-cart-item-summary"><span class="sc-cart-item-price"><span class="currency">AMD</span>&nbsp;<span class="pricechangetype">{{$cartget->price}} </span></span>

                            <input type="number" min="1" data-updateid="{{$cartget->id}}" max="1000" class="sc-cart-item-qty" value="{{$cartget->quantity}}">

                            <div class="sc-cart-item-amount summedPrice{{$cartget->id}}"><span class="currency">AMD</span> &nbsp;<span class="pricechangetype">{{$cartget->price*$cartget->quantity}}</span></div>




                            @if($cartget->attributes->descriptionproduct=="")

                                <span class="addproductdesc addproductdesc{{$cartget->id}}" > <a class="add"  title="Add" class="adddescription" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a></span>
                                <span class="editproductdesc editproductdesc{{$cartget->id}}" style="display: none" >  <a class="edit"  title="Edit"  data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a></span>
                                <span class="removeproductdesc removeproductdesc{{$cartget->id}}" style="display: none">  <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a></span>
                                <input type="hidden" class="editproductdescinput"  value="{{$cartget->id}}">
                                <br>
                                <textarea  class="main-sc-cart-item-qty descprod" style="width: 435px;display: none" name="description" style="width: 435px;" ></textarea>
                            @else
                                <span class="addproductdesc addproductdesc{{$cartget->id}}" style="display: none"> <a class="add"  title="Add" class="adddescription" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a></span>
                                <span class="editproductdesc editproductdesc{{$cartget->id}}" >  <a class="edit"  title="Edit"  data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a></span>
                                <span class="removeproductdesc removeproductdesc{{$cartget->id}}">  <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a></span>
                                <input type="hidden" class="editproductdescinput"  value="{{$cartget->id}}">
                                <br>
                                <textarea  class="main-sc-cart-item-qty descprod" style="width: 435px;display: none" name="description" style="width: 435px;" ></textarea>    <!--  <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a>-->
                            @endif
                            <div class="descriptionproductdiv{{$cartget->id}}">{{$cartget->attributes->descriptionproduct}}</div>



                        </div>
                    </div>

                    <input type="hidden" name="EDP_BILL_NO" value="{{rand(100,9999)}}">
                    <input type="hidden" name="qty" value="{{$cartget->quantity}}" class="priceitem">
                    <input type="hidden" name="EDP_price" value=" {{$cartget->price}}" class="inputprice">

                @endforeach
            </div>


            <input type="hidden" name="EDP_AMOUNT" value=" {{$total}}" class="inputtotal">



        </div>
        <div id="smartcart" class="total ">
            <div class="pull-left "><span>Առաքում։ </span><span class="shiptotal pricechangetype">{{$shiptotal}}</span><span class="currency">&nbsp;@lang('lang.amd')</span></div>
            <div class="pull-right"><span class=" price_total pricechangetype">{{$total}}</span><span class="currency">&nbsp;@lang('lang.amd')</span></div>
        </div>

        <p>
            <img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">
            <img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="IDram" title="IDram" src ="{{asset('asset/IMAGE/id.png')}}">
            <img style="width: 25px;" alt="Cash" title="Cash" src ="{{asset('asset/IMAGE/md.png')}}">
        </p>

        <br>
        <div class="sc-cart-toolbar">
            <button class="btn btn-info sc-cart-checkout" type="button">Պատվիրել</button>
            <button class="btn btn-danger sc-cart-clear" type="button">Չեղարկել</button>
        </div>

    </form>
</aside>


