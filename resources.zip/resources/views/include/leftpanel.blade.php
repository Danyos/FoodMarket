
    <div class="for-all d-none d-md-block">
        <div class="all-header">@lang('lang.ALL FOR ARRIVES')</div>
    </div>
    <div class="all-body d-none d-md-block">
        <div class="all-slick">
            @foreach($itemall->chunk(4) as $items)
                <div>

                    @foreach($items as $item)

                        <div class="all-product left-product-show">
                            <div class="all-product-image" onclick="location.href='{{url('/RestaurantProduct',$item->product_id)}}'">
                                <img src="{{asset('myproduct/'.$item->img)}}" alt="IMG">
                            </div>
                            <div class="all-product-text a-p-t">
                                <h6>{{$item->title_am}}</h6>

                                <p>
                                    <span class="price-now pricechangetype">{{$item->price_new}}</span>
                                    <span class="price-really">{{$item->price_old}}</span>

                                    <span class="currency">@lang('lang.amd')</span>
                                </p>
                                @if($item->stars==1)
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                @elseif($item->stars==2)
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                @elseif($item->stars==3)
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                @elseif($item->stars==4)
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                @elseif($item->stars==5)
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                @endif
                                <button type="button" onclick="sel()" class="sc-add-to-cart btn btn-success btn-sm addCart addCarts leftbarAddC" data-itemid="">
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i> Ավելացնել
                                </button>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>
    </div>

