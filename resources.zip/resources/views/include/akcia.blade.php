<div class="hot-prop">
    <div class="prop-body">
        <div class="prop-slick">
            @foreach($zexch as $zexcher)
                <div>
                    <div class="slick-window" style="height: 434px;">
                        <div class="slick-window-image">
                            <a href="{{route('RestaurantProduct',$zexcher->product_id)}}"><img src="{{asset('myproduct/'.$zexcher->img)}}" alt="IMG"></a>
                        </div>
                        <div class="this-time" data-indefikator="this-time-{{$zexcher->product_id}}" data-timin="{{$zexcher->datatime}}"></div>
                        <div class="timer">
                            <div class="clock day" data-indefikator="z-{{$zexcher->product_id}}">
                                <span id="this-time-{{$zexcher->product_id}}-d">0</span>
                                <p>Օր</p>
                            </div>
                            <div class="clock hour">
                                <span id="this-time-{{$zexcher->product_id}}-h">0</span>
                                <p>ժ</p>
                            </div>
                            <div class="clock min">
                                <span id="this-time-{{$zexcher->product_id}}-m">00</span>
                                <p>ր</p>
                            </div>
                            <div class="clock sec">
                                <span id="this-time-{{$zexcher->product_id}}-s">00</span>
                                <p>վ</p>
                            </div>
                        </div>
                        <div class="info">
                            <h5> {{$zexcher->{'title_'.session('locale')} }}</h5>
                            @if($zexcher->stars==1)
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            @elseif($zexcher->stars==2)
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            @elseif($zexcher->stars==3)
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            @elseif($zexcher->stars==4)
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                            @elseif($zexcher->stars==5)
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            @endif
                            <p>
                                <span class="price-now pricechangetype">{{$zexcher->price_new}}</span>
                                @if($zexcher->price_old>0)
                                    <span class="price-really pricechangetype">{{$zexcher->price_old}}</span>
                                @endif
                                <span class="currency">@lang('lang.amd')</span>
                            </p>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>
    </div>

</div>
