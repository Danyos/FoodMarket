@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    	<style type="text/css">
		.footer-info-2_ {
			padding: 15px;
			color: #444 !important;
		}
		
		b {
		    color: #444;
		}

		.footer-info-2_ p {
			font-size: 16px;
			color: #444;
		}

		.footer-info-2_ .val {
			color: #e95668;
		}

		.footer-info-2_ .pah {
			list-style: none;
			margin: 15px 0;
			color: #444;
		}
	</style>
@endsection
@section('content')
	
	<div class="container footer-info-2_">
		<h2 class="text-center">Fastfood.am-ին անհրաժեշտ են՝</h2>
		<hr>
		<div class="row">
		    <div class="col-sm-12 col-md-5 col-lg-4 col-xl-4">
		        <ul class="navbar-nav">
		            <li class="nav-item"><b>ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</b></li>
		            <li class="nav-item"><a href="{{route('AboutUs')}}">Մեր մասին</a></li>
		            <li class="nav-item"><a href="{{route('PrivacyPolicy')}}">Գաղտնիության քաղաքականություն</a></li>
		            <br>
		            <li class="nav-item"><b>ՍՊԱՍԱՐԿՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('Jobs')}}">Աշխատատեղեր</a></li>
		            <li class="nav-item"><a href="{{route('CorporateClients')}}">Կորպորատիվ հաճախորդներ</a></li>
		            <br>
		            <li class="nav-item"><b>ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('DeliveryPrices')}}">Առաքման գները և պայմանները</a></li>
		            <li class="nav-item"><a href="{{route('Paymentmethods')}}">Վճարման եղանակները և պայմանները</a></li>
		        </ul>
		    </div>
		    <div class="col-sm-12 col-md-7 col-lg-8 col-xl-8">
		        <h4 class="text-left">Առաքիչ մեքենայով</h4>
		        <p class="text-left">
			        <b style="color: #444;">Լոռիում:</b> Ունեք սեփական մեքենա՞: Մենք առաջարկում ենք Ձեզ հետաքրքիր և լավ վարձատրվող առաքիչի աշխատանք Աշխատեք ամսական <b class="val">60000</b>-<b class="val">120000</b> դրամ : 
		        </p>
		        <h5 class="text-left">Որն է մեր առավելությունը՝</h5>
		        <ul>
			        <li>Հետաքրքիր և ստաբիլ աշխատանք արագ զարգացող ընկերությունում:</li>
			        <li>Բարձր աշխատավարձ, որը վճարվում է ամսական <b class="val">2</b> անգամ</li>
			        <li>Ճկուն աշխատանքային գրաֆիկ, որը կարող էք համատեղել ձեր ածխատանքը այլ աշխատանքի հետ</li>
			        <li>Կարիերա ձեռք բերելու մեծ հնարավորություն</li>
			        <li class="pah">
			        	<b>Պահանջներ</b>
			        	<ul>
					        <li>Քաղաքում արագ կողմնորոշվելու ունակություն</li>
				        	<li>Սեփական մեքենայի առկայություն</li>
					        <li>Անգլերեն և/կամ ռուսերեն լեզուների իմացությունը ցանկալի է</li>
				        </ul>
			        </li>
	        	</ul>
	        	<h4 class="text-left">Առաքիչ հեծանիվով</h4>
	        	<p class="text-left">
	        		Ունեք սեփական հեծանի՞վ: Մենք առաջարկում ենք լավ վարձատրվող և հետաքրքիր  աշխատանք Վանաձորում: Աշխատեք ամսական <b class="val">50000</b>-<b class="val">80000</b> դրամ:
	        	</p>
	        	<h5 class="text-left">Աշխատավարձ և բոնուսներ</h5>
	        	<ul>
	        		<li>Աշխատավարձը վճարվում է ամսական <b class="val">2</b> անգամ</li>
	        		<li>Ամսական կարող եք ստանալ մինչև <b class="val">30 000</b> դրամ հավելավճար:</li>
	        	</ul>
	        	<h5 class="text-left">Մեզ մոտ Դուք կստանաք</h5>
	        	<ul>
		        	<li>Հետաքրքիր և ստաբիլ աշխատանք արագ զարգացող ընկերությունում:</li>
        			<li>Բարձր աշխատավարձ, որը վճարվում է ամսական <b class="val">2</b> անգամ</li>
        			<li>Ճկուն աշխատանքային գրաֆիկ, որը կարող էք համատեղել ձեր աշխատանքը այլ աշխատանքի հետ</li>
		        	<li>Կարիերա ձեռք բերելու մեծ հնարավորություն</li>
		        	<li class="pah">
			        	<b>Պահանջներ</b>
			        	<ul>
			        		<li>Քաղաքում արագ կողմնորոշվելու ունակություն</li>
			        		<li>Սեփական հեծանիվի առկայություն</li>
				        	<li>Անգլերեն և/կամ ռուսերեն լեզուների իմացությունը ցանկալի է</li>
			        	</ul>
			        </li>
	        	</ul>
		        <h4 class="text-left">Շրջիկ առաքիչներ</h4>
		        <ul>
		        	<li class="pah"><b>Պահանջներ</b></li>
		        	<li>Քաղաքում արագ կողմնորոշվելու ունակություն</li>
		        	<li>Սեփական հեծանիվի առկայություն</li>
		        	<li>Անգլերեն և/կամ ռուսերեն լեզուների իմացությունը ցանկալի է</li>
	        	</ul>
	        	<p class="text-left">Աշխատեք ամսական <b class="val">40000</b>-<b class="val">50000</b> դրամ:</p>
	        	<h6 class="text-left">Աշխատանքային ժամեր՝ 10։00-22։00</h6>
	        	<p class="text-left">Եթե ձեզ հետաքրքրում է մեզ հետ աշխատելը, կարող եք թողնել Ձեր տվյալները` գրելով <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b> :էլ փոստին:</p>
	        	<p class="text-left">
	        		Ձեզ հետաքրքրող հարցերի և պայմանագրի կնքման համար կարող եք զանգահարել` <b>093 708388</b> հեռախոսահամարով:
	        	</p>
        	</div>
	    </div>
	</div>
<script src="JS/_JQuery/jquery.js"></script>
<script src="JS/_Popper/popper.js"></script>
		<script src="JS/bootstrap.min.js"></script>
@endsection