@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    <style type="text/css">
		.footer-info-1_ {
			padding: 15px;
			color: #444 !important;
		}
		
		b {
		    color: #444;
		}

		.footer-info-1_ p {
			font-size: 16px;
			color: #444;
		}
		
	</style>
@endsection
@section('content')

	<div class="container container footer-info-1_">
		        <h2 class="text-center">Գաղտնիության քաղաքականություն</h2>
		        <hr>
		<div class="row">
		    <div class="col-sm-12 col-md-5 col-lg-4 col-xl-4">
		        <ul class="navbar-nav">
		            <li class="nav-item"><b>ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</b></li>
		            <li class="nav-item"><a href="{{route('AboutUs')}}">Մեր մասին</a></li>
		            <li class="nav-item"><a href="{{route('PrivacyPolicy')}}">Գաղտնիության քաղաքականություն</a></li>
		            <br>
		            <li class="nav-item"><b>ՍՊԱՍԱՐԿՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('Jobs')}}">Աշխատատեղեր</a></li>
		            <li class="nav-item"><a href="{{route('CorporateClients')}}">Կորպորատիվ հաճախորդներ</a></li>
		            <br>
		            <li class="nav-item"><b>ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('DeliveryPrices')}}">Առաքման գները և պայմանները</a></li>
		            <li class="nav-item"><a href="{{route('Paymentmethods')}}">Վճարման եղանակները և պայմանները</a></li>
		        </ul>
		    </div>
		    <div class="col-sm-12 col-md-7 col-lg-8 col-xl-8">
		<h4 class="text-left">Ընդհանուր դրույթներ եւ պայմաններ</h4>
		<p class="text-left">
			Ստորև բերված են <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> կայքից և առաքման ծառայությունից օգտվելու պայմանները։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը դա Հայաստանում ստեղծված առցանց ծառայություն է որը տալիս է հնարավորություն պատվիրել սնունդ, երեխային խնամելու միջոցներ, նարգիլե, ծաղիկներ, կենդանիների կերեր, խմիչքներ և այլն։
		</p>
		<p class="text-left">
			<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի գլխավոր գրասենյակը գտնվում է հետևյալ հասցեում` Տիգրան Մեծ 18, Վանաձոր, Լոռի, Հայաստան։
		</p>
		<p class="text-left">
			<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի հետ կապված յուրաքանչյուր հարց առաջանալու դեպքում կարող եք դիմել <b><a href="http://fastfood.am" target="_blank">"ՖԱՍՏՖՈՒԴ.ԷՅԷՄ"</a></b>-ի գրասենյակ, որը գտվում է Տիգրան Մեծ 18, Վանաձոր, Լոռի, Հայաստան հասցեում։
		</p>

		<h4 class="text-left">
			Անձնական տվյալների դիտարկում և խմբագրում
		</h4>
		<p class="text-left">
			Անձնական տվյալների պահպանման օրենքի համաձայն, <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի յուրաքանչյուր հաճախորդ, ունի իրավունք տեսնելու և խմբագրելու անձնական տվյալները հավաքվածներ կազմակերպության կողմից։ Դրա համար խնդրում ենք ուղղարկել էլեկտրոնային նամակ հետևյալ էլ․ հասցեին <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b> կամ զանգահարել <b>+374-93-708-388</b> հեռախոսահամարին։
		</p>

		<h4 class="text-left">
			Գաղտնիություն
		</h4>
		<p class="text-left">
			<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> կազմակերպությունը խիստ պահպանում է անձնական տվյալների պահպանման օրենքը։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը մեծ պատասխանատվությամբ է վերաբերվում իր հաճախորդների տվյալների պահպանմանը։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը հավաստիացնում է, որ ոչ մի անձնական տվյալ չի փոխանցվելու երրորդ անձանց։
		</p>

		<h4 class="text-left">
			Փոխհարաբերություններ ռեստորանների և մասնագիտացված խանութների հետ ներկայացված կայքում
		</h4>
		<p class="text-left">
			Պատվերը ստանալուց հետո, <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը  փոխանցում է պատվերը տվյալ ռեստորան կամ մասնագիտացված խանութ։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը հանդիսանում է միջնորդ հաճախորդի և ռեստորանի միջև։ Եթե ինչ որ պատճառով առքումը չի կարող կայանալ, <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը տեղյակ է պահում հաճախորդին հնարավորինս արագ։ Յուրաքնաչյուր փոփոխություն կապված առաքման հետ կախված է միայն ընտրված ռեստորանից։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> կազմակերպության պատասխանատվությունը, հաճախորդի պատվերը փոխանցել տվյալ կամակերպություն և առաքումը տվյալ կամակերպության կողմից պատրաստված ապրանքը հասցնել հաճախորդին խիստ սահմանապակ է։
		</p>

		<h4 class="text-left">
			Բողոք
		</h4>
		<p class="text-left">
			<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը չի կրում պատասխանատվություն կայքում տեղադրված ռեստորանների ուտեստների և ուտեստների որակի համար։ Եվ այնուամենայնիվ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը ջանք է գործադրում, որպեսզի պաշտպանի ռեստորանի կողմից խախտված հաճախորդների և օգտատերերի իրավունքները։ Ինչպես նաև <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը պատրաստ է առաջարկել փողհատուցում պատվերի ընդհանուր գնի սահմաններում առանձին և կոնկրետ իրավիճակներում։
			<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը կրում է պատասխանատվություն առաքման ժամանակահատվածի համար և պարտավորվում է մաքսիմալ ջանք գործադրել, որպեսզի իրականացնի առաքումը նշված ժամանակահատվածում։
		</p>

		<p class="text-left">
			Խնդրում ենք Ձեզ ուղարկել Ձեր բողոքները հետևյալ էլ․ հասցեով <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b> կամ զանգահարել <b>+374-93-708-388</b>:
		</p>

		<h4 class="text-left">
			Նամակներ և ոչ ցանկալի նամակներ (ՍՊԱՄ)։
		</h4>
		<p class="text-left">
			Եթե դուք գրանցված հաճախորդ եք ապա դուք պարբերաբար ստանալու եք նամակներ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ից։ Դուք կարող եք հրաժարվել նմանատիպ նամակներ ստանալուց սեխմելով “Unsubscribe” կոճակը համապատասխան նամակի մեջ։ Դրանից հետո դուք այլևս երբեք չեք ստանա նամակներ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ից։ 
		</p>

		<p class="text-left">
			Ավելի մարամասն իմֆորմացիաի համար կարող եք ուղարկել նամակ հետևյալ էլ․ հասցեով <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b> կամ զանգահարել <b>+374-93-708-388</b>։
		</p>

		<h4 class="text-left">
			Գներ
		</h4>
		<p class="text-left">
			Կայքի թարմացումները կատարվում են ամեն օր։ Չնայած որոշ հարգելի պատճառների հնարավոր է ժամանակ առ ժամանակ հանդիպել գնային անհամապատասխանության։ Ոչ ռեստորանը, ոչ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը չեն կրում ֆինանսական կոմպենսացիայի պատասխանատվություն գնային անհամապատասխանության համար։ Գնային անհամապատասխանության խնդիրների դեպքում խնդրում ենք տեղեկացնել <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> ուղարկելով նամակ հետևյալ էլ․ հասցեով <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b> կամ զանգահարել <b>+374-93-708-388</b>։
		</p>

		<h4 class="text-left">
			Հեղինակային իրավունքների պահպանում։
		</h4>
		<p class="text-left">
			Դուք չունեք իրավունք օգտագործելու, պատճենելու և/կամ տարածել <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> կազմակերպության ապրանքանիշը առանց թույլատվության։ Եթե դուք հետաքրքրված եք <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> կայքում տեղադրված ինֆորմացիաիով, ապա խնդրում ենք դիմել <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> ուղարկելով նամակ հետևյալ էլ․ հասցեով <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b> կամ զանգահարել <b>+374-93-708-388</b>։
		</p>

		<h4 class="text-left">
			Պատասխանատվություն
		</h4>
		<p class="text-left">
			<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը ջանք չի խնայում իր հաճախորդներին լավագույն սպասարկում ապահովելու համար։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը պատասխանատվություն չի կրում կայքի տեխնիկական անսարքությունների և համապատասխան ծառայությունների համար։
			Տվյալ համաձայնագիրը կարգավորվում է ՀՀ օրենսգրքով։
		</p>

		<p class="text-left">
			<b>
				<b><a href="http://fastfood.am" target="_blank">Ֆաստֆօօդ.am</a></b> © 2019 - բոլոր իրավունքները պաշտպանված են։
			</b>
		</p>
	</div>
		</div>
	</div>
	
@endsection