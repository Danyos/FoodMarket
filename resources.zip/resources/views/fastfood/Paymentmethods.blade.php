@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    	<style type="text/css">
		.footer-info-5_ {
			padding: 15px;
			color: #444 !important;
		}
		
		b {
		    color: #444;
		}

		.footer-info-5_ .header {
			color: #FF5F00 ;
		}

		.footer-info-5_ p {
			font-size: 16px;
			color: #444;
		}

		.footer-info-5_ .val {
			color: #e95668;
		}

		.footer-info-5_ b {
			color: #444;
		}
	</style>
@endsection
@section('content')


	<div class="container footer-info-5_">
		<h2 class="text-center">Վճարման եղանակները և պայմանները</h2>
		<hr>
        <div class="row">
            <div class="col-sm-12 col-md-5 col-lg-4 col-xl-4">
		        <ul class="navbar-nav">
		            <li class="nav-item"><b>ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</b></li>
		            <li class="nav-item"><a href="{{route('AboutUs')}}">Մեր մասին</a></li>
		            <li class="nav-item"><a href="{{route('PrivacyPolicy')}}">Գաղտնիության քաղաքականություն</a></li>
		            <br>
		            <li class="nav-item"><b>ՍՊԱՍԱՐԿՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('Jobs')}}">Աշխատատեղեր</a></li>
		            <li class="nav-item"><a href="{{route('CorporateClients')}}">Կորպորատիվ հաճախորդներ</a></li>
		            <br>
		            <li class="nav-item"><b>ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('DeliveryPrices')}}">Առաքման գները և պայմանները</a></li>
		            <li class="nav-item"><a href="{{route('Paymentmethods')}}">Վճարման եղանակները և պայմանները</a></li>
		        </ul>
		    </div>
            <div class="col-sm-12 col-md-7 col-lg-8 col-xl-8">
                <h4 class="text-left">Կանխիկ վճարման պայմանները՝</h4>
		        <ol>
		        	<li>կանխիկ վճարումը իրականցվում է պատվերը ստանալու պահին։ </li>
		        	<li>
		        		կանխիկ վճարումը կատարվում է բացառապես ՀՀ դրամով։ Դոլարով, Ռուբլիով և մնացած բոլոր արտարժույթներով կանխիկ վճարումներ չի իրականացվում։ ՀՀ օրենսդրությունը թույլ չի տալիս ՀՀ-ում կատարել այլ արտարժույթներով առևտուր։  
		        	</li>
		        	<li>
		        		<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ում նշված բոլոր ապրանքների գները ֆիքսված են՝ ներառված ԱԱՀ։ 
		        	</li>
		        	<li>
		        		առցանց <b>(online)</b> վճարում կատարվում է` պատվերը հաստատվելուց հետո։ 
		        	</li>
		        	<li>
			        	առցանց <b>(online)</b> վճարում կատարվում է` <b>Arca</b>, <b>Master</b>, <b>Visa</b> և <b>Idram</b> վճարային համակարգերով։ 
		        	</li>
			        <li>
			        	առցանց <b>(online)</b> վճարումը ենթակա է վերադարձի միայն այն դեպքում, երբ նշված կազմակերպությունը պատվերը ամբողջությամբ չի կարող կատարել։ 
			        </li>
			        <li>
			        	առցանց <b>(online)</b> վճարման հետ խնդիրներ առաջանալու դեպքում՝ կապ հաստատել մեր էլեկտորնային փոստով <b><a href="https://mail.ru/" target="_blink">info@fastfood.am</a></b>  կամ զանգահարել <b>+374 (93) 84-85-81</b> հեռախոսահամարով։ Սպասարկման որակը բարձրացնելու համար ձեր հեռախոսազանգը հնարավոր է ձայնագրվել։ 
		        	</li>
	        	</ol>
	        	<h4 class="text-center">Պատվերի չեղարկում</h4>
	        	<p class="text-left">
	        		<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ը միայն <b class="val">5</b> րոպեի ընթացքում կարող է չեղյալ հայտարարել ձեր պատվերը: Մենք կկարողանանք վերադարձնել ձեր գումարը միայն այս դեպքում:
	        	</p>
            </div>
        </div>
	</div>
@endsection