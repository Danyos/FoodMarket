@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    <style type="text/css">
		.footer-info-4_ {
			padding: 15px;
			color: #444 !important;
		}
		
		b {
		    color: #444;
		}

		.footer-info-4_ .header {
			color: #FF5F00 ;
		}

		.footer-info-4_ p {
			font-size: 16px;
			color: #444;
		}

		.footer-info-4_ .val {
			color: #e95668;
		}
	</style>
@endsection
@section('content')

	<div class="container footer-info-4_">
	    <div class="row">
	        <div class="col-sm-12 col-md-5 col-lg-4 col-xl-4">
		        <ul class="navbar-nav">
		            <li class="nav-item"><b>ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</b></li>
		            <li class="nav-item"><a href="{{route('AboutUs')}}">Մեր մասին</a></li>
		            <li class="nav-item"><a href="{{route('PrivacyPolicy')}}">Գաղտնիության քաղաքականություն</a></li>
		            <br>
		            <li class="nav-item"><b>ՍՊԱՍԱՐԿՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('Jobs')}}">Աշխատատեղեր</a></li>
		            <li class="nav-item"><a href="{{route('CorporateClients')}}">Կորպորատիվ հաճախորդներ</a></li>
		            <br>
		            <li class="nav-item"><b>ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('DeliveryPrices')}}">Առաքման գները և պայմանները</a></li>
		            <li class="nav-item"><a href="{{route('Paymentmethods')}}">Վճարման եղանակները և պայմանները</a></li>
		        </ul>
		    </div>
	        <div class="col-sm-12 col-md-7 col-lg-8 col-xl-8">
		        <h3 class="text-left header">Մեր մասին</h3>
		        <p class="text-left">
		        	<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> կայքը  օնլայն հավելված է, որտեղ ներկայացված են, ռեստորաններ, առրագ սննդի կետեր, բառ սրճարաններ, գարեջրատներ, կալյան խանութներ, բանջարեղենի խանութներ,  ծաղիկների և նվերների խանութներ, կենդանիների կերեր ։ <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>–ը իր հաճախորդներին թույլ է տալիս օնլայն տիրույթում կատարել գնումներ՝ ընտրելով հարմարավետությունը և խնայելով ժամանակը։ 
		        </p>

		        <h4 class="text-left header">Պատմություն</h4>
		        <p class="text-left">
		        	«Ֆաստֆուդ»-ն սկսեց իր գործունեությունը 2018թ.-ին, Վանաձորցիների պահանջարկով: ՝ նպատակ ունենալով մատուցել բարձրակարգ և որակյալ սպասարկում հասարակության տարբեր խավերին:
		        </p>
		        <p class="text-left">
		        	Այսօր «Ֆաստֆուդ» անունը յուրաքանչյուրի համար դարձել է որակի և արագության  չափանիշ, ինչն էլ մշտապես ապահովում է հաճախորդների բարձր գնահատականն ու վստահությունը: 
		        </p>
		        <p class="text-left">
		        	Հավատարիմ մնալով իր՝ «Ամենարագն ու հուսալին միայն մեզ հետ» կարգախոսին, «Ֆաստֆուդ»-ն ձգտում է լինել առաջինը՝ փորձելով հայ սպառողին մշտապես ներկայանալ Արագ և հուսալի սպասարկմամբ, թարմացվող տեսականիով:
		        </p>

		        <h4 class="text-left header">Մեր առաքելությունը</h4>
		        <p class="text-left">
		        	<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի առաքելությունն է իր հաճախորդներին մատուցել որակյալ ծառայություններ օնլայն տիրույթում՝ հնարավորություն ընձեռնելով կատարել գնումներ, ինչպես նաև առցանց ուսումնասիրել վաճառվող ցանկացած ապրանք։
		        </p>
		        <p class="text-left">
		        	<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի գործունեության հիմքում ընկած է հաճախորդի համար առավելագույնս շահավետ և որակյալ ծառայությունների մատուցումը:
		        </p>
		        <p class="text-left">
		        	Օնլայն գնումների գործընթացում մենք կարևորում ենք հաճախորդների կարիքները և պահանջմունքները՝ դարձնելով օնլայն գնումները դյուրին և հասանելի, ներկայացնելով բարձրորակ ապրանքների լայն տեսականի։
		        </p>

		        <h4 class="text-left header">Մեր առավելությունները</h4>
		        <p class="text-left">
		        	<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի մատուցած ծառայությունները առանձնանում են հետևյալ առավելություններով՝
		        </p>
		        <ul>
		        	<li>
		        		Օնլայն գնումներ կատարելու <b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b> համակարգը ապրանքների հսկայական կատալոգ է (մոտ <b class="val">20</b> հազար անուն ապրանք), որը ներկայանում է արդի օնլայն խանութին համապատասխան բոլոր գործիքներով՝ մատչելի որոնման հնարավորություն, որակյալ լուսանկարներ,  ապրանքերի նկարագրություն, ինչն էլ այցելուին տալիս է գնման համար անհրաժեշտ տեղեկություն:
		        	</li>
		        	<li>Էքսկլյուզիվ ապրանքատեսականու մեծ ընտրության հնարավորություն:</li>
		        	<li>Բարձր սպասարկման որակ՝  հիմնված հաճախորդների կարծիքի և պահանջմունքների վրա:</li>
		        	<li>
		        		Ձեր նախընտրած ապրանքները կարող եք պատվիրել աշխարհի ցանկացած կետից՝ Հայաստանում բնակվող Ձեր հարազատների և բարեկամների համար։
		        	</li>
		        	<li>Գնված ապրանքի արագ առաքում՝ Լուռու մարզում  առավելագույնը <b class="val">60</b> րոպեի ընթացքում:</li>
		        	<li>
		        		<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ի միջոցով դուք կարող եք կատարել ապահով օնլայն գործարքներ՝ տարբեր վճարային մեթոդներով: Կայքը հնարավություն է ընձեռում վճարել ինչպես կանխիկ, այնպես էլ գնումներ կատարել <b>ARCA</b>, <b>MasterCard</b>, <b>Visa</b>, վճարային համակարգերով, <b>IDRAM</b> համակարգով:
		        	</li>
		        	<li>
		        		<b><a href="http://fastfood.am" target="_blank">Fastfood.am</a></b>-ից գնումներ կատարել անվտանգ է։ Այստեղ երաշխավորված են Ձեր քարտային տվյալներ գաղտնիությունը Ameriabank -ի վճարային համակարգի կողմից։
		        	</li>
		        </ul>
		    </div>
		</div>
	</div>
@endsection