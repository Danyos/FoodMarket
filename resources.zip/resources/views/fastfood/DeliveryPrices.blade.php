@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    	<style type="text/css">
		.footer-info_ {
			padding: 15px;
			color: #444 !imortant;
		}
		
		b {
		    color: #444;
		}

		.footer-info-list_ {
			color: #444;
			padding-top: 15px;
		}

		.footer-info-list_ {
			padding-left: 17px;
			font-size: 18px;
		}

		.footer-info-list_ b {
			color: #e95668;
		}
		.footer-info_ p {
			font-size: 16px;
			color: #444;
		}
	</style>
@endsection
@section('content')



	<div class="container footer-info_">
		        <h2 class="text-center">Առաքման գները և պայմանները</h2>
		        <hr>
		<div class="row">
		    <div class="col-sm-12 col-md-5 col-lg-4 col-xl-4">
		        <ul class="navbar-nav">
		            <li class="nav-item"><b>ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</b></li>
		            <li class="nav-item"><a href="{{route('AboutUs')}}">Մեր մասին</a></li>
		            <li class="nav-item"><a href="{{route('PrivacyPolicy')}}">Գաղտնիության քաղաքականություն</a></li>
		            <br>
		            <li class="nav-item"><b>ՍՊԱՍԱՐԿՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('Jobs')}}">Աշխատատեղեր</a></li>
		            <li class="nav-item"><a href="{{route('CorporateClients')}}">Կորպորատիվ հաճախորդներ</a></li>
		            <br>
		            <li class="nav-item"><b>ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</b></li>
		            <li class="nav-item"><a href="{{route('DeliveryPrices')}}">Առաքման գները և պայմանները</a></li>
		            <li class="nav-item"><a href="{{route('Paymentmethods')}}">Վճարման եղանակները և պայմանները</a></li>
		        </ul>
		    </div>
		    <div class="col-sm-12 col-md-7 col-lg-8 col-xl-8">
		        <ol class="footer-info-list_">
			        <li>
			        	Վանաձոր քաղաքում պատվերը մի կետից մինչև պատվիրատու կազմում է ֆիքսված <b>300</b> դրամ։
			        </li>
			        <li>
			        	Վանաձոր քաղաքում յուրաքաչյուր հաջորդ կետից (ռեստորան, ծաղկի սրահ և այլն) պատվեր կատարելու դեպքում առաքման ֆիքսված <b>300</b> դրամին ավելանում է <b>200</b> դրամ։
			        </li>
			        <li>
			        	Վանաձորից դուրս այլ շրջաններ պատվերը առաքելու համար ներկայացնում ենք ֆիքսված գումարները, որը նշված կլինի գնումների զամբյուղում ձեր ընտրություններից հետո։ 
			        </li>
			        <li>
			        	Առաքումը իրականացվում է մեկ ժամվա ընթացքում կախված առաքման վայրից և եղանակային պայմաններից։ 
			        </li>
		        	<li>Վանաձորից դուրս առաքումը <b>1</b> կմ-ը  <b>70</b> դրամ է:</li>
		        </ol>
		        <p class="text-left">
		        	Առաքման պայմանների և գների  հետաքրքրող հարցերի դեպքում կարող եք զանգահարել` 
		        	<b>093 708 388</b> հեռախոսահամարով:
	        	</p>
		    </div>
		</div>
	</div>
@endsection