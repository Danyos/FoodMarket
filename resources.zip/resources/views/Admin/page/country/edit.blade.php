@extends('Admin.layouts.app')
@section('content')
<div class="modal-body">
    @if(session('okeys'))
        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

    @endif
    <form method="POST" action="{{route('County.update',$country->id)}}" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <input type="hidden" value="" name="section_id">

        <div class="form-group">
            <label for="input-1">@lang('admin.title_am')</label>
            <input type="text" name="country_am" class="form-control" id="input-1" value="{{$country->country_am}}" placeholder="@lang('admin.title_am')">
        </div>
        <div class="form-group">
            <label for="input-2">@lang('admin.title_ru')</label>
            <input type="text" name="country_ru" class="form-control" id="input-2" value="{{$country->country_ru}}" placeholder="@lang('admin.title_ru')">
        </div>
        <div class="form-group">
            <label for="input-3">@lang('admin.title_en')</label>
            <input type="text" name="country_en" class="form-control" id="input-3" value="{{$country->country_en}}" placeholder="@lang('admin.title_en')">
        </div>

        <div class="form-group">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"></span>
                </div>
                <br>
                <div class="custom-file">

                </div>
            </div></div>

        <div class="form-group">
            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
        </div>
    </form>
</div>
    @endsection
