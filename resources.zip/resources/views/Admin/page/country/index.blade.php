
@extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="col-sm-9">
                <h4 class="page-title">   @lang('admin.Sections')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{route('sectionMenu.index')}}">Մատուցվող Մենյու</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
{{--                      {{$section->name_am}}--}}
                    </li>
                </ol>
            </div>

            @if(session('error'))
                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

            @endif
            <div class="card">
                <div class="btn-group float-sm-right">
                    <!-- Large Size Modal -->
                    <button class="btn btn-light btn-block m-4" data-toggle="modal" data-target="#formemodal">@lang('lang.Add') @lang('admin.Sections')</button>
                    <!-- Modal -->
                    <div class="modal fade" id="formemodal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">@lang('lang.Add') @lang('admin.Sections')</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    @if(session('okeys'))
                                        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                    @endif
                                    <form method="POST" action="{{route('County.store')}}" enctype="multipart/form-data">
                                        @csrf
                                        <input type="hidden" value="" name="section_id">

                                        <div class="form-group">
                                            <label for="input-1">@lang('admin.title_am')</label>
                                            <input type="text" name="country_am" class="form-control" id="input-1" placeholder="@lang('admin.title_am')">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-2">@lang('admin.title_ru')</label>
                                            <input type="text" name="country_ru" class="form-control" id="input-2" placeholder="@lang('admin.title_ru')">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-3">@lang('admin.title_en')</label>
                                            <input type="text" name="country_en" class="form-control" id="input-3" placeholder="@lang('admin.title_en')">
                                        </div>

                                        <div class="form-group">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"></span>
                                                </div>
                                                <br>
                                                <div class="custom-file">

                                                </div>
                                            </div></div>

                                        <div class="form-group">
                                            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif
                <div class="card-body">
                    <h4 class="card-title">Մենյու</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Title arm</th>
                                    <th>Title rus</th>
                                    <th>title en</th>
                                    <th>update </th>
                                    <th>view</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($country as $countrys)
                                <tr>
                                    <td>{{$countrys->id}}</td>
                                    <td>{{$countrys->country_am}}</td>
                                    <td>{{$countrys->country_ru}}</td>
                                    <td>{{$countrys->country_en}}</td>
{{--                                    <td><img src="{{asset('myitem/'.$menuFood->img)}}" alt=""></td>--}}
                                    <td>
                                        <label class="badge badge-info" onclick="location.href='{{route('County.edit',$countrys->id)}}'">edit</label> ||
                                        <label class="badge badge-info" onclick="location.href='{{route('CountyPrice.show',$countrys->id)}}'">view</label> ||

                                    </td>

                                </tr>
                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    @endsection

