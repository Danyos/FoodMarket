@extends('Admin.layouts.app')
@section('content')



    <div class="col-12 col-lg-10">

        <!-- Title -->
        <div class="inbox-title mb-15">
            <h2>Զանգիր Ինձ</h2>
        </div>


        <div class="table-responsive">
            <table class="table table-dark">
                <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        Անուն
                    </th>

                    <th>
                        Գործող
                    </th>
                    <th>
                        Հեռ
                    </th>
                    <th>
                        Ժամ
                    </th>



                </tr>
                </thead>
                <tbody>
                @foreach($contact as $market)
                        <tr>
                            <td>
                                {{$market->id}}
                            </td>
                            <td>
                                <a>{{$market->title}}</a>
                            </td>
                            @if($market->status=='active')
                                <form action="{{route('contactmsgupdate',$market->id)}}" method="post">
                                    @csrf
                                    <input type="hidden" name="status" value="inactive">
                                    <td onclick="submit()">
                                        <button type="submit" class="badge badge-success" >{{$market->status}}</button>
                                    </td>
                                </form>
                            @else
                                <form action="{{route('contactmsgupdate',$market->id)}}" method="post">
                                    @csrf
                                    <input type="hidden" name="status" value="active">
                                    <td onclick="submit()">
                                        <button class="badge badge-warning" type="submit">{{$market->status}}</button>
                                    </td>
                                </form>
                            @endif

                            <td>
                                <a>{{$market->tel}}</a>
                            </td>



                            <td>
                                {{$market->created_at->format('Y-M-d')}}
                            </td>

                        </tr>
                    @endforeach
                    </tbody>
                </table>
            {{$contact->links()}}
            </div>
        </div>
<div class="mb-150"></div>


    @endsection
