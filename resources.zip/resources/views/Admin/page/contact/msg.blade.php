@extends('Admin.layouts.app')
@section('content')



    <div class="col-12 col-lg-10">

        <!-- Title -->
        <div class="inbox-title mb-15">
            <h2>Հետադարձ կապ</h2>
        </div>


        <div class="table-responsive">
            <table class="table table-dark">
                <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        Անուն
                    </th>
                    <th>
                        Գործող
                    </th>
                    <th>
                        Հեռ
                    </th>
                    <th>
                        Նյութ
                    </th>
                    <th>
                        Նկարագրություն
                    </th>
                    <th>
                        Ժամ
                    </th>


                </tr>
                </thead>
                <tbody>
                @foreach($contact as $market)
                    <tr>
                        <td>
                            {{$market->id}}
                        </td>
                        <td>
                            <a>{{$market->title}}</a>





                        @if($market->status=='active')

                            <form action="{{route('contactmsgupdate',$market->id)}}" method="post">
                                @csrf
                                <input type="hidden" name="status" value="inactive">
                                <td onclick="submit()">
                                    <button type="submit" class="badge badge-success" >{{$market->status}}</button>
                                </td>
                            </form>

                        @else

                            <form action="{{route('contactmsgupdate',$market->id)}}" method="post">
                                @csrf
                                <input type="hidden" name="status" value="active">
                                <td onclick="submit()">
                                    <button class="badge badge-warning" type="submit">{{$market->status}}</button>
                                </td>
                            </form>

                        @endif
<td>{{$market->tel}}</td>
                        <td>
                            @isset($market->file)
                                <a href="{{asset('pdf/'.$market->file)}}" target="_blank"><img src="{{asset('pdf/logo/Pdf_by_mimooh.svg')}}" alt="" style="width: 30px"   class="product-thumb d-block"></a>
                            @endisset
                        </td>
                        <td>
                            <a>{{$market->msg}}</a>
                        </td>
                        <td>
                            {{$market->created_at->format('Y-M-d')}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{$contact->links()}}
    </div>
<div class="mb-150"></div>


@endsection
