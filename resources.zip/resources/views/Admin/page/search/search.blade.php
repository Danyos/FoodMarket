@extends('Admin.page.item.layouts.app')

@section('content')
    <div class="card-body">
        <h4 class="card-title">Ապրանքատեսակներ</h4>
        <div class="row">
            <div class="col-12 table-responsive">
                <table id="order-listing" class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>վերնագիր</th>
                        <th>Լուսանկար</th>
                        <th>Փոփոխել || Ջնջել</th>

                    </tr>
                    </thead>
                    @if(isset($details))

                        <h3 class="catHeaderText"> {{ $query }}</h3>
                    <tbody>
                    @foreach($data as $restaurants)
                        <?php $product=\App\Models\Product::find($restaurants->product_id)?>
                        <tr>
                            <td>{{$restaurants->id}}</td>
                            <td>{{$restaurants->title_am}}</td>
                            <td><img style="width: 80px" src="{{asset('myproduct/'.$product->images)}}" alt="...">
                            </td>
                            <td>
                                <label class="badge badge-info" onclick="location.href='{{route('Items.edit',$product->id)}}'">Փոփոխել</label>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                        @else


                    @endif
                </table>
            </div>
        </div>
    </div>
    @endsection
