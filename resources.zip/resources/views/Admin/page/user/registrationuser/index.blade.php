@extends('Admin.layouts.app')
@section('content')

    <div class="content-wrapper">
        <div class="container-fluid">


            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title"> @lang('admin.Sections')</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">@lang('admin.home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                          @lang($sec)
                        </li>
                    </ol>
                </div>
                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif


                <div class="btn-group float-sm-right">
                    <!-- Large Size Modal -->
                    <button class="btn btn-light btn-block m-4" data-toggle="modal" data-target="#formemodal">@lang('lang.Add') @lang('admin.users')</button>
                    <!-- Modal -->
                    <div class="modal fade" id="formemodal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">@lang('lang.add') @lang('admin.users')</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    @if(session('okeys'))
                                        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                    @endif
                                    <form method="POST" action="{{ route('RegistrationUser.store') }}" enctype="multipart/form-data">
                                        {{ csrf_field() }}

                                        <div class="form-group">
                                            <label for="input-1">@lang('lang.name')</label>
                                            <input type="text" name="name" class="form-control" id="input-1" placeholder="@lang('lang.name')">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-2">@lang('lang.surname')</label>
                                            <input type="text" name="surname" class="form-control" id="input-2" placeholder="@lang('lang.surname')">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-3">@lang('lang.email')</label>
                                            <input type="text" name="email" class="form-control" id="input-3" placeholder="@lang('lang.email')">
                                        </div>

                                        <div class="form-group login-group-checkbox">
                                            <input type="radio" class="input-4" name="reg_gender" id="male" value="company" placeholder="@lang('lang.company')" >
                                            <label for="male">@lang('lang.company')</label>

                                            <input type="radio" class="input-5" name="reg_gender" id="female" value="man" placeholder="@lang('lang.man')">
                                            <label for="female">@lang('lang.man')</label>
                                        </div>
                                        <div class="form-group">
                                        <select name="rolle">
                                            <option value="0">User</option>
                                            <option value="1">Admin</option>
                                        </select>
                                        </div>
                                        <div class="form-group">
                                        <select name="status">
                                            <option value="active" >@lang('lang.top active')</option>
                                            <option value="inactive">@lang('lang.top inactive')</option>
                                        </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="reg_password" class="sr-only">@lang('lang.password')</label>
                                            <input type="password" class="form-control" id="reg_password" name="password" placeholder="@lang('lang.password')">
                                        </div>

                                        <div class="form-group">
                                            <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i> @lang('lang.Add')</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- End Breadcrumb-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card ">
                        <div class="card-header"><i class="fa fa-table"></i>  @lang('admin.Signup') {{$user->count()}}</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="default-datatable" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>@lang('lang.name')</th>
                                        <th>Rolle</th>
                                        <th>@lang('lang.surname')</th>
                                        <th>@lang('lang.company')</th>
                                        <th>@lang('lang.email')</th>
                                        <th>visit || delete</th>

                                    </tr>
                                    </thead>
                                    <tbody>

@foreach($user as $users)
                                        <tr data-id="{{$users->id}}">
                                            <td>
                                                <a href="{{route('Usersprofile',$users->id)}}"><i aria-hidden="true" class="fa fa-edit"></i> <span class="sr-only"></span>visit</a> || <i aria-hidden="true" class="fa fa-remove" id="user_del"  style="cursor: pointer;"  data-starts="{{$users->id}}" data-toggle="modal"
                                                                                                                                                                                          data-target="#deletef{{$users->id}}"
                                                                                                                                                                                          data-userid="{{route('RegistrationUser.destroy',$users->id)}}"> remove</i></td>


                                            <td>{{$users->id}}</td>
                                            <td><a href="{{route('Usersprofile',$users->id)}}">{{$users->name}}</a></td>
                                            @if($users->rolle==0)
                                            <td>User</td>
                                            @else
                                                <td>Admin</td>
                                                @endif
                                            <td>{{$users->surname}}</td>
                                            <td>{{$users->reg_gender}}</td>
                                            <td>{{$users->email}}</td>
                                            </tr>
@endforeach
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>id</th>
                                        <th>@lang('lang.name')</th>
                                        <th>Rolle</th>
                                        <th>@lang('lang.surname')</th>
                                        <th>@lang('lang.company')</th>
                                        <th>@lang('lang.email')</th>
                                        <th>visit || delete</th>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal-->
            <!-- Modal delete-->

            @foreach($user as $delete)
                <div class="modal fade modal" id="deletef{{$delete->id}}">
                    <div class="modal-dialog">
                        <div class="modal-content border-danger">
                            <div class="modal-header bg-danger">
                                <h3><i class="glyphicon glyphicon-thumbs-up"></i>@lang('lang.Iagree')</h3>
                                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-footer">
                                <form  action="{{route('destroyusers',$delete->id)}}" method="post">
                                    @csrf
                              <button  type="submit">@lang('lang.Yes')</button>
                                </form>
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">@lang('lang.No')
                                </button></div>
                        </div>
                    </div>
                </div>
            @endforeach



        <!-- End container-fluid-->

    </div><!--End content-wrapper-->
    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->




@endsection

