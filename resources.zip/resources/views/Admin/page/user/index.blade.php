
@extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">

            <div class="card">
                <div class="btn-group float-sm-right">
                    <button class="btn btn-light btn-block m-4" onclick="location.href='{{route('Admin.create')}}'">@lang('lang.Add') @lang('admin.Sections')</button>
                    <!-- Modal -->
                </div>

                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif
                <div class="card-body">
                    <h4 class="card-title">Data table</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Surname</th>
                                    <th>rolle</th>
                                    <th>Admin</th>
                                    <th>User</th>
                                    <th>email</th>

                                    <th>update || view || Delete</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($user as $users)
                                    <tr>
                                        <td>{{$users->id}}</td>
                                        <td>{{$users->name}}</td>
                                        <td>{{$users->surname}}</td>
                                        <td>{{$users->rolle}}</td>
                                        <td>{{$users->admin}}</td>
                                        <td>{{$users->user_type}}</td>

                                        <td>{{$users->email}}</td>
                                        <td>
                                            <label class="badge badge-info" onclick="location.href='{{route('Admin.edit',$users->id)}}'">edit</label> ||
                                            <label class="badge badge-secondary" onclick="location.href='{{route('Admin.show',$users->id)}}'">show</label> ||
                                            <label class="badge badge-info">Delete</label>
                                        </td>
                                        <td>
                                            <button class="btn btn-outline-primary" hidden>View</button>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection


