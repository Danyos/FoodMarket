@extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">
                            @if(session('succses'))
                                <div class="lobibox-notify-wrapper top right alerts">
                                    <div
                                        class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded"
                                        style="width: 400px;">
                                        <div class="lobibox-notify-icon-wrapper">
                                            <div class="lobibox-notify-icon">
                                                <div>
                                                    <div class="icon-el"><i class="fa fa-check-circle"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="lobibox-notify-body">
                                            <div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր
                                                փոփոխությունը
                                            </div>
                                        </div>
                                        <span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div>
                                </div>

                            @endif
                            @if(session('error'))
                                <div class="lobibox-notify-wrapper top right alerts">
                                    <div
                                        class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded"
                                        style="width: 400px;">
                                        <div class="lobibox-notify-icon-wrapper">
                                            <div class="lobibox-notify-icon">
                                                <div>
                                                    <div class="icon-el"><i class="fa fa-check-circle"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="lobibox-notify-body">
                                            <div class="lobibox-notify-msg" style="max-height: 32px;">Գաղտնաբարը չի
                                                համնկնում
                                            </div>
                                        </div>
                                        <span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div>
                                </div>

                            @endif
<form id="register-form" class="text-left" method="POST" action="{{ route('Admin.store') }}">
    {{ csrf_field() }}
    <div class="form-group{{ $errors->has('status') ? ' has-error' : '' }}">
        <select name="status" id="">
            <option value="active">Active</option>
            <option value="inactive">inactive</option>
        </select>
        <select name="rolle" id="cooise">
            <option value="user" hidden>Choois</option>
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="company">company</option>
        </select>


        <span class="rolles"></span>
    </div>
    <div class="login-form-main-message"></div>
    <div class="main-login-form">
        <div class="login-group">
            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                <label for="reg_username" class="sr-only">@lang('lang.name')</label>
                <input type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="@lang('lang.name')" required>
                @if($errors->has('name'))
                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                @endif
            </div>
            <div class="form-group{{ $errors->has('surname') ? ' has-error' : '' }}">
                <label for="reg_fullname" class="sr-only">@lang('lang.surname')</label>
                <input type="text" class="form-control" id="reg_fullname"  name="surname" value="{{ old('surname') }}" placeholder="@lang('lang.surname')">
                @if ($errors->has('surname'))
                    <span class="help-block">
                                        <strong>{{ $errors->first('surname') }}</strong>
                                    </span>
                @endif
            </div>
            <div class="form-group">
                <label for="reg_fullname" class="sr-only">@lang('lang.surname')</label>
                <input type="number" class="form-control" id="reg_fullname"  name="tel" value="" placeholder="Հեռ․">

            </div>

            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                <label for="reg_email" class="sr-only">@lang('lang.email')</label>
                <input type="text" class="form-control" id="reg_email" name="email" value="{{ old('email') }}" placeholder="@lang('lang.email')" required>
                @if($errors->has('email'))
                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                @endif
            </div>
            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                <label for="reg_password" class="sr-only">@lang('lang.password')</label>
                <input type="password" class="form-control" id="reg_password" name="password" placeholder="@lang('lang.password')" required>
                @if ($errors->has('password'))
                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                @endif
            </div>
            <div class="form-group">
                <label for="reg_password_confirm" class="sr-only">@lang('lang.chekpassword')</label>
                <input type="password" class="form-control" id="reg_password_confirm" name="password_confirmation" placeholder="@lang('lang.chekpassword')" required>
            </div>


        </div>
        <input type="hidden" name="avatar" value="avatar/avatar.webp">
        <button type="submit" class="login-button">  @lang('lang.Add')</button>
    </div>

    <div class="etc-login-form">
        @if (Route::has('password.request'))
            <a class="btn btn-link" href="{{ route('password.request') }}">

            </a>
        @endif
    </div>
</form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection
@section('js')
    <script>
        $(document).ready(function () {
            $('#cooise').change(function () {
                var rolle = $(this).val();
                $.ajax({
                    type:'get',
                    url:'{{url('User/Rolle')}}/'+rolle,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".rolles").html(data);
                    }
                });




            });

        });

    </script>
@endsection
