@extends('Admin.layouts.app')
@section('content')
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">@lang('admin.home')</a></li>
                        <li class="breadcrumb-item"><a href="javaScript:void();">{{$user->name}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{$user->name}} Profile</li>
                    </ol>
                </div>

            </div>
            <!-- End Breadcrumb-->

            <div class="row">
                <div class="col-lg-4">
                    <div class="card profile-card-2">
                        <div class="card-img-block">

                        </div>
                        <div class="card-body pt-5">

                            <?php $userphoto=\App\Models\UserPhoto::where('user_id',$user->id)->get()->reverse()->take(1);?>
                              @if(count($userphoto)==null)
                                    <img id="thumbImgs" src="{{asset('asset/image/avatar.webp')}}"
                                 alt="" class="profile">
                                 @else
                      @foreach($userphoto as $userphotos)
                
                           @if($userphotos->photo_name)
                             <img id="thumbImgs" src="{{asset('storage/user/'.$userphotos->photo_name)}}"
                                 alt="" class="profile">
                                 @elseif($userphotos->avatar)
                                   <img id="thumbImgs" src="{{$userphotos->avatar}}"
                                 alt="" class="profile">
                             @endif
                               @endforeach
       
                 @endif


                            <h5 class="card-title">{{$user->name}}</h5>
                            <p class="card-text">{{$user->reg_gender}}</p>

                        </div>

            
                    </div>

                </div>

                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-tabs-primary top-icon nav-justified">
                                <li class="nav-item">
                                    <a href="javascript:void();" data-target="#profile" data-toggle="pill" class="nav-link active"><i class="icon-user"></i> <span class="hidden-xs">  @lang('admin.home')</span></a>
                                </li>
                                <li class="nav-item">
                                    <a href="javascript:void();" data-target="#messages" data-toggle="pill" class="nav-link"><i class="icon-envelope-open"></i> <span class="hidden-xs">  @lang('lang.Messages')</span></a>
                                </li>
                                <li class="nav-item">
                                    <a href="javascript:void();" data-target="#edit" data-toggle="pill" class="nav-link"><i class="icon-settings"></i> <span class="hidden-xs">  @lang('lang.change')</span></a>
                                </li>

                            </ul>
                            <div class="tab-content p-3">
                                <div class="tab-pane active" id="profile">
                                    <h5 class="mb-3">@lang('admin.mainpart')</h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p>
                                               {{$user->name}}
                                               {{$user->surname}}<br>
                                               {{$user->tel}}<br>
                                               {{$user->email}}
                                            </p>
                                        </div>
                                        <div class="col-md-12">
                                            <h5 class="mt-2 mb-3"><span class="fa fa-clock-o ion-clock float-right"></span>@lang('lang.announcements')</h5>
                                            <div class="table-responsive">
                                                <table class="table table-hover table-striped">
                                                    <tbody>
                                                    @foreach($item as $itemstoday)
                                                        <tr>
                                                            <td onclick="location.href='{{route('items',$itemstoday->id)}}'" style="cursor: pointer;">
                                                                <span class="float-right font-weight-bold">{{$itemstoday->created_at->format('Y M d H:i')}}</span>{{$itemstoday->title}}
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/row-->
                                </div>
                                <div class="tab-pane" id="messages">
                                    <div class="alert alert-info alert-dismissible" role="alert">


                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-hover table-striped">

                                            <tbody>
                                            <?php $msg=\App\Models\Messager::where('to','=',$user->id)->where('from',\Illuminate\Support\Facades\Auth::user()->id)->get();?>
                                            <?php $msgfirst=\App\Models\Messager::where('to','=',$user->id)->where('from',\Illuminate\Support\Facades\Auth::user()->id)->first();?>
@foreach($msg as $usermsg)
    <?php $username=\App\User::find($usermsg->to);?>
       <div class="direct-chat-msg doted-border">
                                        <div class="direct-chat-info clearfix">
                                            <span class="direct-chat-name pull-left"></span>
                                        </div>
                                                @foreach($usermsg->msgs->reverse() as $main)
                                                    <tr>
                                                <td><a href="{{route('adminchat',$main->msg_id)}}" target="_blank">
                                                    <span class="float-right font-weight-bold">{{$main->name}} </span>
                                                    {{$main->body}} 
                                                    <br>
                                                
                                                    <i class="fa {{$main->fa}}" aria-hidden="true"></i>
                                                    </a>
                                                </td>
                                                    </tr>
                                                    @endforeach
                                                    </div>

                                    @endforeach
                                
                                
                                     <form action="{{route('adminmessager')}}" method="post" class="faicon">
                          @csrf
                                <div class="popup-messages-footer">

                                        <input type="hidden"  value="{{$msgfirst->msg_id??null}}" name="msg_id">

                                    <textarea id="status_message" placeholder="@lang('lang.Messages')" rows="3" cols="150" name="body"></textarea>
                                    <div class="btn-footer">
                                        <input type="checkbox" hidden class="bg_none" id="fil_peper" value="fa fa-thumbs-o-up" name="fa">
                                        <input type="hidden"  value="{{$user->id}}" name="to">
                                        <button type="submit" class="bg_none pull-right"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </form>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane" id="edit">
                                    <div class="modal-body">
                                        @if(session('okeys'))
                                            <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                        @endif
                                        <form method="POST" action="{{ route('myUserProfileupdate',$user->id) }}">
                                     @csrf
                                           
                                    
                                                             <div class="form-group">
                                                <select name="rolle">
                                                    @if($user->rolle=='0')

                                                    <option value="0" selected>User</option>
                                                        <option value="1">Admin</option>

                                                    @else
                                                        <option value="0">User</option>
                                                    <option value="1" selected>Admin</option>
                                                        @endif
                                                </select>
                                                <select name="admin">
                                                    @if($user->admin ==0)

                                                        <option value="0" selected>User</option>
                                                        <option value="1">Super Admin</option>
                                                        <option value="2">Admin</option>
                                                        @elseif($user->admin==1)
                                                        <option value="0" >User</option>
                                                    <option value="1" selected>Super Admin</option>
                                                    <option value="2">Admin</option>
                                                    @elseif($user->admin==2)
                                                        <option value="0" >User</option>
                                                        <option value="1">Super Admin</option>
                                                        <option value="2" selected>Admin</option>

@endif
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <select name="status">
                                                    @if($user->status=='active')
                                                    <option value="active" selected>@lang('lang.top active')</option>
                                                    <option value="inactive">@lang('lang.top inactive')</option>
                                                        @else
                                                        <option value="active" >@lang('lang.top active')</option>
                                                        <option value="inactive" selected>@lang('lang.top inactive')</option>
                                                    @endif
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i> @lang('lang.change')</button>
                                            </div>
                                            </form>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        <form method="POST" action="{{ route('UserProfile.update',$user->id) }}" enctype="multipart/form-data">
                                     @csrf
                                            @method('PUT')
                                            <div class="form-group">
                                                <label for="input-1">@lang('lang.name')</label>
                                                <input type="text" name="name" class="form-control"  id="input-1" value=" {{$user->name}}">
                                            </div>
                                            <div class="form-group">
                                                <label for="input-2">@lang('lang.surname')</label>
                                                <input type="text" name="surname" class="form-control" id="input-2" placeholder="@lang('lang.surname')" value="{{$user->surname}}">
                                            </div>
                                            <div class="form-group">
                                                <label for="input-3">@lang('lang.email')</label>
                                                <input type="text" name="email" class="form-control" id="input-3" placeholder="@lang('lang.email')" value="{{$user->email}}" disabled>
                                            </div>

                                            <div class="form-group login-group-checkbox">
                                                @if($user->reg_gender=='company')
                                                <input type="radio" class="input-4" name="reg_gender" id="male" value="company" placeholder="@lang('lang.company') " checked>
                                                <label for="male" >@lang('lang.company')</label>

                                                <input type="radio" class="input-5" name="reg_gender" id="female" value="man" placeholder="@lang('lang.man')">
                                                <label for="female">@lang('lang.man')</label>
                                                    @else
                                                    <input type="radio" class="input-4" name="reg_gender" id="male" value="company" placeholder="@lang('lang.company') " >
                                                    <label for="male" >@lang('lang.company')</label>

                                                    <input type="radio" class="input-5" name="reg_gender" id="female" value="man" placeholder="@lang('lang.man')" checked>
                                                    <label for="female">@lang('lang.man')</label>

                                                    @endif
                                            </div>
                  
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i> @lang('lang.change')</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <!-- End container-fluid-->
    </div><!--End content-wrapper-->
    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->

    @endsection