
@extends('Admin.page.Filter.layouts.app')
@section('content')

    <div class="col-12 col-lg-10">
        <div class="content-wrapper">
            @if(session('error'))
                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

            @endif
                @if(session('succses'))
                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

            @endif

                <div class="card-body">
                    <h4 class="card-title">Ստանդարտավորում</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Պանակ</th>
                                    <th>Չափս</th>


                                    <th>update  </th>
                                    <th>delete</th>


                                </tr>
                                </thead>
                                <tbody>
@foreach($ProductItemFilter as $ProductItemFilters)
    <form action="{{route('Itemfilter.destroy',$ProductItemFilters->id)}}" method="post" style="display: none">
@method('delete')
        @csrf
        <button type="button" class="pdoductdestroybutton badge-dark badge-info" id="del{{$ProductItemFilters->id}}" style="display: none;" >
        </button>
    </form>
                                <tr>

                                    <td>{{$ProductItemFilters->id}}</td>
                                    <?php $Porductfolder=App\Models\ItemFilterlist::find($ProductItemFilters->filter_id)?>
                                    <td>{{$Porductfolder->title}}</td>
                                    <td>{{$ProductItemFilters->size}}</td>

                                    <td><a href="{{route('Itemfilter.edit',$ProductItemFilters->id)}}">Edit</a> </td>
                                    <td><label class="badge badge-info" for="del{{$ProductItemFilters->id}}"><i class="fa fa-trash-o"></i></label></td>


                                </tr>
    @endforeach

                                </tbody>

                            </table>

                        </div>
                    </div>
                </div>


    </div>

    @endsection
        @section('js')
        <script>
            $('.pdoductdestroybutton').click(function(){

                var r = confirm("Ջնջե՞լ ապրանքը");
                if (r == true) {
                    $(this).attr('type','submit');
                } else {
                }
            })
        </script>
    @endsection

