@include('Admin.include.header')
<style>
    .inputborder{
        border: 1px solid black;
    }

</style>
    <!-- Side Menu Area -->


    <!-- Layout Container -->


        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">

                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                        <li class="breadcrumb-item"><a href="#">Ընկերություներ</a></li>

                </nav>
            </div>
        </div>

        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="inbox--area bg-boxshadow mb-50">
                            <div class="row">
                                <div class="col-12 col-lg-2">
                                    <div class="ibox mb-50">
                                        <div class="ibox-content mailbox-content">
                                            <div class="file-manager">

                                                <button class="btn btn-block btn-primary" data-toggle="modal" data-target="#formemodal">@lang('lang.Add') Ստանդարտավորում</button>
                                                <!-- Modal -->
                                                <br>
                                                <div class="modal fade" id="formemodal">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">@lang('lang.Add') Ստանդարտավորում</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>

                                                            <div class="modal-body">
                                                                @if(session('okeys'))
                                                                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                                                @endif
                                                                    <form method="POST" action="{{route('Itemfilter.store')}}" enctype="multipart/form-data">
                                                                        @csrf
                                                                        <strong style="color: red">*</strong>
                                                                        <div class="form-group">
                                                                            <label for="input-1">Չափս</label>
                                                                            <input type="text" name="size" class="form-control" id="input-1" placeholder="Չափս">
                                                                        </div>

                                                                        <select name="filter_id" id="" style="border-radius: 15px; border:1px solid;padding: 5px;" >
                                                                            <option value="" hidden style="color: red">Պարտադիր Լրացրեք *</option>
                                                                            @foreach($ItemFilterlist as $ProductItemFilters)
                                                                                <option value="{{$ProductItemFilters->id}}">{{$ProductItemFilters->title}}</option>
                                                                            @endforeach
                                                                        </select>

                                                                        <div class="mb-70">

                                                                            </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
                                                                        </div>
                                                                    </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Title -->
                                                <div class="categori-title mt-20">
                                                    <h6>Մենյուների Պանակներ</h6>
                                                </div>
                                                <!-- List -->
<?php    $market=App\Models\FoodMarket::get(); ?>
                                                <form action="{{route('ListFilter.store')}}" method="post">
                                                    @csrf
                                                <input type="text" name="title" placeholder="Ստեղծել նոր պանակ *" style="border-radius: 15px; border:1px solid;padding: 5px;">
                                                    <button type="submit" style="border-radius: 15px; border:1px solid;padding: 5px;">Save</button>
                                                </form>
                                                <ul class="category-list" style="padding: 0">
                                                    <li> <a href="{{route('ListFilter.index')}}"> <i class="fa fa-circle text-danger"></i>Բոլոր</a>

                                                    </li>
                                                    @foreach($ItemFilterlist as $categories)
                                                        <li> <a href="{{route('ListFilter.show',$categories->id)}}"> <i class="fa fa-circle text-danger"></i>{{$categories->title}}  </a>

                                                        </li>
{{--                                                        <form action="" method="post" class="badge ">--}}

{{--                                                            @method('DELETE')--}}
{{--                                                            @csrf--}}
{{--                                                            <button type="button" class="folder" style="font-size: 10px;"><i class="fa fa-trash"></i>--}}
{{--                                                            </button>--}}

{{--                                                        </form>--}}
                                                    @endforeach

                                                </ul>
                                                <div class="clearfix"></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @yield('content')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


@section('js')
<script>
    $('.folder').click(function(){

        var r = confirm("Ջնջե՞լ ապրանքը");
        if (r == true) {
            $(this).attr('type','submit');
        }
    })
</script>
@endsection
@include('Admin.include.footer')
