
@extends('Admin.page.Filter.layouts.app')

@section('content')

    <div class="col-12 col-lg-10">
        <div class="content-wrapper">
            <div class="col-sm-9">
                <h4 class="page-title">   @lang('admin.Sections')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{route('sectionMenu.index')}}">  Ստանդարտ Մենյու</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                       {{$ProductItemFilter->size}}
                    </li>

                </ol>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">


                        <div class="card-body">
                            @if(session('okey'))
                                <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր փոփոխությունը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                            @endif
                            <form action="{{route('Itemfilter.update',$ProductItemFilter->id)}}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <?php $Porductfolder=App\Models\ItemFilterlist::find($ProductItemFilter->filter_id)?>


                                <select name="filter_id" id="" style="border-radius: 15px; border:1px solid;padding: 5px;" >
                                    <option value="{{$Porductfolder->id}}" hidden style="color: red">{{$Porductfolder->title}}</option>
                                    @foreach($ItemFilterlist as $ProductItemFilters)
                                        <option value="{{$ProductItemFilters->id}}">{{$ProductItemFilters->title}}</option>
                                    @endforeach
                                </select>
                                <div class="form-group">
                                    <label for="input-1">Հուշաբառ</label>
                                    <input type="text" name="size" class="form-control" id="input-1" value="{{$ProductItemFilter->size}}" placeholder="Հուշաբառ">
                                </div>

                                <div class="mb-70">


                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ar"></i> @lang('lang.change')</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
