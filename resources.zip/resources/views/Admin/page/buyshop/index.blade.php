
@extends('Admin.layouts.app')
@section('js')
    <script>
        setInterval(function(){
           location.reload()
        }, 7000);

    </script>
@endsection
@section('content')


        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Գնումներ</li>
                    </ol>
                </nav>
            </div>
        </div>

        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <!-- Product List Area -->
                        <div class="product-list--area bg-boxshadow">
                            <div class="ibox-content">
                                <div class="row mb-30">
                                    <div class="col-sm-4">
                                        <form action="{{route('statusselect')}}" method="post">
                                            @csrf
                                            <label class="col-form-label" for="status">Բացված || Չբացված</label>
                                            <select name="status" id="status" class="form-control" onchange="submit()">

                                                <option hidden>Ընտրել</option>
                                                <option value="active">Բացված</option>
                                                <option value="inactive">Չբացված</option>
                                            </select>
                                        </form>
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-lg-12">
                                    <!-- Ibox -->
                                    <div class="ibox">
                                        <!-- Ibox Content -->
                                        <div class="ibox-content" style="border: 1px solid black;">
                                            <!-- Footable -->
                                            <table class="footable table table-stripped toggle-arrow-tiny default breakpoint footable-loaded" border="1" data-page-size="15">
                                                <thead >
                                                <tr style="border: 1px solid black;">
                                                    <th data-toggle="true" class="footable-visible footable-first-column footable-sortable">Id<span class="footable-sort-indicator"></span></th>
                                                    <th data-toggle="true" class="footable-visible footable-first-column footable-sortable">Անուն<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Status<span class="footable-sort-indicator"></span></th>

                                                    <th data-hide="phone" class="footable-visible footable-sortable">E-mail<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Ամբողջ գումար<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Ընտրած տարածաշրջանը<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Հասցե<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Տուն<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Բնակարան<span class="footable-sort-indicator"></span></th>
                                                    <th data-hide="phone" class="footable-visible footable-sortable">Բացել<span class="footable-sort-indicator"></span></th>

                                                </tr>
                                                </thead>
                                                <tbody>
                                                @foreach($BuyShop as $BuyShops)
                                                <tr class="footable-even" style="display: table-row;">
                                                    <td class="footable-visible footable-first-column"><span class="footable-toggle"></span>
                                                        {{$BuyShops->id}}
                                                    </td>
                                                    <td class="footable-visible footable-first-column"><span class="footable-toggle"></span>
                                                        {{$BuyShops->name}}
                                                    </td>
                                                    <td class="footable-visible">
                                                        @if($BuyShops->status=='inactive')
                                                        <span class="label label-danger" onclick="location.href='{{route('buyshop.edit',$BuyShops->id)}}'">{{$BuyShops->status}}</span>
                                                            @else
                                                            <span class="label label-warning" onclick="location.href='{{route('buyshop.edit',$BuyShops->id)}}'">{{$BuyShops->status}}</span>
                                                        @endif
                                                    </td>
                                                    <td class="footable-visible">
                                                        {{$BuyShops->email}}
                                                    </td>

                                                    <td class="footable-visible">
                                                        {{$BuyShops->all_money}}

                                                    </td>
                                                    <td class="footable-visible">
                                                        {{$BuyShops->choose_country_section}}
                                                    </td>
                                                    <td class="footable-visible">
                                                        {{$BuyShops->street}} /{{$BuyShops->floor}}
                                                    </td>
                                                    <td class="footable-visible">
                                                        {{$BuyShops->home}}
                                                    </td>
                                                    <td class="footable-visible">
                                                        {{$BuyShops->enter}}
                                                    </td>
                                                    <td class="text-right footable-visible footable-last-column">
                                                     <button class="label label-info" onclick="location.href='{{route('buyshop.show',$BuyShops->id)}}'">Տեսնել</button>
                                                    </td>
                                                </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
{{$BuyShop->links()}}
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>

                    </div>
                </div>
            </div>
        </div>
<div class="mb-150"></div>


@endsection
