
@extends('Admin.layouts.app')
@section('content')

    <div class="breadcrumb-area">
        <div class="container-fluid">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{route('adminindex')}}">Գլխավոր</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><a href="{{route('buyshop.index')}}">Գնումներ</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Գնված ապրանքներ</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="wrapper wrapper-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Basics Tables Area -->
                    <div class="basic-tables-area bg-boxshadow">

                        <table class="table table-warning" id="printTable">
                            <thead align="center" style="font-size:18px; ">
                            <th >Անուն</th>
                            <th >Հեռ</th>
                            <th >Փողոց</th>
                            <th >Մուտք</th>
                            <th >Հարկ</th>
                            <th >Տուն</th>
                            </thead>
                            <br>
                            <br>
                            <br>

                            <tbody class="mb-200">
                            <tr style="font-size:15px; ">
                                <td align="center">{{$main->name}}</td>
                                <td align="center">{{$main->tel}}</td>
                                <td align="center">{{$main->street}}</td>
                                <td align="center">{{$main->enter??'-'}}</td>
                                <td align="center">{{$main->floor??'-'}}</td>
                                <td align="center">{{$main->home}}</td>

                            </tr>
                            <tr>
                                <td> <hr style="width: 100%!important;"></td>
                                <td> <hr style="width: 100%!important;"></td>
                                <td> <hr style="width: 100%!important;"></td>
                                <td> <hr style="width: 100%!important;"></td>
                                <td> <hr style="width: 100%!important;"></td>
                                <td> <hr style="width: 100%!important;"></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                            </tr>
                            </tbody>

<thead class=" table-dark mb-100">

                            <tr>
                                <th>Ապրանքի անուն</th>
                                <th>Նկարագրություն</th>
                                <th>Ընկերություներ</th>
                                <th>Քանակ</th>
                                <th>Գումար</th>
                                <th class="dnj">Լուսանկար</th>
                                <th class="dnj">Իմանալ ավելին</th>
                            </tr>
                            </thead>
                            <tbody class="table-dark">


                                @foreach($BuyShop as $BuyShops)
                                    <?php $product=App\Models\Product\Lang::where('product_id',$BuyShops->product_id)->first()?>
                                    <tr>

                                    <td>{{$product->title_am}}</td>
                                <td>{{$BuyShops->description}}</td>
                                <?php $food=App\Models\FoodMarket::find($BuyShops->market)?>
                                <td>{{$food->market_name_am}}</td>
                                <td>{{$BuyShops->quantity}}</td>
                                <td>{{$BuyShops->price}}</td>
                                <td class="dnj"><img src="{{asset('myproduct/'.$product->img)}}" style="width: 80px;" alt=""></td>
                                <td class="dnj">
                                    <button class="btn-white btn btn-xs" onclick="location.href='{{route('productshows',$BuyShops->product_id)}}'">Տեսնել Ապրանքը</button>
                                </td>
                            </tr>
                            @endforeach


                            </tbody>
                            <tfoot >


                            <tr>
                           <td style="font-size:15px; ">   Ամբողջ գումար․՝ <b style="font-weight: bold;font-size:20px; ">{{$main->all_money}} </b> դրամ</td>
                            </tr>

                            <tr>
                                <td> <hr style="border:0.3px dotted black;width: 100%!important;"></td>
                                <td> <hr style="border:0.3px dotted black;width: 100%!important;"></td>
                                <td> <hr style="border:0.3px dotted black;width: 100%!important;"></td>
                                <td> <hr style="border:0.3px dotted black;width: 100%!important;"></td>
                                <td> <hr style="border:0.3px dotted black;width: 100%!important;"></td>
                                <td> <hr style="border:0.3px dotted black;width: 100%!important;"></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                                <td><br></td>
                            </tr>
                            </tfoot>

                        </table>



                        <button class="pronterbutton">Print me</button>
                    </div>

                </div>
                <!-- / Content -->

            </div>
        </div>
    </div>

@endsection
@section('js')
    <script>
        function printData()
        {
            var divToPrint=document.getElementById("printTable");
            var divToPrint2=document.getElementById("printTable2");
            var divToPrint3=document.getElementById("printTable3");
            newWin= window.open("");
            newWin.document.write(divToPrint.outerHTML);
            newWin.document.write(divToPrint.outerHTML);
            newWin.document.write(divToPrint.outerHTML);

            newWin.focus();
            newWin.print();
            newWin.close();
        }

        $('.pronterbutton').on('click',function(){
            $('.dnj').remove();
            printData();
        })
    </script>
@endsection
