
@extends('Admin.page.sectionmenu.layouts.app')

@section('content')

    <div class="col-12 col-lg-10">
        <div class="content-wrapper">
            <div class="col-sm-9">
                <h4 class="page-title">   @lang('admin.Sections')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{route('sectionMenu.index')}}">  Մատուցվող Մենյու</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                       {{$menufood->name_am}}
                    </li>

                </ol>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <?php $category=\App\Models\Menufolder::get(); ?>
                        <?php $folders=\App\Models\Menufolder::find($menufood->folder_id); ?>

                        <div class="card-body">
                            @if(session('okey'))
                                <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր փոփոխությունը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                            @endif
                            <form action="{{route('sectionMenu.update',$menufood->sections_id)}}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')

                                <select name="folder_id" id="">
                                    <option value="{{$folders->id??null}}" hidden style="color: red">{{$folders->folder??null}}</option>
                                    @foreach($category as $folder)
                                        <option value="{{$folder->id}}">{{$folder->folder}}</option>
                                    @endforeach
                                </select>
                                <div class="form-group">
                                    <label for="input-1">Հուշաբառ</label>
                                    <input type="text" name="slug" class="form-control" id="input-1" value="{{$menufood->slug}}" placeholder="Հուշաբառ">
                                </div>
                                <div class="form-group">
                                    <label for="input-1">@lang('admin.title_am')</label>
                                    <input type="text" name="name_am" value="{{$menufood->name_am}}" class="form-control" id="input-1" placeholder="{{$menufood->food_name_am}}">
                                </div>
                                <div class="form-group">
                                    <label for="input-2">@lang('admin.title_ru')</label>
                                    <input type="text" name="name_ru" value="{{$menufood->name_ru}}" class="form-control" id="input-2" placeholder="{{$menufood->food_name_ru}}">
                                </div>
                                <div class="form-group">
                                    <label for="input-3">@lang('admin.title_en')</label>
                                    <input type="text" name="name_en" class="form-control" value="{{$menufood->name_en}}" id="input-3" placeholder="{{$menufood->food_name_en}}">
                                </div>

                                <div class="form-group">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
                                        </div>
                                        <br>


                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ar"></i> @lang('lang.Add')</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
