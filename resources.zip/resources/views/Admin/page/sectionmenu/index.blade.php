
@extends('Admin.page.sectionmenu.layouts.app')
@section('content')

    <div class="col-12 col-lg-10">
        <div class="content-wrapper">
            @if(session('error'))
                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

            @endif
                @if(session('succses'))
                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

            @endif

                <div class="card-body">
                    <h4 class="card-title">Մենյու</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Հուշաբառ</th>
                                    <th>Պանակ</th>
                                    <th>Title arm</th>
                                    <th>Title rus</th>
                                    <th>title en</th>
                                    <th>update  </th>
                                    <th>delete</th>
                                    <th>view</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($menu as $menuFood)
<?php $folders=\App\Models\Menufolder::find($menuFood->folder_id);?>
                                <tr>
                                    <td>{{$menuFood->sections_id}}</td>
                                    <td>{{$menuFood->slug}}</td>
                                    <td>{{$folders->folder??null}}</td>
                                    <td>{{$menuFood->name_am}}</td>
                                    <td>{{$menuFood->name_ru}}</td>
                                    <td>{{$menuFood->name_en}}</td>
{{--                                    <td><img src="{{asset('myitem/'.$menuFood->img)}}" alt=""></td>--}}
                                    <td>   <label class="badge badge-info" onclick="location.href='{{route('sectionMenu.edit',$menuFood->sections_id)}}'"><i class="fa fa-edit"></i></label>

                                    </td>
                                    <td>

                                        <form action="{{route('sectionMenu.destroy',$menuFood->sections_id)}}" method="post" class="badge ">
                                            @method('DELETE')
                                            @csrf
                                            <button type="button" style="padding: 10px" class="pdoductdestroybutton"><i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>

                                    <td>
                                        <button class="btn btn-outline-primary" onclick="location.href='{{route('MENU.show',$menuFood->sections_id)}}'">Կազմել Մենյու</button>
                                    </td>
                                </tr>
                    @endforeach
                                </tbody>

                            </table>
                            {{$menu->links()}}
                        </div>
                    </div>
                </div>


    </div>

    @endsection
        @section('js')
        <script>
            $('.pdoductdestroybutton').click(function(){

                var r = confirm("Ջնջե՞լ ապրանքը");
                if (r == true) {
                    $(this).attr('type','submit');
                } else {
                }
            })
        </script>
    @endsection

