
@extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="col-sm-9">
                <h4 class="page-title">   @lang('admin.Sections')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{route('sectionMenu.index')}}">  Մատուցվող Մենյու</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{url('/MENU/'.$section_chek->sections_id)}}">{{$section_chek->name_am}}</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        {{$menufood->food_name_am}}
                    </li>

                </ol>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">
                            @if(session('okey'))
                                <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր փոփոխությունը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                            @endif
                            <form action="{{route('MENU.update',$menufood->id)}}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <div class="form-group">
                                    <h6>Բաժնի ապրանք</h6>

                                <select name="sections_id">
                                    <option value="{{$section_chek->sections_id}}" selected hidden>{{$section_chek->name_am}}</option>
                                    @foreach($section as $sectionmenu)

                                    <option value="{{$sectionmenu->sections_id}}">{{$sectionmenu->name_am}}</option>
                                        @endforeach
                                </select>
                                </div>
                                <div class="form-group">
                                    <h6>Ինչի մեջ երեվա</h6>

                                <select name="category_id">
                                    @if($category_id==null)
                                        <option value="0" hidden >Չեմ Ցանկանում</option>

                                        @endif
                                        <option value="0">Չեմ Ցանկանում</option>
                                </select>
                                </div>
                                <div class="form-group">
                                    <label for="input-1">@lang('admin.title_am')</label>
                                    <input type="text" name="food_name_am" value="{{$menufood->food_name_am}}" class="form-control" id="input-1" placeholder="{{$menufood->food_name_am}}">
                                </div>
                                <div class="form-group">
                                    <label for="input-2">@lang('admin.title_ru')</label>
                                    <input type="text" name="food_name_ru" value="{{$menufood->food_name_ru}}" class="form-control" id="input-2" placeholder="{{$menufood->food_name_ru}}">
                                </div>
                                <div class="form-group">
                                    <label for="input-3">@lang('admin.title_en')</label>
                                    <input type="text" name="food_name_en" class="form-control" value="{{$menufood->food_name_en}}" id="input-3" placeholder="{{$menufood->food_name_en}}">
                                </div>

                                <div class="form-group">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
                                        </div>
                                        <br>


                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ar"></i> @lang('lang.Add')</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
