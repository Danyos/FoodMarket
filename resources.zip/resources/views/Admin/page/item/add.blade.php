@extends('Admin.page.item.layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('assets/vendors/iconfonts/font-awesome/css/font-awesome.min.css')}}">

@endsection
@section('content')












                        <div class="card-body">
                            @if(session('error'))
                                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

                            @endif
                            <div class="modal-body">
                                @if(session('okeys'))
                                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">ХЂХЎХЅХїХЎХїХѕХҐЦЃ Х±ХҐЦЂ ХЎХѕХҐХ¬ХЎЦЃХёЦ‚ХґХЁ</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">Г—</span></div></div>
                                @endif

                                <form method="POST" action="{{route('Items.store')}}" enctype="multipart/form-data">

                                    @csrf
                                  <div class="form-control">

                                        <div class="form-control">
                                            <input type="datetime-local" value="{{\Illuminate\Support\Carbon::now()->format('Y-m-d\TH:i:s')}}" name="datatime">
                                        </div>

                                    <select class="status form-control" name="status" required>
                                        <option value="active" hidden>Status</option>
                                        <option value="active">Active</option>
                                        <option value="Inactve">Inactive</option>

                                    </select>


                                    <hr>




                                    <select  name="folder" required class="folders form-control" style="border: 2px solid red; border-radius: 15px; box-shadow: 2px 3px #FF5F00;">
                                        <option hidden selected>Ընտրել Պանակը</option>
                                        @foreach($MenuFolder as $folders)
                                            <option value="{{$folders->id}}">{{$folders->folder}}</option>
                                        @endforeach
                                    </select>
                                    <div class="mydish"></div>
                                    @error('food_menu_id')
                                    <br>
                                    <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել ընտրել Ճաշացանկը դաշտը.
                                                    </p>
                                                </span>
                                    @enderror



                               <div class="listmenuchek "></div>



                                    <hr>



                                    <div class="form-control">
                                        <span>
                                                <select name="filter_list" id="" class="filteritem" style="border-radius: 15px;padding: 2px;" >
                                          <option value="0" hidden style="color: red">Ստանդարտներ</option>
                                          @foreach($ItemFilterlist as $ProductItemFilters)
                                                        <option value="{{$ProductItemFilters->id}}">{{$ProductItemFilters->title}}</option>
                                                    @endforeach
                                      </select>
                                        </span>
                                        <span class="myfilter"></span><br>
                                        Նորություն:<input type="checkbox" name="new" value="active">
                                       Լավագույն:<input type="checkbox" name="best" value="active">
                                        Բոլոր Առիթների համար:<input type="checkbox" name="օccasions" value="active">
                                        <br>
                                        <span>
                                          <select  name="fastfood" required>
                                              <option value="inactive" hidden>fastfood</option>
                                        <option value="active">Active</option>
                                        <option value="Inactve">Inactive</option>

                                    </select>
</span>
                                        <span>
                                          <select  name="dishe" required>
                                              <option value="inactive" hidden>dishe</option>
                                        <option value="active">Active</option>
                                        <option value="Inactve">Inactive</option>

                                    </select>
</span>
                                        <span>
                                          <select  name="drink" required>
                                              <option value="inactive" hidden>drink</option>
                                        <option value="active">Active</option>
                                        <option value="Inactve">Inactive</option>

                                    </select>
</span>
                                        <span>
                                          <select  name="vegetable" required>
                                              <option value="inactive" hidden>vegetable</option>
                                        <option value="active">Active</option>
                                        <option value="Inactve">Inactive</option>

                                    </select>
</span>
                                    </div>


                                    <hr>

                                    <div class="form-group {{ $errors->has('alians') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('admin.alians')</label>
                                        <input type="text" name="alians"  value="{{old('alians')}}" class="form-control" id="input-1" placeholder="@lang('admin.alians')">

                                    </div>

                                    <div class="form-group {{ $errors->has('title_am') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.title') Armenia</label>
                                        <input type="text" name="title_am"  value="{{old('title_am')}}" class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                        @error('title_am')
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
                                                    </p>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group {{ $errors->has('title_ru') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.title') Russia</label>
                                        <input type="text" name="title_ru"  value="{{old('title_ru')}}" class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                        @error('title_ru')
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
                                                    </p>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group {{ $errors->has('title_en') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.title') English</label>
                                        <input type="text" name="title_en"  value="{{old('title_en')}}" class="form-control" id="input-1" placeholder="@lang('lang.title')">
                                        @error('title_en')
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
                                                    </p>
                                            </span>
                                        @enderror
                                    </div>

                                    <div class="form-group {{ $errors->has('description_am') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.description') Armenia</label>

                                        <textarea rows="4" name="description_am" class="form-control" id="basic-textarea">{{old('description_am')}}</textarea>
                                        @error('description_am')
                                        <br>
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
                                                    </p>
                                                </span>
                                        @enderror
                                    </div>
                                    <div class="form-group {{ $errors->has('description_ru') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.description')  Russia</label>

                                        <textarea rows="4" name="description_ru" class="form-control" id="basic-textarea">{{old('description_ru')}}</textarea>
                                        @error('description_ru')
                                        <br>
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
                                                    </p>
                                                </span>
                                        @enderror
                                    </div>
                                    <div class="form-group {{ $errors->has('description_en') ? ' has-error' : '' }}">
                                        <label for="input-1">@lang('lang.description') English</label>

                                        <textarea rows="4" name="description_en" class="form-control" id="basic-textarea">{{old('description_en')}}</textarea>
                                        @error('description_en')
                                        <br>
                                        <span class="help-block">
                                                    <p class="alert alert-danger">
                                                        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
                                                    </p>
                                                </span>
                                        @enderror
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-6">
                                            <label for="input-1">Old % price</label>

                                            <input type="number" name="price_old" class="form-control" id="input-1" placeholder="@lang('lang.price') Old Price Դ">
                                        </div>

                                        <div class="col-6">
                                            <label for="input-1">price</label>

                                            <input type="number" name="price_new" class="form-control" id="input-1" placeholder="@lang('lang.price')   Դ">
                                        </div>


                                    </div>

     <p>Վարկանիշ</p>


                                    <select id="example-fontawesome" name="stars" autocomplete="off">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>


                                    <div class="form-group">
                                        <label>Images</label>
                                        <input class="form-control" type="file" name="images">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i>@lang('lang.Add')</button>
                                    </div>
                                </form>
                            </div>
                        </div>













@endsection
@section('js')



    <script>
        $(document).ready(function () {
    $('.folders').change(function () {
                var folder = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('Product/Folders')}}/'+folder,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".mydish").html(data);
                    }
                });




            });
    $('.filteritem').change(function () {
                var folder = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('Itemfilter')}}/'+folder,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".myfilter").html(data);
                    }
                });




            });

        });

    </script>

@endsection
