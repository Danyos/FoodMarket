@extends('Admin.page.item.layouts.app')

@section('content')



                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif
                <div class="card-body">
                    <h4 class="card-title">Ապրանքատեսակներ</h4>
                    <div class="row">
                        <div class="col-11 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>վերնագիր</th>
                                    <th>
                                            <summary>Ինֆորմացիա</summary>



                                    <th>Լուսանկար</th>
                                    <th>Փոփոխել ||Կրկնօրինակել|| Ջնջել</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($product as $products)

                                    <form action="{{route('Items.destroy',$products->product_id)}}" method="post" style="display: none">
                                        @method('DELETE')
                                        @csrf
                                        <button type="button" class="pdoductdestroybutton badge-dark badge-info" id="del{{$products->product_id}}" style="display: none;" >
                                          </button>
                                    </form>
                                <tr>

                                    <td>{{$products->product_id}}</td>

                                    <td>

                                        <details>
                                                <summary>{{$products->title_am}}</summary>
                                                <p>{{$products->title_ru}}</p>
                                                <p>{{$products->title_en}}</p>

                                        </details>


                                    </td>


                                    <?php $MenuFood=\App\Models\MenuFood::find($products->food_menu_id) ?>
                                    <?php $FoodMarket=\App\Models\FoodMarket::find($products->food_market_id) ?>
                                    <?php $list_menus=\App\Models\Section::where('sections_id',$products->section_id)->first() ?>


                                    <td> <details>
                                        <summary>  {{$list_menus->name_am??' '}}</summary>
                                        <p>  <br><br>
                                                                                        {{$FoodMarket->{'market_name_'.session('locale')}??null }} || <br><br>
                                           {{$MenuFood->{'food_name_'.session('locale')}??null }}  || <br><br>
                                            {{$products->price}} || <br><br>
                                            {{$products->phone}}</p>

                                    </details>

                                    </td>

                                    <td><img src="{{asset('myproduct/'.$products->images)}}" style="width: 80px;" alt=""></td>


                                    <td>

                                        @if($products->product_id)
                                        <label class="badge badge-info" onclick=" window.open('{{route('Items.edit',$products->product_id)}}')" formtarget="_blank"><i class="fa fa-edit"></i></label>
                                        <label class="badge badge-outline-dark" onclick="location.href='{{route('productshows',$products->product_id)}}'"><i class="fa fa-street-view"></i></label>
                                        <label class="badge badge-success" onclick="location.href='{{route('copy.show',$products->product_id)}}'"><i class="fa fa-copy"></i></label>
                                        @endif
                                            @if(auth()->user()->admin=='superAdmin')
                                        <label class="badge badge-danger" for="del{{$products->product_id}}"><i class="fa fa-remove"></i></label>
                                            @endif
                                    </td>





                                </tr>
                                    @endforeach

                                </tbody>
                            </table>
                        </div>
                    </div>
                    {{$product->links()}}
                </div>


    @endsection
@section('js')
<script>
    $('.pdoductdestroybutton').click(function(){

        var r = confirm("Ջնջե՞լ ապրանքը");
        if (r == true) {
            $(this).attr('type','submit');
        } else {
        }
    })
</script>
    @endsection
