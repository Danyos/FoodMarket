@extends('Admin.layouts.app')

@section('content')


        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('index')}}">Գլխավոր</a></li>
                        <li class="breadcrumb-item"><a href="{{route('Items.index')}}">Ապրանքատեսակ</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{$product->title_am}}</li>
                    </ol>
                </nav>
            </div>
        </div>
@if(session()->has('verj'))
    <strong style="color: red;">Դուք թուլյատրելի դաշտերում ավելացրել եք ապրանք </strong>
    <br> <?php $ItemFilterlist=App\Models\ItemFilterlist::find($findparent_id->filter_list) ?>
    <strong style="color: sandybrown;">Եթե Ցանկանում եք կարող եք ավելացնել</strong>

         <b style="color: #0a0b0d">{{$ItemFilterlist->title??null}}</b>-ի բաժինում ևս ստանդարտ և կրկին ավելացնել ապրանք </b>
    <br>
         <b style="color: #0a0b0d">Հակառակ դեպքում ջնջել   ապրանք <a class="nav-link" data-toggle="tab" href="#item-standart">Տեսնել</a> </b>
    @endif
        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="product--item-arae bg-boxshadow">
                            <!-- Media -->
                            <div class="media align-items-center py-3 mb-4">
                                <img src="{{asset('myproduct/'.$product->images)}}" alt="" class="product-thumb d-block">
                                <!-- Media Body -->
                                <div class="media-body ml-4">
                                    <h4 class="mb-15">{{$product->title_am}}</h4>
                                    <a href="{{route('Items.edit',$product->product_id)}}" class="btn btn-primary btn-sm mb-15">Փոփոխել</a>&nbsp;
                                    <form action="{{route('Items.destroy',$product->product_id)}}" method="post" style="display: inline;">
                                        @method('DELETE')
                                        @csrf
                                        <button type="button" class="pdoductdestroybutton btn btn-danger btn-sm mb-15" >Ջնջել
                                        </button>
                                    </form>
                                    <a href="{{route('Items.create')}}" class="btn btn-default btn-sm mb-15">Ավելացնել new Ապրանքատեսակ</a>
                                    @if(count($ProductItemFilter)>0)

                                    <a href="{{route('itemadd',$product->product_id)}}" class="btn btn-success btn-sm mb-15">Ավելացնել տվյալ ապրանքատեսակին նոր ապրանք</a>
                               <a href="{{route('searchitemadd',$product->product_id)}}" class="btn btn-dropbox btn-sm mb-15">Որոնում</a>
                                    @else


                                            <a class="btn btn-success btn-sm mb-15" data-toggle="tab" href="#item-standart">Ավելացնել Ստանդարները</a>



                             @endif
                                </div>
                            </div>

                            <!-- Nav Tabs -->
                            <div class="nav-tabs-top">
                                <ul class="nav nav-tabs">
                                    <!-- Nav Item -->
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="tab" href="#item-overview">Հիմնական</a>
                                    </li>
                                    <!-- Nav Item -->
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#item-description">Նկարագրություներ</a>
                                    </li>
                                    @if(count($ProductItemFilter)>0)
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#item-standart">Տեսնել Ստանդարները</a>
                                    </li>
                                    @else
                                        <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#item-standart">Ավելացնել Ստանդարները</a>
                                    </li>
                                    @endif
                                    <!-- Nav Item -->
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#item-discounts">Գնումներ</a>
                                    </li>
                                    <!-- Nav Item -->
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#item-images">Լուսանկարներ</a>
                                    </li>
                                </ul>

                                <!-- Tab Content -->
                                <div class="tab-content">
                                    <!-- Overview -->
                                    <div class="tab-pane fade show active" id="item-overview">
                                        <div class="card-body product-item-table">
                                            <h6 class="large font-weight-semibold mb-4">Վերնագիրեր</h6>
                                            <!-- Table -->
                                            <table class="table">
                                                <tbody>
                                                <tr>
                                                    <td>Վերնագիր:</td>
                                                    <td>{{$product->title_am}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Վերնագիր Ռուսերեն:</td>
                                                    <td>{{$product->title_ru}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Վերնագիր Անգլերեն:</td>
                                                    <td>{{$product->title_en}}</td>
                                                </tr>

                                                </tbody>
                                            </table>

                                        </div>
                                        <hr class="m-0">

                                        <!-- Card Body -->
                                        <div class="card-body">
                                            <h6 class="large font-weight-semibold mb-4">Հիմնական</h6>
                                            <!-- Product Item table -->
                                            <table class="table product-item-table">
                                                <tbody>
                                                <tr>
                                                    <td>Գումար:</td>
                                                    <td>
                                                        <strong>{{$product->price_new}} Դրամ</strong>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Զեղչված գումար:</td>
                                                    <td>{{$product->price_old}} @if($product->price_old) Դրամ @endif</td>
                                                </tr>
                                                <tr>
                                                    <td>Ընկերությունը</td>
                                                    <td><a href="{{$product->food_market_id}}">{{$product->market_name_am}}</a></td>
                                                </tr>
                                                <tr>
                                                    <td>Նախնական Մենյու</td>
                                                    <td>{{$product->name_am}}</td>
                                                </tr>    <tr>
                                                    <td>Մենյու</td>
                                                    <td>{{$product->food_name_am}}</td>
                                                </tr>
                                                <tr>
                                                    <td>Ավելացնող</td>
                                                    <?php use App\Models\FoodMarket;use App\User;$user=User::find($product->user_id);?>
                                                    <td>{{$user->name}}</td>
                                                </tr>

                                                </tbody>
                                            </table>

                                        </div>
                                        <hr class="m-0">
                                        <!-- Card Body -->
                                        <div class="card-body">
                                            <h6 class="large font-weight-semibold mb-4">Նշումներ</h6>
                                            <!-- Product Item table -->
                                            <table class="table product-item-table">
                                                <tbody>
                                                <tr>
                                                    <td>Լավագույն:</td>
                                                    @if($product->best=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->best}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->best}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Նոր:</td>
                                                    @if($product->new=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->new}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->new}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Ակտիվ:</td>
                                                    @if($product->status=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->status}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->status}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Բոլոր առիթների համար:</td>
                                                    @if($product->օccasions=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->օccasions}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->օccasions}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Ֆաստ Ֆուդ:</td>
                                                    @if($product->fastfood=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->fastfood}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->fastfood}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>կերակրատեսակ:</td>
                                                    @if($product->dishe=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->dishe}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->dishe}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Խմիրքներ:</td>
                                                    @if($product->drink=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->drink}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->drink}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Մրգեր         :</td>
                                                    @if($product->vegetable=='active')
                                                        <td>
                                                            <span class="badge badge-success">{{$product->vegetable}}</span>
                                                        </td>
                                                    @else
                                                        <td>
                                                            <span class="badge badge-warning">{{$product->vegetable}}</span>
                                                        </td>
                                                    @endif
                                                </tr>
                                                <tr>
                                                    <td>Վարկանիշ:</td>
                                                    <td>
                                                        <span class="ui-product-color align-middle"></span>
                                                        <span class="align-middle">{{$product->stars}}</span>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                        <hr class="m-0">
                                        <!-- Card Body -->

                                    </div>


                                    <!-- Item Description -->
                                    <div class="tab-pane fade" id="item-description">
                                        <div class="card-body p-3">

                                            <div class="row">
                                                <div class="col-md-3">
                                                    <p>
                                                        {{$product->description_am}}
                                                    </p>
                                                </div>
                                                <div class="col-md-3">
                                                    <p>
                                                        {{$product->description_ru}}
                                                    </p>
                                                </div>
                                                <div class="col-md-3">
                                                    <p>
                                                        {{$product->description_en}}
                                                    </p>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <!-- Item Discounts -->
                                    <div class="tab-pane fade" id="item-standart">
                                        <?php $ItemFilterlist=App\Models\ItemFilterlist::find($findparent_id->filter_list??null) ?>

                                        <h4>  {{$ItemFilterlist->title??null}}</h4>
                                        <div class="wrapper wrapper-content" >
                                            <div class="container-fluid">
                                                <div class="row">

                                                    @if(count($ProductItemFilter)>0)

                                                        @foreach($ProductItemFilter as $ProductItemFilters)

                                                    <div class="col-12 col-md-6 col-lg-4" >
                                                        <form action="{{route('filterdelete',$ProductItemFilters->product_item)}}" method="post" style="display: none">

                                                            @csrf
                                                            <button type="button" class="pdoductdestroybutton badge-dark badge-info" id="del{{$ProductItemFilters->product_item}}" style="display: none;" >
                                                            </button>
                                                        </form>
                                                        <div class="notes-pin-board mb-50">
                                                            <!-- Content -->
                                                            <div class="pin-board-content" style="background-image: url('{{asset('myproduct/'.$ProductItemFilters->img)}}');height:200px;background-size:100% 100%; background-repeat: no-repeat;">
<?php $ProductItemFilterssize=App\Models\ProductItemFilter::find($ProductItemFilters->filter_id)?>

                                                                <small style="color:#aa1111;font-weight: bold;">{{$ProductItemFilterssize->size??null}}</small>

                                                                <h2 style="color:black;background-color:rgba(255, 100, 20, 0.5); font-weight: bold;">{{$ProductItemFilters->title_am}}</h2>
                                                                <p style="color:#aa1111;font-weight: bold;">{{$ProductItemFilters->description_am}}</p>
                                                                <p style="color:#aa1111;font-weight: bold;">{{$ProductItemFilters->product_id}}</p>
                                                                <p style="color:#aa1111;font-weight: bold;">{{$ProductItemFilters->product_item}}</p>


                                                                @if(auth()->user()->admin=='superAdmin')


        @if($ProductItemFilters->home!='active')
            <label class="badge badge-info" for="del{{$ProductItemFilters->product_item}}"><i class="fa fa-trash-o"></i></label>

@endif            @if(count($ProductItemFilter)<=1)
            <label class="badge badge-info" for="del{{$ProductItemFilters->product_item}}"><i class="fa fa-trash-o"></i></label>
        @endif

            <a href="{{route('itemsedits',$ProductItemFilters->product_item)}}" class="btn btn-primary btn-sm mb-15"><i class="fa fa-edit"></i></a>


                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                 @endforeach

                                                    @else

                                                            <div class="col-12 col-md-6 col-lg-4">
                                                                <!-- Notes -->
                                                                <div class="notes-pin-board mb-50">
                                                                    <!-- Content -->
                                                                    <div class="pin-board-content">
                                                                        <form method="POST" action="{{route('ListFilter.update',$product->product_id)}}" enctype="multipart/form-data">

                                                                            @csrf
                                                                            @method('PUt')
<span>
                                                                            <select name="filter_list" id="" class="filteritem">
                                                                                <option value="null" hidden style="color: red">Ստանդարտներ</option>

                                                                                @foreach($Filterlist as $ProductItemFilters)
                                                                                    <option value="{{$ProductItemFilters->id}}">{{$ProductItemFilters->title}}</option>
                                                                                @endforeach
                                                                            </select>
</span>
                                                                            <span class="myfilter" ></span><br>

                                                                                <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i>@lang('lang.Add')</button>

                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                        @endif

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="item-discounts">
                                        <div class="card-body">
                                            <!-- Table Responsive -->
                                            <div class="table-responsive">
                                                <table class="table product-item-discounts-table">
                                                    <thead>
                                                    <tr>
                                                        <th>Անուն Ազգանուն</th>
                                                        <th>Քանակ</th>
                                                        <th>Նկարագրություն</th>
                                                        <th>Հեռ</th>
                                                        <th>Առաքում հասցե</th>
                                                        <th>Պատվիրված Ժամը</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach($cart as $shop)

                                                    <tr>
                                                        <th>{{$shop->name}}</th>
                                                        <th>{{$shop->quantity}}</th>
                                                        <th>{{$shop->description}}</th>
                                                        <th>{{$shop->tel}}</th>
                                                        <th>{{$shop->street}}/{{$shop->enter}}/{{$shop->floor}}/{{$shop->home}}</th>
                                                        <th>{{$shop->created_at}}</th>
                                                    </tr>
                                 @endforeach
                                                    </tbody>
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                    <!-- / Discounts -->

                                    <!-- Images -->
                                    <div class="tab-pane fade" id="item-images">
                                        <div class="card-body">

                                            <div class="mb-4">
                                                <span class="badge badge-dot badge-primary"></span> Primary image
                                            </div>

                                            <!-- Lightbox template -->
                                            <div id="product-item-lightbox" class="blueimp-gallery blueimp-gallery-controls">
                                                <div class="slides"></div>
                                                <p class="title"></p>
                                                <a class="prev">‹</a>
                                                <a class="next">›</a>
                                                <a class="close">×</a>
                                                <ol class="indicator"></ol>
                                            </div>
                                            <!-- Item Image -->
                                            <div id="product-item-images" class="row">


                                                @foreach($images as $imagess)

                                                <div class="col-12 col-sm-6 col-md-4 col-xl-3 mb-4">
                                                    <a href="{{asset('myproduct/'.$imagess->image)}}" class="d-block"><img src="{{asset('myproduct/'.$imagess->image)}}" class="img-fluid" alt=""></a>
                                                </div>
@endforeach
                                            </div>
                                        </div>
                                    </div>
                                    <!-- / Images -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    @endsection
@section('js')
    <script>
        $('.pdoductdestroybutton').click(function(){

            var r = confirm("Ջնջե՞լ ապրանքը");
            if (r == true) {
                $(this).attr('type','submit');
            } else {
            }
        })
    </script>


    <script>
        $(document).ready(function () {




            });
            $('.filteritem').change(function () {
                var folder = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('Itemfilter')}}/'+folder,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".myfilter").html(data);
                    }
                });




            });



    </script>

@endsection
