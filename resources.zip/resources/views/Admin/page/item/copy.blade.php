@extends('Admin.page.item.layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('assets/vendors/iconfonts/font-awesome/css/font-awesome.min.css')}}">

@endsection
@section('content')

    <div class="col-md-9">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">@lang('lang.change')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="">@lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">

                    </li>
                </ol>
            </div>
        </div>


        <div class="row left-section">
            <div class="col-lg-12">
                <div class="card">

                    <form action="{{route('copy.store',$product->product_id)}}" method="post" enctype="multipart/form-data">

                        @csrf


                        <div class="form-control">
                            <input type="datetime-local"
                                   value="{{\Carbon\Carbon::parse($product->datatime)->format('Y-m-d\TH:i:s')}}"
                                   name="datatime">
                        </div>
                        @if($product->new=='active')
                            New:<input type="checkbox" name="new" value="active" checked>
                        @else
                            New:<input type="checkbox" name="new" value="active">
                        @endif

                        @if($product->best=='active')
                            Best:<input type="checkbox" name="best" value="active" checked>
                        @else
                            Best:<input type="checkbox" name="best" value="active">
                        @endif
                        @if($product->օccasions=='active')
                            օccasions:<input type="checkbox" name="օccasions" value="active" checked>
                        @else
                            օccasions:<input type="checkbox" name="օccasions" value="active">
                        @endif

                        <span>


        <select name="fastfood" required>

                <option value=" {{$product->fastfood}}"
                        hidden>Ֆաստ Ֆուդ:{{$product->fastfood}}</option>

        <option value="active">Active</option>
        <option value="Inactive">Inactive</option>

        </select>
        </span>

                        <span>


        <select name="dishe" required>

        <option value="{{$product->dishe}}" hidden>կերակրատեսակ:{{$product->dishe}}</option>

        <option value="active">Active</option>
        <option value="Inactive">Inactive</option>

        </select>
        </span>
                        <span>


        <select name="drink" required>
        <option value="{{$product->drink}}" hidden>Խմիրքներ:{{$product->drink}}</option>
        <option value="active">Active</option>
        <option value="Inactive">Inactive</option>

        </select>
        </span>
                        <span>


        <select name="vegetable" required>
        <option value=" {{$product->vegetable}}"
                hidden>Մրգեր: {{$product->vegetable}}</option>
        <option value="active">Active</option>
        <option value="Inactive">Inactive</option>

        </select>
        </span>


                        <br>

                        <select name="folder" required class="folders" style="border: 2px solid red; border-radius: 15px; box-shadow: 2px 3px #FF5F00;">
                            <option hidden selected value="{{$folder->id}}" >{{$folder->folder}}</option>

                            @foreach($folderall as $folderalls)
                                <option
                                    value="{{$folderalls->id}}">{{$folderalls->folder}}</option>
                            @endforeach
                        </select>

                        @error('food_menu_id')
                        <br>
                        <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել ընտրել Ճաշացանկը դաշտը.
        </p>
        </span>
                        @enderror
                        <span class="mydish" >
                                            <select class="menu" name="section_id" style="border: 2px solid red; border-radius: 15px; box-shadow: 2px 3px #FF5F00;">
                                                <option hidden value="{{$product->sections_id}}">{{$product->name_am}}</option>
                                                @foreach($sectionmain as $sectionmenu)
                                                    <option
                                                        value="{{$sectionmenu->sections_id??null}}">{{$sectionmenu->name_am??null}}</option>
                                                @endforeach
                                            </select>
</span>
                        <span class="listmenuchek">
                                            <select class=" oldmenus" name="food_menu_id" style="border: 2px solid red; border-radius: 15px; box-shadow: 2px 3px #FF5F00;">
                                                <option hidden selected
                                                        value="{{$product->food_menu_id}}">{{$product->food_name_am}}</option>
                                            </select>

                                           </span>
                        <br>
                        <select name="status">

                            <option value="{{$productstatus->status}}"
                                    hidden>{{$productstatus->status}}</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>


                        </select>

                        <span>
                                                <select name="filter_list" id="" class="filteritem" style="border-radius: 15px;padding: 2px;" >
                                          <option value="0" hidden style="color: red">Ստանդարտներ</option>
                                          @foreach($ItemFilterlist as $ProductItemFilters)
                                                        <option value="{{$ProductItemFilters->id}}">{{$ProductItemFilters->title}}</option>
                                                    @endforeach
                                      </select>
                                        </span>
                        <span class="myfilter"></span><br>
                        <div class="form-group {{ $errors->has('alians') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('admin.alians')</label>
                            <input type="text" name="alians" value="{{$product->alians}}"
                                   class="form-control" id="input-1" placeholder="@lang('admin.alians')">

                        </div>
                        <div class="form-group {{ $errors->has('title_am') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('lang.title') Armenia</label>
                            <input type="text" name="title_am" value="{{$product->title_am}}"
                                   class="form-control" id="input-1" placeholder="@lang('lang.title')">
                            @error('title')
                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
        </p>
        </span>
                            @enderror
                        </div>
                        <div class="form-group {{ $errors->has('title_ru') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('lang.title') Russia</label>
                            <input type="text" name="title_ru" value="{{$product->title_ru}}"
                                   class="form-control" id="input-1" placeholder="@lang('lang.title')">
                            @error('title')
                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
        </p>
        </span>
                            @enderror
                        </div>
                        <div class="form-group {{ $errors->has('title_en') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('lang.title') English</label>
                            <input type="text" name="title_en" value="{{$product->title_en}}"
                                   class="form-control" id="input-1" placeholder="@lang('lang.title')">
                            @error('title')
                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել վերնագրի դաշտը.
        </p>
        </span>
                            @enderror
                        </div>

                        <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('lang.description') Armenia</label>

                            <textarea rows="4" name="description_am" class="form-control"
                                      id="basic-textarea">{{$product->description_am}}</textarea>
                            @error('description')
                            <br>
                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
        </p>
        </span>
                            @enderror
                        </div>
                        <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('lang.description') Russia</label>

                            <textarea rows="4" name="description_ru" class="form-control"
                                      id="basic-textarea">{{$product->description_ru}}</textarea>
                            @error('description')
                            <br>
                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
        </p>
        </span>
                            @enderror
                        </div>
                        <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
                            <label for="input-1">@lang('lang.description') English</label>

                            <textarea rows="4" name="description_en" class="form-control"
                                      id="basic-textarea">{{$product->description_en}}</textarea>
                            @error('description')
                            <br>
                            <span class="help-block">
        <p class="alert alert-danger">
        <strong>Ուշադրություն!</strong> Լրացնել նկարագրության դաշտը.
        </p>
        </span>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="input-1">price new</label>
                            <input type="number" name="price_new" class="form-control"
                                   value="{{$product->price_new}}" id="input-1"
                                   placeholder="@lang('lang.price')">
                        </div>
                        <div class="col-6">
                            <label for="input-1">Old % price</label>

                            <input type="number" name="price_old" class="form-control"
                                   value="{{$product->price_old}}" id="input-1"
                                   placeholder="@lang('lang.price') Old Price Դ">
                        </div>
                        <p>Վարկանիշ</p>
                        <select id="example-fontawesome" name="stars" autocomplete="off">
                            @if($product->stars==1)
                                <option value="1" selected>1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            @elseif($product->stars==2)
                                <option value="1">1</option>
                                <option value="2" selected>2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>

                            @elseif($product->stars==3)
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3" selected>3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            @elseif($product->stars==4)
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4" selected>4</option>
                                <option value="5">5</option>
                            @elseif($product->stars==5)

                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5" selected>5</option>



                            @endif
                        </select>


                        <div class="form-group">
                            <label>Images</label>
                            <input class="form-control" type="file" name="images" value="">

                        </div>
                        <input type="hidden" name="product_id" value="{{$product->product_id}}">
                        <input class="form-control" type="hidden" name="imgs" value="{{$product->images}}">





                        <input type="hidden" name="product_id" value="{{$product->product_id}}">
                        <div class="form-group">
                            <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i>Հաստատել
                            </button>
                        </div>

                    </form>

                    <div class="form-group">
                        <img src="{{asset('myproduct/'.$product->images)}}" alt=""></div>
                </div>
            </div>
        </div>
    </div>










@endsection
@section('js')

    <script>

        $('.folders').change(function () {
            var folder = $(this).val();

            $.ajax({
                type:'get',
                url:'{{url('Product/Folders')}}/'+folder,
                data:'_token = <?php echo csrf_token() ?>',
                dataType : 'html',
                contentType: false,
                processData: false,

                success:function(data) {
                    $(".mydish").html(data);
                    $(".oldmenu,.oldmenus ").remove().hide();

                }
            });




        });



    </script>

    <script>
        $(document).ready(function () {
            $('.menu').change(function () {
                var id = $(this).val();

                $.ajax({
                    type: 'get',
                    url: '{{url('/Menu/Selects/')}}/' + id,
                    data: '_token = <?php echo csrf_token() ?>',
                    dataType: 'html',
                    contentType: false,
                    processData: false,

                    success: function (data) {
                        $(".listmenuchek").html(data);
                    }
                });


            });
            $('.filteritem').change(function () {
                var folder = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('Itemfilter')}}/'+folder,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".myfilter").html(data);
                    }
                });




            });
        });

    </script>



@endsection

