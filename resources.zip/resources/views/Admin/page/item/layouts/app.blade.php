@include('Admin.include.header')
<style>
    .inputborder{
        border: 1px solid black;
    }
</style>

    <!-- Side Menu Area -->


    <!-- Layout Container -->


        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('index')}}">Գլխավոր</a></li>
                        <li class="breadcrumb-item"><a href="{{route('Items.index')}}">Ապրանքատեսակ</a></li>

                    </ol>
                </nav>
            </div>
        </div>

        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="inbox--area bg-boxshadow mb-50">
                            <div class="row">
                                <div class="col-12 col-lg-3">
                                    <div class="ibox mb-50">
                                        <div class="ibox-content mailbox-content">
                                            <div class="file-manager">

                                                <a class="btn btn-block btn-primary compose-mail" href="{{route('Items.create')}}">Ավելացնել Ապրանքատեսակ</a>

                                                <!-- Title -->

                                                <div class="folder-title mt-30">

                                                </div>

                                                <ul class="folder-list">
                                                    <li><a href="{{route('Items.index')}}"> <i class="fa fa-reply-all "></i> Բոլոր ապրանքները </a></li>
                                                    <li><a href="{{route('allproductss','best')}}"> <i class="fa fa-street-view"></i>Լավագույն ապրանքները </a></li>
                                                    <li><a href="{{route('allproductss','new')}}"> <i class="fa fa-hacker-news"></i>Նոր ապրանքները </a></li>
                                                    <li><a href="{{route('allproductss','alls')}}"> <i class="fa fa-bell"></i>Բոլոր առիթների համար </a></li>
                                                    <li><a href="{{route('allproductss','my')}}"> <i class="fa fa-file-text-o"></i> Իմ ապրանքները  <span class=" inbox float-right"></span></a></li>
                                                  <li><a href="{{route('trashs')}}"> <i class="fa fa-trash-o"></i> Inactive</a></li>
                                                </ul>

                                                <!-- Title -->
                                                <div class="categori-title mt-30">
                                                    <h6>Ընկերություներ</h6>
                                                </div>
                                                <!-- List -->
                                                <?php $category=\App\Models\FoodMarket::get(); ?>
                                                <ul class="category-list" style="padding: 0">
                                                    @foreach($category as $categories)

                                                    <li><a href="{{route('Items.show',$categories->id)}}"> <i class="fa fa-circle text-danger"></i>{{$categories->market_name_am}}</a></li>

                                              @endforeach
                                                </ul>
                                                <div class="clearfix"></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
  <div class="col-9 col-lg-9">
                                @yield('content')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




@include('Admin.include.footer')
