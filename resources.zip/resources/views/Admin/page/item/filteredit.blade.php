@extends('Admin.page.item.layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('assets/vendors/iconfonts/font-awesome/css/font-awesome.min.css')}}">

@endsection
@section('content')
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">@lang('lang.Add')</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">@lang('admin.home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">

                        </li>
                    </ol>
                </div>
            </div>


            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">

                            <div class="modal-body">
                                <form action="{{route('search_filter')}}" method="post">
                                    @csrf



                                    <div class="form-group">
                                        <input type="text" name="search">
                                    </div>
                                    <input type="hidden" value="{{$id}}" name="item">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-light px-5"><i class="icon-search"> </i> Որոնել</button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>



                <div class="card-body">
                    <h4 class="card-title">Ապրանքատեսակներ</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>վերնագիր</th>
                                    <th>Լուսանկար</th>
                                    <th>Աելացնել</th>

                                </tr>
                                </thead>
                                @if(isset($details))

                                    <h3 class="catHeaderText"> {{ $query }}</h3>
                                    <tbody>
                                    @foreach($data as $restaurants)
                                        <?php $product=\App\Models\Product::find($restaurants->product_id)?>
                                        <tr>
                                            <td>{{$restaurants->product_id}}</td>
                                            <td>{{$restaurants->title_am}}</td>
                                            <td><img style="width: 80px" src="{{asset('myproduct/'.$product->images)}}" alt="...">
                                            </td>
                                            <form action="{{route('filteraddsearch',$restaurants->product_id)}}" method="post" enctype="multipart/form-data">

                                                @csrf

                                                <td>
                                                    <input type="hidden" value="{{$id}}" name="item">
                                                <select  class="oldmenu" name="filter_id" style=" border-radius: 15px; box-shadow: 2px 3px #FF5F00;">

                                                    @foreach($filt as $menus)

                                                        <option value="{{$menus->id}}" data-ids="{{$menus->id}}">{{$menus->size}}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td>
                                                <button type="submit" class="badge badge-info" onclick="location.href='{{route('Items.edit',$product->id)}}'">Ավելացնել</button>
                                            </td>
                                            </form>
                                        </tr>
                                    @endforeach
                                    </tbody>

                                @else


                                @endif
                            </table>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>




@endsection
@section('js')



    <script>
        $(document).ready(function () {
            $('.filteritem').change(function () {
                var folder = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('Itemfilter')}}/'+folder,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".myfilter").html(data);
                    }
                });




            });

        });

    </script>

@endsection
