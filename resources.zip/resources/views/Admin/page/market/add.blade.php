@extends('Admin.page.market.layouts.app')
@section('content')


    <div class="col-12 col-lg-10">
    @if(session('okeys'))
        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

    @endif
    <form method="POST" action="{{route('market.store')}}" enctype="multipart/form-data">
        @csrf
        <label for="background" style="cursor: pointer"><img src="https://amp.businessinsider.com/images/55c4ad8f371d222e008bdca6-1920-960.jpg" style="width: 100%; height: 250px;" alt=""></label>
        <input type="file" name="background" id="background" style="display: none">
@if(session()->has('er'))
    <strong style="color:red;">Հիմի լրացրեք դաշտերը ճիշտ և նշեք կատեգորիաի հասցեն հակառակ դեպքում ելի չի հաստատվի ձեր ավելացումը</strong>
    @endif
        <br>
        <select name="category_id">
            <option value="0">Ընտրել</option>

            @foreach($category as $categores)
                <option value="{{$categores->cat_id}}">{{$categores->cat_name_am}}</option>
            @endforeach
        </select>
        Գլխավոր:<input type="checkbox" name="view" value="active">
        <div class="form-group">
            <label for="input-1">@lang('admin.title_am')</label>
            <input type="text" name="name_am" class="form-control" id="input-1" placeholder="@lang('admin.title_am')">
        </div>
        <div class="form-group">
            <label for="input-2">@lang('admin.title_ru')</label>
            <input type="text" name="name_ru" class="form-control" id="input-2" placeholder="@lang('admin.title_ru')">
        </div>
        <div class="form-group">
            <label for="input-6">@lang('admin.title_en')</label>
            <input type="text" name="name_en" class="form-control" id="input-6" placeholder="@lang('admin.title_en')">
        </div>
        <div class="form-group">
            <label for="input-4">Հասցե</label>
            <input type="text" name="addres" class="form-control" id="input-4" placeholder="Հասցե">
        </div>
        <div class="form-group">
            <label for="input-8">Առաքման ժամանակահտված</label>
            <input type="text" name="delivery" class="form-control" id="input-8" placeholder="Առաքման ժամանակահտված">
        </div>
        <div class="form-group">
            <label for="input-9">Առաքման գումար</label>
            <input type="text" name="price" class="form-control" id="input-9" placeholder="Առաքման գումար">
        </div>
        <div class="form-group">
            <label for="input-10">Հեռ․</label>
            <input type="text" name="tel" class="form-control" id="input-10" placeholder="Հեռ․">
        </div>


        <div class="form-group">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text"></span>
                </div>
                <br>
                <div class="custom-file">
                    <input type="file" name="logo" class="custom-file-input" id="lusa">
                    <label class="custom-file-label" for="lusa">@lang('lang.addimg')</label>
                </div>
            </div></div>

        <div class="form-group">
            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
        </div>
    </form>
</div>
    @endsection
