@extends('Admin.layouts.app')
@section('content')

    <div class="content-wrapper">
        <div class="container-fluid">



            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title"></h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">@lang('admin.home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            @lang('admin.Sections')
                        </li>
                    </ol>
                </div>
                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif


                <div class="btn-group float-sm-right">
                    <!-- Large Size Modal -->
                    <button class="btn btn-light btn-block m-4" data-toggle="modal" data-target="#formemodal">@lang('lang.AddaStatement')</button>
                    <!-- Modal -->
                    <div class="modal fade" id="formemodal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">@lang('lang.AddaStatement')</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    @if(session('okeys'))
                                        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                    @endif
                                    <form method="POST" action="{{ route('Submenu.store') }}" enctype="multipart/form-data">
                                        @csrf
                                        <div class="form-group">
                                            <label for="input-1">@lang('admin.title_am')</label>
                                            <input type="text" name="name_am" class="form-control" id="input-1" placeholder="Վերնագիր Հայերեն">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-2">@lang('admin.title_ru')</label>
                                            <input type="text" name="name_ru" class="form-control" id="input-2" placeholder="Վերնագիր Ռուսերեն">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-3">@lang('admin.title_en')</label>
                                            <input type="text" name="name_en" class="form-control" id="input-3" placeholder="Վերնագիր Անգլերեն">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-3">@lang('admin.title_es')</label>
                                            <input type="text" name="name_es" class="form-control" id="input-3" placeholder="Վերնագիր Իսպաներեն">
                                            <input type="hidden" name="section_id" value="">
                                        </div>
                                        <div class="form-group">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
                                                </div>
                                                <br>
                                                <div class="custom-file">
                                                    <input type="file" name="img" class="custom-file-input" id="lusa">
                                                    <label class="custom-file-label" for="lusa">@lang('lang.addimg')</label>
                                                </div>
                                            </div></div>

                                        <div class="form-group">
                                            <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i> @lang('lang.Add')</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- End Breadcrumb-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card ">
                        <div class="card-header"><i class="fa fa-table"></i>@lang('lang.To date') {{$sectionitem->count()}} @lang('admin.Sections')</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="default-datatable" class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>@lang('admin.title_'.session('locale'))</th>
                                        <th>img</th>
                                        <th>update || delete</th>

                                    </tr>
                                    </thead>
                                    <tbody>

                                    @foreach($sectionitem as $item)
                                        <tr data-id="{{$item->id}}">
                                            <td>{{$item->{'name_'.session('locale')} }}</td>
                                            <td><img src="{{asset('storage/category/'.$item->img)}}" style="width:50px;" alt=""></td>
                                            <td>
                                                <a href="{{route('Submenu.edit',$item->id)}}"><i aria-hidden="true" class="fa fa-edit"></i> <span class="sr-only"></span>Edit</a> || <i aria-hidden="true" class="fa fa-remove" id="ct_del"  style="cursor: pointer;"  data-start="{{$item->id}}" data-toggle="modal"
                                                                                                                                                                                        data-target="#delete{{$item->id}}"
                                                                                                                                                                                        data-ctid="{{route('Submenu.destroy', $item->id)}}"> remove</i></td>

                                        </tr>
                                    @endforeach
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>@lang('admin.title_'.session('locale'))</th>
                                        <th>img</th>
                                        <th>update || delete</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal-->
            <!-- Modal delete-->
            @foreach($sectionitem as $item)
                <div class="modal fade mymodal" id="delete{{$item->id}}">
                    <div class="modal-dialog">
                        <div class="modal-content border-danger">
                            <div class="modal-header bg-danger">
                                <h3><i class="glyphicon glyphicon-thumbs-up"></i>@lang('lang.Iagree')</h3>
                                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            {{$item->name_am}}
                            {{$item->id}}
                            <div class="modal-footer">
                                <a href="{{url('Section/Submenu/'.$item->id)}}" class="dell  btn btn-default pull-right ">@lang('lang.Yes')</a>

                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">@lang('lang.No')
                                </button></div>
                        </div>
                    </div>
                </div>
            @endforeach


        </div>
        <!-- End container-fluid-->

    </div><!--End content-wrapper-->
    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->




@endsection
@section('js')
    <script>
        $(document).ready(function () {
            $('#ct_del').click(function () {

                var url = $(this).data('ctid');

                id = $(this).data('start');
                $(".dell").attr('href', url);

            });
            $(".dell").click(function (event) {
                event.preventDefault();
                var url = $(this).attr('href');
                var token = $('input[name="_token"]').val();
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    data: {_token: token},
                    success: function (data) {
                        if (data == 1) {
                            $('tr[data-id="' + id + '"]').fadeOut().remove();

                        } else {
                            alert('ok');
                        }

                        $('#delete'+id).modal('hide');


                    }
                })


            });
        });
    </script>
@endsection
