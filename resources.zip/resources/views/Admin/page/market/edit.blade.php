
@extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="col-sm-9">
                <h4 class="page-title">   @lang('admin.Sections')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{route('market.index')}}">@lang('admin.market')</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        {{$foodMarket->market_name_am}}
                    </li>


                </ol>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">
                            @if(session('okey'))
                                <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր փոփոխությունը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                            @endif
                            <form action="{{route('market.update',$foodMarket->id)}}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <label for="background" style="cursor: pointer"><img src="{{asset('foodname/'.$foodMarket->background)}}" style="width: 100%; height: 250px;" alt=""></label>
                                <input type="file" name="background" id="background" style="display: none">
                                @if($foodMarket->view=='active')
                                    Գլխավոր:<input type="checkbox" name="view" value="active" checked>
                                @else
                                    Գլխավոր:<input type="checkbox" name="view" value="active">
                                @endif
                                <div class="form-group">
                                    <h6>Ինչի մեջ երեվա</h6>

                                    <select name="category_id">

                                        <option value="{{$category_id->cat_id}}" selected hidden>{{$category_id->cat_name_am}}</option>
                                        @foreach($category as $categores)
                                            <option value="{{$categores->cat_id}}">{{$categores->cat_name_am}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="input-1">@lang('admin.title_am')</label>
                                    <input type="text" name="market_name_am" value="{{$foodMarket->market_name_am}}" class="form-control" id="input-1" placeholder="{{$foodMarket->market_name_am}}">
                                </div>
                                <div class="form-group">
                                    <label for="input-2">@lang('admin.title_ru')</label>
                                    <input type="text" name="market_name_ru" value="{{$foodMarket->market_name_ru}}" class="form-control" id="input-2" placeholder="{{$foodMarket->market_name_ru}}">
                                </div>
                                <div class="form-group">
                                    <label for="input-3">@lang('admin.title_en')</label>
                                    <input type="text" name="market_name_en" class="form-control" value="{{$foodMarket->market_name_en}}" id="input-3" placeholder="{{$foodMarket->market_name_en}}">
                                </div>


                                    <div class="form-group">
                                        <label for="input-3">Հասցե</label>
                                        <input type="text" name="addres" class="form-control" value="{{$foodMarket->addres}}" id="input-3" placeholder="Հասցե">
                                    </div>
                                <div class="form-group">
                                    <label for="input-8">Առաքման ժամանակահտված</label>
                                    <input type="text" name="delivery" class="form-control" value="{{$foodMarket->delivery}}" id="input-8" placeholder="Առաքման ժամանակահտված">
                                </div>
                                <div class="form-group">
                                    <label for="input-9">Առաքման գումար</label>
                                    <input type="text" name="price" class="form-control" value="{{$foodMarket->price}}" id="input-9" placeholder="Առաքման գումար">
                                </div>
                                    <div class="form-group">
                                        <label for="input-3">Հեռ․</label>
                                        <input type="text" name="tel" class="form-control" id="input-3" value="{{$foodMarket->tel}}" placeholder="Հեռ․">
                                    </div>

                                <div class="row">
                                        <h6> Աշխատաժամերը</h6>
                                    <?php $datas=\App\Models\Dateworkcompany::where('market_id',$id)->get();?>

                                    @if(!count($datas)>0)
                                    @foreach($date as $week)

                                    <div class="col-md-1" >
                                        <br>
                                        <label for="input-3">{{$week->week_am}}</label>
                                        <br>
                                        <input type="time" name="start_{{$week->week_en}}" value="{{$foodMarket->start_date??null}}" placeholder="Աշխատաժամերի սկիզբ․">
                                        <input type="time" name="end_{{$week->week_en}}"  value="{{$foodMarket->end_date??null}}" placeholder="Աշխատաժամեր ավարտ">
                                        <br>
                                       Փակ է: <input type="checkbox" name="close_{{$week->week_en}}" value="inactive">
                                      <input type="hidden" name="week_{{$week->week_en}}" value="{{$week->week_en}}">
                                    </div>
                                    @endforeach

                                    </div>
                                @else
                                    @foreach($dateweek as $week)

                                        <div class="col-md-1" >
                                            <br>
                                            <label for="input-3">{{$week->week_am}}</label>
                                            <br>
                                            <input type="time" name="start_{{$week->week_en}}" value="{{$week->start_date}}" placeholder="Աշխատաժամերի սկիզբ․">
                                            <input type="time" name="end_{{$week->week_en}}"  value="{{$week->end_date}}" placeholder="Աշխատաժամեր ավարտ">
                                            <br>
                                            @if($week->close=='inactive')
                                            Փակ է: <input type="checkbox" name="close_{{$week->week_en}}" value="inactive" checked>
                                            @else
                                                Փակ է: <input type="checkbox" name="close_{{$week->week_en}}" value="inactive">

                                                @endif

                                            <input type="hidden" name="week_{{$week->week_en}}" value="{{$week->week_en}}">
                                        </div>
                                    @endforeach



                                    @endif


                                <br>
                                <br>  <br>
                                <br>
                                    <div class="col-md-6 col-lg-3 col-xl-3">
                                        <img src="{{asset('foodname/'.$foodMarket->logo)}}" alt="lightbox" class="lightbox-thumb img-thumbnail">

                                    </div>
                                </div>
                        <div class="form-group">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
                                </div>
                                <br>

                                <div class="custom-file">
                                    <input type="hidden" name="images_old" value="{{$foodMarket->logo}}">
                                    <input type="file" name="file" class="custom-file-input" id="lusa" >
                                    <label class="custom-file-label" for="lusa">@lang('lang.change')</label>
                                </div>
                            </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ar"></i> @lang('lang.change')</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
