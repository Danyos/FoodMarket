@extends('Admin.layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('assets/vendors/iconfonts/font-awesome/css/font-awesome.min.css')}}">

@endsection
@section('content')
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <h4 class="page-title">@lang('lang.Add')</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">@lang('admin.home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">

                        </li>
                    </ol>
                </div>
            </div>


            <div class="row">
                <div class="col-lg-12">
                    <div class="card">

                        <div class="card-body">

                            <div class="modal-body">
                                @if(session('okeys'))
                                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">ХЂХЎХЅХїХЎХїХѕХҐЦЃ Х±ХҐЦЂ ХЎХѕХҐХ¬ХЎЦЃХёЦ‚ХґХЁ</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">Г—</span></div></div>
                                @endif
                                <ul class="navbar-nav d-none d-md-block">

                                </ul>
                                <form action="{{route('Market.update',$menu_market->menu_market_id)}}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    @method('PUt')
                                    <select  name="list_id"  required>

                                        <option hidden selected value="{{$menu_market->menu_list_id}}">{{$menu_market->list_name_am}}</option>

                                        @foreach($list as $listmenu)
                                            <option value="{{$listmenu->id}}">{{$listmenu->list_name_am}}</option>
                                        @endforeach
                                    </select>

                                    <select  name="category_id" class="menu" required>

                                        <option hidden selected value="{{$menu_market->section_id}}">{{$menu_market->name_am}}</option>

                                        @foreach($category as $categores)
                                            <option value="{{$categores->sections_id}}">{{$categores->name_am}}</option>
                                        @endforeach
                                    </select>



                                    <select  class="listmenu" name="food_menu_id">
                                        <option hidden selected value="{{$menu_market->food_menu_id}}">{{$menu_market->food_name_am}}</option>
                                    </select>










                                    <input type="hidden" name="market_id" value="{{$id}}">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-light px-5"><i class="icon-lock"></i>@lang('lang.change')</button>
                                    </div>
                                          </form>
                            </div>
                        </div>
                    </div>
                </div>






            </div>
        </div>
    </div>




@endsection
@section('js')

    <script src="{{asset('assets/js/form-addons.js')}}"></script>


    <script>
        $(document).ready(function () {
            $('.menu').change(function () {
                var id = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('/Menu/Select/')}}/'+id,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".listmenu").html(data);
                    }
                });




            });

        });

    </script>
@endsection

