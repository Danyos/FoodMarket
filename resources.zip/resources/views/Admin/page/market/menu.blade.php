@extends('Admin.layouts.app')
@section('content')


    @extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">

            <div class="card">
                <div class="btn-group float-sm-right">
                    <!-- Large Size Modal -->
                    <button class="btn btn-light btn-block m-4" data-toggle="modal" data-target="#formemodal">@lang('lang.Add') @lang('admin.Sections')</button>
                    <!-- Modal -->
                    <div class="modal fade" id="formemodal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">@lang('lang.Add') @lang('admin.Sections')</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    @if(session('okeys'))
                                        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                    @endif
                                    <form method="POST" action="{{route('Market.store')}}" enctype="multipart/form-data">
                                        @csrf
                                        <select  name="category_id"  required class="menu">
                                            <option hidden selected>Ընտրել</option>
                                            @foreach($category as $categories)
                                                <option value="{{$categories->sections_id}}" data-ids="{{$categories->sections_id}}">{{$categories->name_am}}</option>
                                            @endforeach

                                        </select>
                                        <select  class="listmenu" name="food_menu_id">

                                        </select>
                                        <input type="hidden" name="market_id" value="{{$market_id->market_id}}">

                                            <input type="hidden" name="menu_list_id" class="form-control" value="{{$id}}" id="input-1" placeholder="@lang('admin.title_am')">



                                        <div class="form-group">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"></span>
                                                </div>
                                                <br>
                                                <div class="custom-file">

                                                </div>
                                            </div></div>

                                        <div class="form-group">
                                            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif
                <div class="card-body">
                    <h4 class="card-title">Մենյու</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Menu</th>
                                    <th>Market</th>
                                    <th>Section</th>
                                    <th>Category</th>

                                    {{--                                    <th>images</th>--}}
                                    <th>update || delete</th>
                                    <th>view</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($menumarket as $menuFood)

                                    <tr>
                                        <td>{{$menuFood->menu_market_id}}</td>
                                        <td>{{$menuFood->food_name_am}}</td>
                                        <td>{{$menuFood->market_name_am}}</td>
                                        <td>{{$menuFood->list_name_am}}</td>
                                        <td>{{$menuFood->name_am}}</td>

                                        {{--                                    <td><img src="{{asset('myitem/'.$menuFood->img)}}" alt=""></td>--}}
                                        <td>
                                            <label class="badge badge-info" onclick="location.href='{{route('Market.edit',$menuFood->menu_market_id)}}'">edit</label> ||
                                            <label class="badge badge-info">Delete</label>
                                        </td>
                                        <td>

                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection



@endsection
@section('js')

    <script src="{{asset('assets/js/form-addons.js')}}"></script>

    <script>
        $(document).ready(function () {
            $('.menu').change(function () {
                var id = $(this).val();

                $.ajax({
                    type:'get',
                    url:'{{url('/Menu/Select/')}}/'+id,
                    data:'_token = <?php echo csrf_token() ?>',
                    dataType : 'html',
                    contentType: false,
                    processData: false,

                    success:function(data) {
                        $(".listmenu").html(data);
                    }
                });




            });

        });

    </script>
@endsection
