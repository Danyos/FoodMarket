@extends('Admin.layouts.app')
@section('content')
    <style>
        .fd{
            display: block;
        }
    </style>

    @if($restaurant!=null)
        <div class="row">
            <div class="col-12">
                <div class="appwork-faq-area bg-boxshadow">
                    <table class="table">
                        @foreach($restaurant as $listmils)
                            <thead>
                        <tr>
                            <th>{{$listmils->name_am}}</th></tr>
                            </thead>
                        <tbody>
                        <?php $men=\App\MenuFood::where('section_id',$listmils->sections_id)->get()?>
                        @foreach($men as $main)



                        <tr style="">
                            <td><a href="{{url('food/menu/product/show'.$main->id.'/'.$id)}}" class="footer-link color-black">{{$main->{'food_name_'.session('locale')} }}</a>
                            </td>
                        </tr>
                    @endforeach
                        </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
        @endif
<div class="mb-70"></div>
        <script>
            $('.ok:first').addClass("fd");
        </script>
@endsection
