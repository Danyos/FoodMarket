@extends('Admin.page.market.layouts.app')
@section('content')



    <div class="col-12 col-lg-10">

                <!-- Title -->
                <div class="inbox-title mb-15">
                    <h2>@lang('admin.market')</h2>
                </div>
        @if(session('error'))
            <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

        @endif

                <div class="table-responsive">
                    <table class="table table-dark">
                        <thead>
                        <tr>
                            <th>
                                #
                            </th>
                            <th>
                           Անուն
                            </th>
                            <th>
                                Լուսանկար
                            </th>
                            <th>
                            Գործող
                            </th>
                            <th>
                            Ժամ
                            </th>


                            <th>
                               Փոփոխել || Տեսնել մենյուն
                            </th>

                        </tr>
                        </thead>
                        <tbody>
                        @foreach($foodMarket as $market)
                        <tr>
                            <td>
                                {{$market->id}}
                            </td>
                            <td>
                                <a href="{{route('marketlistselect',$market->id)}}">{{$market->market_name_am}}</a>
                            </td>

                            <td><img src="{{asset('foodname/'.$market->logo)}}" style="width: 50px;" alt=""></td>
                            @if($market->type=='active')
                                <form action="{{route('typemarket',$market->id)}}" method="post">
                                    @csrf
                                    <input type="hidden" name="type" value="inactive">
                                <td onclick="submit()">
                                    <button type="submit" class="badge badge-success" >{{$market->type}}</button>
                                </td>
                                </form>
                            @else
                                <form action="{{route('typemarket',$market->id)}}" method="post">
                                    @csrf
                                    <input type="hidden" name="type" value="active">
                                <td onclick="submit()">
                                    <button class="badge badge-warning" type="submit">{{$market->type}}</button>
                                </td>
                                </form>
                            @endif
                            <td>
                                {{$market->created_at->format('Y-M-d')}}
                            </td>
                            <td>
                                <label class="badge badge-info" onclick="location.href='{{route('market.edit',$market->id)}}'">Փոփոխել</label> ||
                                <label class="badge badge-info" onclick="location.href='{{route('viewmenu',$market->id)}}'">Տեսնել մենյուն</label>
                            </td>

                        </tr>
             @endforeach
                        </tbody>
                    </table>
                </div>
            </div>



@endsection
