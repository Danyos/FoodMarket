@include('Admin.include.header')
<style>
    .inputborder{
        border: 1px solid black;
    }
</style>

    <!-- Side Menu Area -->


    <!-- Layout Container -->


        <!-- Breadcrumb Area -->
        <div class="breadcrumb-area">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">

                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">  @lang('admin.home')</a></li>
                        <li class="breadcrumb-item"><a href="#">Ընկերություներ</a></li>

                </nav>
            </div>
        </div>

        <!-- Wrapper -->
        <div class="wrapper wrapper-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="inbox--area bg-boxshadow mb-50">
                            <div class="row">
                                <div class="col-12 col-lg-2">
                                    <div class="ibox mb-50">
                                        <div class="ibox-content mailbox-content">
                                            <div class="file-manager">

                                                <button class="btn btn-block btn-primary" onclick="location.href='{{route('market.create')}}'">@lang('lang.Add') ընկերություն</button>


                                                <!-- Title -->
                                                <div class="categori-title mt-20">
                                                    <h6>Ընկերություներ</h6>
                                                </div>
                                                <!-- List -->
                                                <?php $category=\App\Models\Category::get(); ?>
                                                <ul class="category-list" style="padding: 0">
                                                    @foreach($category as $categories)
                                                    <li><a href="{{route('market.show',$categories->cat_id)}}"> <i class="fa fa-circle text-danger"></i>{{$categories->cat_name_am}}</a></li>
                                              @endforeach
                                                </ul>
                                                <div class="clearfix"></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @yield('content')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




@include('Admin.include.footer')
