
@extends('Admin.layouts.app')
@section('content')

<div class="main-panel">
    <div class="content-wrapper">

    <div class="row">
        <div class="col-lg-12">
            <div class="card">

                <div class="card-body">
                    @if(session('okey'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր փոփոխությունը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                        @endif
                        <form action="{{route('Category.update',$category->cat_id)}}" method="post" enctype="multipart/form-data">
@csrf
                            @method('PUT')
                        <div class="form-group">
                            <label for="input-1">@lang('admin.title_am')</label>
                            <input type="text" name="name_am" value="{{$category->cat_name_am}}" class="form-control" id="input-1" placeholder="{{$category->name_am}}">
                        </div>
                        <div class="form-group">
                            <label for="input-2">@lang('admin.title_ru')</label>
                            <input type="text" name="name_ru" value="{{$category->cat_name_ru}}" class="form-control" id="input-2" placeholder="{{$category->name_ru}}">
                        </div>
                        <div class="form-group">
                            <label for="input-3">@lang('admin.title_en')</label>
                            <input type="text" name="name_en" class="form-control" value="{{$category->cat_name_en}}" id="input-3" placeholder="{{$category->name_en}}">
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
                                </div>
                                <br>

                                <div class="custom-file">
                                    <input type="hidden" name="images_old" value="{{$category->img}}">
                                    <input type="file" name="file" class="custom-file-input" id="lusa" >
                                    <label class="custom-file-label" for="lusa">@lang('lang.addimg')</label>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-3 col-xl-3">
                                <img src="{{asset('myitem/'.$category->img)}}" alt="lightbox" class="lightbox-thumb img-thumbnail">

                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ar"></i> @lang('lang.Add')</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    @stop
