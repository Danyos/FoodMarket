
@extends('Admin.layouts.app')
@section('content')

    <div class="main-panel">
        <div class="content-wrapper">
            @if(session('error'))
                <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

            @endif
            <div class="card">
                <div class="btn-group float-sm-right">
                    <!-- Large Size Modal -->
                    <button class="btn btn-light btn-block m-4" data-toggle="modal" data-target="#formemodal">@lang('lang.Add') @lang('admin.Sections')</button>
                    <!-- Modal -->
                    <div class="modal fade" id="formemodal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">@lang('lang.Add') @lang('admin.Sections')</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    @if(session('okeys'))
                                        <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                                    @endif
                                    <form method="POST" action="{{route('Category.store')}}" enctype="multipart/form-data">
                                        @csrf
                                        <div class="form-group">
                                            <label for="input-1">@lang('admin.title_am')</label>
                                            <input type="text" name="name_am" class="form-control" id="input-1" placeholder="@lang('admin.title_am')">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-2">@lang('admin.title_ru')</label>
                                            <input type="text" name="name_ru" class="form-control" id="input-2" placeholder="@lang('admin.title_ru')">
                                        </div>
                                        <div class="form-group">
                                            <label for="input-3">@lang('admin.title_en')</label>
                                            <input type="text" name="name_en" class="form-control" id="input-3" placeholder="@lang('admin.title_en')">
                                        </div>

                                        <div class="form-group">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"></span>
                                                </div>
                                                <br>
                                                <div class="custom-file">
                                                    <input type="file" name="file" class="custom-file-input" id="lusa">
                                                    <label class="custom-file-label" for="lusa">@lang('lang.addimg')</label>
                                                </div>
                                            </div></div>

                                        <div class="form-group">
                                            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @if(session('okeys'))
                    <div class="lobibox-notify-wrapper top right alerts"><div class="lobibox-notify lobibox-notify-success animated-fast fadeInDown notify-mini rounded" style="width: 400px;"><div class="lobibox-notify-icon-wrapper"><div class="lobibox-notify-icon"><div><div class="icon-el"><i class="fa fa-check-circle"></i></div></div></div></div><div class="lobibox-notify-body"><div class="lobibox-notify-msg" style="max-height: 32px;">Հաստատվեց ձեր ավելացումը</div></div><span class="lobibox-close" onclick="$('.alerts').hide();">×</span></div></div>

                @endif
                <div class="card-body">
                    <h4 class="card-title">Data table</h4>
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table id="order-listing" class="table">
                                <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Title arm</th>
                                    <th>Title rus</th>
                                    <th>title en</th>
                                    <th>images</th>
                                    <th>update || delete</th>
                                    <th>view</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($category as $categories)
                                <tr>
                                    <td>{{$categories->cat_id}}</td>
                                    <td>{{$categories->cat_name_am}}</td>
                                    <td>{{$categories->cat_name_ru}}</td>
                                    <td>{{$categories->cat_name_en}}</td>
                                    <td style="background-color: #FF5F00;"><img src="{{asset('myitem/'.$categories->img)}}" style="width: 80px;" alt=""></td>
                                    <td>
                                        <label class="badge badge-info" onclick="location.href='{{route('Category.edit',$categories->cat_id)}}'">edit</label> ||
                                        <label class="badge badge-info">Delete</label>
                                    </td>

                                </tr>
                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    @endsection

@section('js')
    <script>
        $('.pdoductdestroybutton').click(function(){

            var r = confirm("Ջնջե՞լ ապրանքը");
            if (r == true) {
                $(this).attr('type','submit');
            } else {
            }
        })
    </script>
@endsection
