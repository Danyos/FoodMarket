@extends('Admin.layouts.app')
@section('content')



    <div class="col-12 col-lg-10">

        <!-- Title -->
        <div class="inbox-title mb-15">
            <h2>Փոխարժեք</h2>
        </div>


        <div class="table-responsive">
            <table class="table table-dark">
                <thead>
                <tr>


                    <th>
                      Usd
                    </th>
                    <th>
                   RUB
                    </th>


                    <th>
                    Edit
                    </th>
                </tr>
                </thead>
                <tbody>

                    <tr>

                        <td>
                            <a>{{$Currency->USD}}</a>
                        </td>


                        <td>
                            <a>{{$Currency->RUB}}</a>
                        </td>

                        <td>
                            <label class="badge badge-info" data-toggle="modal" data-target="#formemodal">EDIT</label>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
    <div class="mb-150"></div>

    <div class="modal fade" id="formemodal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">@lang('lang.change') Փոխարժեք</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">

                    <form method="POST" action="{{route('priceupdates')}}" enctype="multipart/form-data">
                        @csrf


                        <div class="form-group">
                            <label for="input-9">Փոխարժեք USD</label>
                            <input type="text" name="USD" class="form-control" id="input-9" value="{{$Currency->USD}}" placeholder="USD">
                        </div>
                        <div class="form-group">
                            <label for="input-10">Փոխարժեք RUB</label>
                            <input type="text" name="RUB" class="form-control" value="{{$Currency->RUB}}" id="input-10" placeholder="RUB">
                        </div>




                        <div class="form-group">
                            <button type="submit" class="btn btn-light px-5"><i class="flag-icon-ne"></i> @lang('lang.change')</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
