@extends('Admin.layouts.app')
@section('content')


    <div class="main-panel">
        <div class="content-wrapper">
            <div class="col-sm-9">
                <h4 class="page-title">   @lang('admin.Sections')</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="">  @lang('admin.home')</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                      Ընկերություներ
                    </li>


                </ol>
                @if(session('msg'))
                    <strong style="color: red;">Չհաստատվեց ձեր ավելացումը</strong>

                @endif
            </div>
            <div class="card">
                <div class="btn-group float-sm-right">

                    <button class="btn btn-light btn-block m-4" data-toggle="modal" data-target="#formemodal">@lang('lang.Add') ընկերություն</button>
                    <!-- Modal -->
                    <div class="modal fade" id="formemodal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">@lang('lang.Add') ընկերություն</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">

                                    <form method="POST" action="{{route('MenuRestoran.store')}}" enctype="multipart/form-data">
                                        @csrf

                                        <select name="food_markets">
                                            <option value="0">Ընտրել</option>
                                            @foreach($food_markets as $foodmarkets)
                                            <option value="{{$foodmarkets->cat_id}}">{{$foodmarkets->cat_name_am}}</option>
                                            @endforeach
                                        </select>

                                        <select name="" class="menu">
                                            <option value="0">Ընտրել</option>
                                            @foreach($folder as $folders)
                                            <option value="{{$folders->id}}">{{$folders->folder}}</option>
                                            @endforeach
                                        </select>
                                        <div class="listmenuchek"></div>
                                        <div class="row">



                                            <button type="submit" class=""><i class="flag-icon-ne"></i> @lang('lang.Add')</button>
                                        </div>
                                        <br>

                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                        <br>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @if(session('ok'))
                    <strong style="color: green;">Հաստատվեց ձեր ավելացումը</strong>
                @endif

                    <div class="row">



    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">@lang('admin.market')</h4>
                <div class="table-responsive">
                    <table class="table table-dark">

                        <tbody>

                        @foreach($MenuRestoran as $MenuRestorans)
                            <details>




        <summary>   {{$MenuRestorans->cat_name_am}}
            </summary>

        @foreach($MenuRestorans->rstoran as $menu)
                                    <form action="{{route('MenuRestoran.destroy',$menu->menu_markets)}}" method="post" style="">
                                        @method('DELETE')
                                        @csrf
                                        <input type="hidden" name="cat_id" value="{{$MenuRestorans->cat_id}}">
                                        <button type="submit" id="del{{$MenuRestorans->cat_id}}" class="btn btn-danger btn-sm">
                                            Delete</button>
                                    </form>
<?php $section=\App\Models\Section::where('sections_id',$menu->menu_markets)->get()?>

        @foreach($section as $menu_markets)

    <label class="badge badge-info">{{$menu_markets->name_am}}</label>


@endforeach

@endforeach

    </details>


                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
                    </div>
                    </div>
                    </div>


@endsection
        @section('js')



                <script>
                    $(document).ready(function () {
                        $('.menu').change(function () {
                            var id = $(this).val();

                            $.ajax({
                                type:'get',
                                url:'{{url('/Menu/Folders/')}}/'+id,
                                data:'_token = <?php echo csrf_token() ?>',
                                dataType : 'html',
                                contentType: false,
                                processData: false,

                                success:function(data) {
                                    $(".listmenuchek").html(data);
                                }
                            });




                        });

                    });

                </script>

@endsection
