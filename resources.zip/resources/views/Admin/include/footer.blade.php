
</div>
</div>
<nav class="footer  bg-boxshadow " style="background-color:  #1f1f2c">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <p>
                    <img class="img1" style="width: 100px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">
                    <img class="img2" style="width: 100px;" alt="IDram" title="IDram3" src ="{{asset('asset/IMAGE/id.png')}}">
                    <img class="img" style="width: 30px;" alt="Cash" title="Cash" src ="{{asset('asset/IMAGE/md.png')}}">
                </p>
            </div>


                <div class="social_share_area wow fadeInUp" data-wow-delay="1.2s">
                    <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                </div>

        </div>

        <div class="row">
            <!-- Footer -->
            <div class="col-sm pb-3">
                <div class="footer-text color-white mb-2">ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</div>

          <a href="{{route('AboutUs')}}" class="footer-link color-white mb-2" title="">Մեր մասին</a>
             <a href="{{route('PrivacyPolicy')}}" class="footer-link color-white" title="">Գաղտնիության քաղաքականություն</a>

            </div>
            <!-- Footer -->
            <div class="col-sm pb-4">
                <div class="footer-text color-white mb-3">ՍՊԱՍԱՐԿՈՒՄ</div>
                <ul class="list-unstyled">
                    <li><a href="{{route('Jobs')}}" class="footer-link color-white" title="">Աշխատատեղեր</a></li>

                    <li><a href="{{route('CorporateClients')}}" class="footer-link color-white" title="">Կորպորատիվ հաճախորդներ</a></li>
                </ul>
            </div>
            <!-- Footer -->
            <div class="col-sm pb-4">
                <div class="footer-text color-white mb-3">ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</div>
                <ul class="list-unstyled">
                    <li><a href="{{route('DeliveryPrices')}}" class="footer-link color-white" title="">Առաքման գները և պայմանները</a></li>
                    <li><a href="{{route('Paymentmethods')}}" class="footer-link color-white" title="">Վճարման եղանակները և պայմանները</a></li>
                </ul>
            </div>
            <!-- Footer -->
            <div class="col-sm pb-4 ">
                <div class="footer-text color-white mb-3">ԿՈՆՏԱԿՏԱՅԻՆ ՏՎՅԱԼՆԵՐ</div>
                <ul class="list-unstyled">
                    <li><a title="" style="color: #fff;"><i class="fa fa-home" aria-hidden="true" style="color: #E95668;"></i>Տիգրան  Մեծի 18, Վանաձոր, Լոռի, Հայաստան</a></li>
                    <li><a title="" style="color: #25A3B1;"><i class="fa fa-envelope-o" aria-hidden="true" style="color: #E95668;"></i> info@fastfood.am</a></li>
                    <li><a title="" style="color: #fff;">
                            +374 (95) 84-85-81
                            <br>
                            +374 (91) 84-85-81
                        </a>
                    </li>

                </ul>
            </div>

        </div>
        <div class="col-lg-12 pb-6 mb-15 ">
            <ul align="center">

                <li><span style="color: #fff;">Copyright © 2019. fastfood.am</span></li>
                <li><span style="color: #fff;">By eargir.com</span></li>
            </ul>
        </div>
    </div>
</nav>
<!-- avart -->
</div>

</div>


<!-- jQuery 2.2.4 -->
<script src="{{asset('assets/assets/js/jquery/jquery.2.2.4.min.js')}}"></script>
<!-- Bootsrap js -->
@yield('js')

<script src="{{asset('assets/assets/js/bootstrap/popper.min.js')}}"></script>
<script src="{{asset('assets/assets/js/bootstrap/bootstrap.min.js')}}"></script>



<script src="{{asset('assets/js/plugins-js/classy-nav.js')}}"></script>

<!-- Footable js -->
<script src="{{asset('assets/js/plugins-js/product-list-js/footable.js')}}"></script>

<!-- Active js -->
<script src="{{asset('assets/js/active.js')}}"></script>
<script>
    /*$('.zang').click(function () {
        var id=$(this).data('id');
        $.ajax({
            type:'get',
            url:'{{url('ContactAdmin/update')}}/'+id,
            data:'_token = <?php /*echo csrf_token() */?>',
            dataType : 'html',
            contentType: false,
            processData: false,

            success:function(data) {
                $(".zanges"+id).fadeOut().remove();
            }
        });
    });*/


</script>

</body>


<!-- Mirrored from demo.designing-world.com/appwork-2.1.0/default-version/dashboard-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 30 Jul 2019 12:01:49 GMT -->
</html>
