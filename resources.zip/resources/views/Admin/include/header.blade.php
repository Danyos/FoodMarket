<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from demo.designing-world.com/appwork-2.1.0/default-version/dashboard-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 30 Jul 2019 12:01:48 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Colors">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>FastFood</title>

    <!-- Favicon -->
    <link rel="icon" href="{{asset('assets/img/core-img/favicon.jpg')}}">

    <!-- Footable Stylesheet -->
    <link rel="stylesheet" href="{{asset('assets/css/plugins/products-css/footable.css')}}">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="{{asset('assets/style.css')}}">

    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="{{asset('assets/css/responsive.css')}}">
    @yield('css')
</head>

<body>
<div class="page-wrapper">


    <!-- Page Top Bar Area -->
    <div class="page-top-bar-area d-flex align-items-center justify-content-between">

        <!-- Logo Trigger Area -->
        <div class="logo-trigger-area d-flex align-items-center">

            <!-- logo -->
            <a href="{{route('index')}}" class="logo">
                    <span class="big-logo" >
                        <img src="{{asset('asset/IMAGE/fast-corel x16.jpg')}}" alt="" style="border-radius:13px;width: 290px;">
                    </span>
                <span class="small-logo" style="border-radius:15px;">
                        <img src="{{asset('asset/IMAGE/fast-corel x16.jpg')}}" alt="" style="border-radius:15px; width: 90px;">
                    </span>
            </a>

            <!-- Trigger -->
            <div class="top-trigger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <!-- Top Search Bar -->
        <div class="top-search-bar">
            <form action="{{route('adminsearch')}}" method="post">
                @csrf
                <input type="search" name="search" class="top-search" placeholder="Որոնում...">
                <button type="submit"><i class="pe-7s-search"></i></button>

            </form>
        </div>
    <?php use App\Models\BuyShop;use App\Models\ProductShop;use App\Models\Section;$zang=\App\Models\ContactAdmin::where('status','inactive')->get() ?>
        <!-- User Meta -->
        <div class="user-meta-data d-flex align-items-center">
            <!-- Notifications -->
            <div class="topbar-notifications">
                <div class="noti--icon">{{count($zang)}}
                    <div class="active-status"> </div>
                    <img src="{{asset('assets/img/core-img/bell.png')}}" alt="">

                </div>
                <br>
                <!-- Notifications Data -->
                <div class="notifications-data">
                    <h6>{{count($zang)}}  Ցանկանումեն զանգահարեքիրենց</h6>
                    <!-- Notifications List Data -->
                    @foreach($zang as $zangs)
                    <a class="notification-list--data zang zangs{{$zangs->id}}" href="#" data-id="{{$zangs->id}}">
                        <!-- Notifications icon -->
                        <div class="notification-list-icon">
                            <i class="fa fa-phone bg-secondary" aria-hidden="true"></i>
                        </div>
                        <!-- Notifications Text -->

                        <div class="notification--list-body-text">
                            <h6>{{$zangs->title}}</h6>
                            <p>{{$zangs->msg}}</p>
                        </div>
                    </a>
  @endforeach
                    <div class="notification--all--list">
                        <a href="#">Ցույց տալ Ավելին</a>
                    </div>
                </div>
            </div>


            <!-- Profile -->
            <div class="topbar-profile">
                <!-- Thumb -->
                <div class="user---thumb">
                    <img src="{{asset('assets/img/core-img/favicon.jpg')}}" alt="">
                </div>
                <!-- Profile Data -->
                @if(auth()->user()->rolle!='company')
                <div class="profile-data">
                    <a class="profile-list--data" href="{{url('/logout')}}">
                        <!-- Profile icon -->
                        <div class="profile--list-icon">
                            <i class="fa fa-sign-out text-danger" aria-hidden="true"></i>
                        </div>
                        <!-- Profile Text -->
                        <div class="notification--list-body-text profile">
                            <h6>Sign-out</h6>
                        </div>
                    </a>
                </div>
                    @else
                    <div class="profile-data">
                        <a class="profile-list--data" href="{{route('logoutcompany')}}">
                            <!-- Profile icon -->
                            <div class="profile--list-icon">
                                <i class="fa fa-sign-out text-danger" aria-hidden="true"></i>
                            </div>
                            <!-- Profile Text -->
                            <div class="notification--list-body-text profile">
                                <h6>Sign-out</h6>
                            </div>
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- ###### Layout Container Area ###### -->
    <div class="layout-container-area mt-70">
        <!-- Side Menu Area -->
        <div class="side-menu-area">

            <div class="classy-nav-container breakpoint-off">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="classyNav">

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">
                        <!-- close btn -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>
                    <?php   $BuyShop=BuyShop::where('status','inactive')->get()->count();?>
                        @if($BuyShop >0)
                            <script defer>
                                let audio = new Audio('{{asset('mp3/cart.mp3')}}');
                                if(!audio.isPlaying)
                                {
                                    audio.play();
                                }
                            </script>
                    @endif
                        <?php $zang=\App\Models\ContactAdmin::where('status','inactive')->get()->count();?>
                        @if($zang >0)
                            <script defer>
                                let audi = new Audio('{{asset('mp3/sms.mp3')}}');
                                if(!audi.isPlaying)
                                {
                                    audi.play();
                                }
                            </script>
                    @endif
                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul>
                                @if(auth()->user()->rolle!='company')
                                <li><a href="{{route('adminindex')}}"><i class="icon_drive"></i> @lang('admin.home')</a>

                                </li>
                                    @if(auth()->user()->admin=='superAdmin')
                                <li><a href="{{route('Category.index')}}"><i class="icon_piechart"></i> Գլխավոր մենյու</a>

                                </li>

                                <li><a href="{{route('sectionMenu.index')}}"><i class="icon_documents_alt"></i>Մենյուների Բաժիներ</a>

                                </li>
                                <li><a href="{{route('market.index')}}"><i class="icon_genius"></i> Ընկերություներ</a></li>
                                <li><a href="{{route('ListFilter.index')}}"><i class="icon_menu"></i> Ստանդարտավորում</a></li>
                                <li><a href="{{route('Items.index')}}"><i class="icon_map_alt"></i> Բոլոր ապրանքները</a></li>

                                        <li><a href="{{route('buyshop.index')}}"><i class="icon_cart_alt"></i> Գնումներ  <span
                                                    style="background-color: #1bc2db;
                                                        color: #fff;
                                                        padding: 0 5px;
                                                        border-radius: 15px;">{{$BuyShop}}</span></a> </li>
                                <li><a href="{{route('MenuRestoran.index')}}"><i class="icon_document_alt"></i> Կազմել Նախացանկ</a>
                                </li>
                                <li><a href="{{route('Admin.index')}}"><i class="icon_desktop"></i> Օգտատերեր</a>
                                </li>
                                        @else

                                        <li><a href="{{route('Items.index')}}"><i class="icon_map_alt"></i> Բոլոր ապրանքները</a></li>


                                        @endif
                                    @else
{{--                                    <li><a href=""><i class="icon_drive"></i> @lang('companyindex')</a></li>--}}
                                    <li ><a href="{{route('Production.index')}}" style="color: red"><i class="icon_map_alt"></i> Բոլոր ապրանքները</a></li>
                                    <?php $section=Section::where('folder_id',auth()->user()->menu_id)->get()?>
                                    @foreach($section as $sections)
                                        <li><a href="{{route('chosfindmenu',$sections->sections_id)}}" style="color:sandybrown"><i class="icon_map_alt"></i>{{$sections->name_am}}</a></li>
                                    @endforeach
@endif


                            </ul>

                        </div>
                        <!-- Nav End -->
                    </div>
                </nav>
            </div>
        </div>

        <!-- Layout Container -->
        <div class="layout-container sidemenu-container mt-100">
            <div class="container-fluid" >



