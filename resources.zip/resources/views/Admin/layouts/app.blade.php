@include('Admin.include.header')

    @yield('content')

@include('Admin.include.footer')
