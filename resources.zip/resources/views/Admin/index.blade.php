@extends('Admin.layouts.app')
@section('css')
    <meta http-equiv="refresh" content="5" />
@endsection
@section('content')


                            <div class="container-fluid">
                                <div class="row">
                        <div class="col-lg-3">
                            <!-- Widget Content Style -->
                            <div class="widget-content-style bg-danger text-center zoom-effect mb-50"  onclick="location.href='{{route('contactindex')}}'">
                                <?php   use App\Models\BuyShop;$BuyShop=BuyShop::where('status','inactive')->get()->count();?>
                                <?php $zang=\App\Models\ContactAdmin::where('status','inactive')->where('type','phone')->get()->count();?>

                                <div class="widget--content-text">
                                    <i class="fa fa-phone fa-4x mb-10"></i>
                                    <h2 class="color-white">{{$zang}}</h2>
                                    <h6 class="color-white no-margins">Զանգ</h6>
                                </div>
                            </div>
                        </div>
                                    <div class="col-lg-3">
                            <!-- Widget Content Style -->
                            <div class="widget-content-style bg-success text-center zoom-effect mb-50"  onclick="location.href='{{route('contactmsg')}}'">
                                <?php $sms=\App\Models\ContactAdmin::where('status','inactive')->where('type','msg')->get()->count();?>

                                <div class="widget--content-text">
                                    <i class="fa fa-send fa-4x mb-10"></i>
                                    <h2 class="color-white">{{$sms}}</h2>
                                    <h6 class="color-white no-margins">Հետադարձ կապ</h6>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <!-- Widget Content -->
                            <div class="widget-content-style bg-green p-lg text-center zoom-effect mb-50" onclick="location.href='{{route('buyshop.index')}}'">
                                <!-- Widget Content Text -->
                                <div class="widget--content-text">
                                    <i class="fa fa-cart-plus fa-3x color-white mb-10"></i>
                                    <h2 class="color-white">{{$BuyShop}}</h2>
                                    <h3 class="color-white no-margins">Գնումներ</h3>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <!-- Widget Content -->
                            <div class="widget-content-style bg-danger p-lg text-center  zoom-effect mb-50" onclick="location.href='{{route('Currency')}}'">
                                <div class="widget--content-text" >
                                <i class="fa fa-money fa-3x color-white mb-10" style="text-align: center"></i>
                                <h2 class="color-white">Փոխարժեք</h2>

                                </div>
                                <ul class="list-unstyled m-t-md">
                                    <li>
                                        <span class="fa fa-dollar m-r-xs"></span>
                                        <label>Դոլար: </label> {{$currencies->USD}}
                                    </li>
                                    <li>
                                        <span class="fa fa-ruble m-r-xs"></span>
                                        <label>Ռուբլի: </label> {{$currencies->RUB}}
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

                            <div class="page-wrapper mb-170">

                            </div>



    <script>
        var audio = document.getElementById("play");


        function playAudio() {
            audio.play();
        }
    </script>
    @endsection
