@extends('Admin.layouts.app')
@section('content')
@dd(1)
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row pt-2 pb-2">
                <div class="col-sm-9">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminindex')}}">Գլխավոր</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                        </li>
                    </ol>
                </div>

                    <div class="col-md-6 col-lg-12 col-xl-12">
                        <div class="own-info-window">
                            <div class="person-info">
                                <ul>
                                    <li>
                                        <button class="btn btn-light" data-toggle="collapse" data-target="#name"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                        <span><i class="fa fa-user" aria-hidden="true"></i> {{\Illuminate\Support\Facades\Auth::user()->name}} {{\Illuminate\Support\Facades\Auth::user()->surname}}</span>
                                        <form action="{{ route('namechangess')}}"  method="post">
                                            @csrf
                                            <div id="name" class="form-group input-group edit-param collapse namesurname">
                                                <input type="text" name="name" class="form-control" placeholder="введите новое имя" value="{{\Illuminate\Support\Facades\Auth::user()->name}}">
                                                <input type="text" name="surname" class="form-control" placeholder="введите новое имя" value="{{\Illuminate\Support\Facades\Auth::user()->surname}}">
                                                <div class="input-group-append">
                                                    <button class="btn btn-warning ">
                                                        @lang('lang.change')
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                        <hr>
                                    </li>

                                    <li>
                                        <button class="btn btn-light" data-toggle="collapse" data-target="#type"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                        <span><i class="fa fa-list-alt" aria-hidden="true"></i> {{\Illuminate\Support\Facades\Auth::user()->reg_gender}}</span>
                                        <form action="{{route('genders')}}" method="post">
                                            @csrf
                                            <div id="type" class="form-group input-group edit-param collapse">
                                                <input type="radio" class="" name="type" id="male" value="company" placeholder="Компания" required checked>
                                                <label for="male">@lang('lang.company')</label>
                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                <input type="radio" class="" name="type" id="female" value="man" placeholder="челавек" required>
                                                <label for="female">@lang('lang.man')</label>
                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                <button class="btn btn-warning editBtn" type="submit">
                                                    @lang('lang.change')
                                                </button>
                                            </div>
                                        </form>
                                        <hr>
                                    </li>
                                    <li>
                                        <button class="btn btn-light" data-toggle="collapse" data-target="#type1"><i class="fa fa-picture-o" aria-hidden="true"></i></button>
                                        <span><i class="fa fa-photo" aria-hidden="true"></i> Photo</span>
                                        <form id="imageUploadForm" action="{{route('saves-images')}}" enctype="multipart/form-data" method="post">
                                            @csrf
                                            <div id="type1" class="form-group input-group edit-param collapse">
                                                <label for="photo_name"><i class="fa fa-photo" aria-hidden="true">  @lang('lang.addimg') </i></label>
                                                <input type="file" name="photo_name" id="photo_name" required="" style="display: none;">
                                                <button class="btn btn-warning" type="submit">
                                                    @lang('lang.change')
                                                </button>
                                            </div>
                                        </form>
                                        <hr>
                                    </li>

                                    <li>
                                        <button class="btn btn-light" data-toggle="collapse" data-target="#mail"><i class="fa fa-phone" aria-hidden="true"></i></button>
                                        <span><i class="fa fa-phone" aria-hidden="true"></i>{{\Illuminate\Support\Facades\Auth::user()->tel}}</span>
                                        <form action="{{route('tels')}}" method="post">
                                            @csrf
                                            <div id="mail" class="form-group input-group edit-param collapse">
                                                <input type="text" name="tel" class="form-control" placeholder="старое Phone адрес" value="{{auth()->user()->tel}}">
                                                <div class="input-group-append">
                                                    @if(\Illuminate\Support\Facades\Auth::user()->tel)
                                                        <button class="btn btn-warning" type="submit">
                                                            @lang('lang.change')
                                                        </button>
                                                    @else

                                                        <button class="btn btn-warning" type="submit">
                                                            @lang('lang.add')
                                                        </button>
                                                    @endif
                                                </div>
                                            </div>
                                        </form>
                                        <hr>
                                    </li>

                                    <li>
                                        @if (session('status'))
                                            <div class="alert alert-success" role="alert">
                                                {{ session('status') }}
                                            </div>
                                        @endif
                                        <button class="btn btn-light" data-toggle="collapse" data-target="#password"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>

                                        <span><i class="fa fa-key" aria-hidden="true"></i> пароль</span>
                                        <form id="login-form" class="text-left" role="form" method="POST" action="{{ route('password.email') }}">

                                            @csrf                                        <div id="password" class="form-group input-group edit-param collapse">
                                                <label for="fp_email" class="sr-only">{{ __('E-Mail Address') }}</label>

                                                <input type="hidden" class="form-control" name="email" value="{{ auth()->user()->email}}"  >
                                                @if ($errors->has('email'))
                                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                                @endif
                                                <div class="input-group-append">
                                                    <button class="btn btn-warning" type="submit">
                                                        @lang('lang.send')
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>


            </div>



        </div>


    </div>












    @endsection