@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/reasPage.css')}}">
    <link href="{{asset('asset/dist/css/smart_cart.css')}}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
    <link href="{{asset('asset/CSS/timeTo.css')}}" rel="stylesheet"/>
    <style>

        .btn-show {
            display: none;
        }
        @media (max-width: 768px) {
            .adversting {
                display: none;
            }
        }
        .adversting {
            width: 70%;
            margin: 20px auto;
        }
        aside {
            position: sticky;
            top: 50px;
            border: 1px solid #eee;
        }
        .btn-show{
            display:block;
        }

    </style>

@endsection
@section('content')


    <section class="container-fluid">

        <div class="row" style="margin-top: 15px;">
            <div class="col-md-3 col-lg-3 col-xl-3">
                @include('include.search')
                @include('include.leftpanel')


            </div>


            @if(isset($details))

            <div class="col-md-9 col-lg-9 col-xl-9">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h3 class="catHeaderText"> {{ $query }}</h3>
                        <div class="row">

                            <!-- BEGIN PRODUCTS -->
                            @foreach($data as $restaurants)

                                <div class="col-12 col-sm-4 col-md-6 col-lg-4 col-xl-3 howShow">
                                    <div class="sc-product-item thumbnail">
                                        <div class="myCheck">
                                            <input type="checkbox" onclick="unsel({{$restaurants->id}})" class="check-select" id="checl-select-{{$restaurants->id}}">
                                        </div>
                                        <div class="menuShow">
                                            <div class="form-group">
                                                <ul class="navbar-nav">
                                                    <form class="addCartlist">
                                                        <li class="nav-item margin-t-b-5">
                                                            <button onclick="sel({{$restaurants->product_id}})" type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$restaurants->product_id}}">
                                                                <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                            </button>
                                                        </li>
                                                        <li class="nav-item btnsCon">
                                                            <a class="btn btn-success controlBtns" href="{{route('RestaurantProduct',$restaurants->product_id)}}">
                                                                <i class="fa fa-search-plus" aria-hidden="true"></i>
                                                            </a>
                                                            <input class="main-sc-cart-item-qty qty" name="product_quantity" min="1" value="1" type="number">
                                                            @auth
                                                                @if($restaurants->auth!=auth()->user()->id)
                                                                    <button type="button"  class="btn btn-success controlBtns myfavorit color-{{$restaurants->product_id}}" data-favorit="{{$restaurants->product_id}}">
                                                                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                                    </button>
                                                                @else
                                                                    <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                        <i class="fa fa-heart-o" style="color:red"  aria-hidden="true"></i></button>

                                                                @endif
                                                            @else
                                                                <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                    <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                            @endauth
                                                        </li>
                                                    </form>
                                                </ul>
                                            </div>
                                        </div>


                                        <img class="prodImg" data-name="product_image" src="{{asset('myproduct/'.$restaurants->img)}}" alt="...">
                                        <div class="sc-added-item" data-removid="{{$restaurants->product_id}}" id='sc-added-item-{{$restaurants->product_id}}' onclick="unsel({{$restaurants->product_id}})"></div>
                                        <div class="all-product-text">
                                            <h6 class="myIm" data-name="product_name">
                                                <a href="{{route('RestaurantProduct',$restaurants->product_id)}}">{{$restaurants->{'title_'.session('locale')} }}</a></h6>
                                                <span class="text-left mainDesk">{{mb_substr($restaurants->{'description_'.session('locale')}, 0, 100)}}</span>
                                            @if($restaurants->stars==1)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($restaurants->stars==2)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($restaurants->stars==3)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($restaurants->stars==4)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($restaurants->stars==5)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            @endif
                                            <p>
                                                <span class="price price-now">{{$restaurants->price_new}}</span>
                                                <span class="price-really">{{$restaurants->price_old}}</span>
                                                <span>@lang('lang.amd')</span>
                                                <input name="product_price" value="{{$restaurants->price_new}}" type="hidden" />
                                                <input name="product_id" value="{{$restaurants->product_id}}" type="hidden" />
                                            </p>
                                        </div>
                                    </div>
                                </div>
                        @endforeach
                        <!-- END PRODUCTS -->
                        </div>
                    </div>
                </div>
{{$data->links()}}
            </div>
            @else

            <div class="col-md-9 col-lg-9 col-xl-9">
                <div class="panel panel-default">
                    <div class="panel-body">

                    @section('title', __("lang.Nothing was found"))
                    <h3 class="text-center catHeaderText">@lang('lang.Nothing was found')</h3>
                    <hr>
                    <div class='text-center' style="font-size: 70px;">
                        <i class="fa fa-inbox" aria-hidden="true"></i>
                    </div>
                </div>
                </div>
                </div>

            @endif

        </div>
    </section>

@endsection
