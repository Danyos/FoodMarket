<div class="container">
<div class="row" style="background: wheat;">
    @foreach($data as $search)
        <a href="{{route('RestaurantProduct',$search->product_id)}}" style="color: black; font-size: 15px;">{{$search->title_am }}</a>
    @endforeach
</div>
</div>
