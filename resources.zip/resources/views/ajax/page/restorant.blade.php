<div class="col-md-6 col-lg-6 col-xl-6">
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="row">
                <!-- BEGIN PRODUCTS -->
                @foreach($data as $restaurants)
                    <div class="col-12 col-sm-4 col-md-6 col-lg-4 col-xl-4 howShow">
                        <div class="sc-product-item thumbnail">
                            <div class="myCheck">
                                <input type="checkbox" onclick="unsel({{$restaurants->id}})" class="check-select" id="checl-select-{{$restaurants->id}}">
                            </div>
                            <div class="menuShow">
                                <div class="form-group">
                                    <ul class="navbar-nav">
                                        <form class="addCartlist">
                                            <li class="nav-item margin-t-b-5">
                                                <button onclick="sel({{$restaurants->product_id}})" type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCartsRest" data-itemid="{{$restaurants->product_id}}">
                                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                </button>
                                            </li>
                                            <li class="nav-item btnsCon">
                                                <a class="btn btn-success controlBtns" href="{{route('RestaurantProduct',$restaurants->product_id)}}">
                                                    <i class="fa fa-search-plus" aria-hidden="true"></i>
                                                </a>
                                                <input class="main-sc-cart-item-qty qty" name="product_quantity" min="1" value="1" type="number">
                                                <button class="btn btn-success controlBtns">
                                                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                </button>
                                            </li>
                                        </form>
                                    </ul>
                                </div>
                            </div>

                            <img class="prodImg" data-name="product_image" src="{{asset('myproduct/'.$restaurants->images)}}" alt="...">
                            <div class="sc-added-item" data-removid="{{$restaurants->product_id}}" id='sc-added-item-{{$restaurants->product_id}}' onclick="unsel({{$restaurants->product_id}})"></div>
                            <div class="all-product-text">
                                <h6 class="myIm" data-name="product_name">
                                    <a href="{{route('RestaurantProduct',$restaurants->product_id)}}">{{$restaurants->{'title_'.session('locale')} }}</a></h6>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <p>
                                    <span class="price price-now">{{$restaurants->price_new}}</span>
                                    <span class="price-really">{{$restaurants->price_old}}</span>
                                    <span>@lang('lang.amd')</span>
                                    <input name="product_price" value="{{$restaurants->price_new}}" type="hidden" />
                                    <input name="product_id" value="{{$restaurants->id}}" type="hidden" />
                                </p>
                            </div>
                        </div>
                    </div>
            @endforeach
            <!-- END PRODUCTS -->
            </div>
        </div>
    </div>

</div>
