
<div class="signUpHover"><a href="{{route('favoritesalls')}}"><i class="fa fa-heart" aria-hidden="true"></i><span id="favQuantity">{{$favoritecount}}</span></a></div>
