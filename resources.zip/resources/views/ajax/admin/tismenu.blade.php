<option hidden selected>ընտրել խանութ</option>
@foreach($data as $menus)
    <option value="{{$menus->id}}" data-ids="{{$menus->id}}">{{$menus->food_name_am}}</option>
@endforeach

