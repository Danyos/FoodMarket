<select  class="oldmenu" name="filter_id" style=" border-radius: 15px; box-shadow: 2px 3px #FF5F00;">

    @foreach($data as $menus)
        <option value="{{$menus->id}}" data-ids="{{$menus->id}}">{{$menus->size}}</option>
    @endforeach
</select>
