@if($id=='admin')

    <select name="admin" id="">
        <option value="superAdmin">SuperAdmin</option>
        <option value="admin">Admin</option>
    </select>
    @elseif($id=='company')
    <select name="market" id="">
        @foreach($market as $markets)
            <option value="{{$markets->id}}">{{$markets->market_name_am}}</option>
        @endforeach
    </select>

    <select name="menu_id" id="">
        @foreach($folder as $folders)
            <option value="{{$folders->id}}">{{$folders->folder}}</option>
        @endforeach
    </select>
    @elseif($id=='user')
    <select name="user_type" id="">
        <option value="man" hidden>Տեսակը</option>
        <option value="company">Ընկերություն</option>
        <option value="man">Անհատ</option>
    </select>
@endif
