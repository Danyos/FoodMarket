<select  class="oldmenu" name="food_menu_id" style="border: 2px solid red; border-radius: 15px; box-shadow: 2px 3px #FF5F00;">
    <option hidden>Մենյու</option>
    @foreach($data as $menus)
        <option value="{{$menus->id}}" data-ids="{{$menus->id}}">{{$menus->food_name_am}}</option>
    @endforeach
</select>


