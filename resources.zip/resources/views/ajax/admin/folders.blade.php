@foreach($data as $sections)
    <div class="col-sm-6">
        <label for="{{$sections->name_en}}">{{$sections->slug??$sections->name_am}}</label>
        <input type="checkbox" name="menu_markets[]" id="{{$sections->name_en}}" value="{{$sections->sections_id}}">
    </div>
@endforeach
