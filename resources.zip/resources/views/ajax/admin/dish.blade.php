<select  name="section_id" required class="menu" style="border: 2px solid red; border-radius: 15px; box-shadow: 2px 3px #FF5F00;">
    <option hidden selected>Ցանկ</option>
    @foreach($data as $market)
        <option value="{{$market->sections_id}}">{{$market->slug??$market->name_am}}</option>
    @endforeach
</select>

    <script>

        $('.menu').change(function () {
            var id = $(this).val();

            $.ajax({
                type:'get',
                url:'{{url('/Menu/Selects/')}}/'+id,
                data:'_token = <?php echo csrf_token() ?>',
                dataType : 'html',
                contentType: false,
                processData: false,

                success:function(data) {
                    $(".listmenuchek").html(data);


                }
            });




        });


</script>
