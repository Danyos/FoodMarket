@foreach($cart as $cartget)
    <div class="sc-cart-item list-group-item del{{$cartget->id}}" data-unique-key="1564504090868">
        <button type="button" class="sc-cart-remove" data-removids="{{$cartget->id}}" onclick="location.href='{{route('delremove',$cartget->id)}}'">×</button>
        <img class="img-responsive pull-left" src="{{asset('myproduct/'.$cartget->attributes->images)}}">
        <h4 class="list-group-item-heading">{{$cartget->name}}</h4><p class="list-group-item-text"></p>
        <h4 class="list-group-item-heading">{{$cartget->attributes->marketprice}}</h4><p class="list-group-item-text"></p>
        <div class="sc-cart-item-summary"><span class="sc-cart-item-price">AMD&nbsp;{{$cartget->price}}</span>

            <input type="number" min="1" data-updateid="{{$cartget->id}}" max="1000" class="sc-cart-item-qty item-qty" value="{{$cartget->quantity}}" onchange="console.log(1)">

            <span class="sc-cart-item-amount">AMD&nbsp;{{$cartget->price*$cartget->quantity}}</span>

        </div>
    </div>
@endforeach
<img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">
<img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="IDram" title="IDram" src ="{{asset('asset/IMAGE/id.png')}}">
<img style="width: 25px;" alt="Cash" title="Cash" src ="{{asset('asset/IMAGE/md.png')}}">
<div id="smartcart" class="total ">
    <div class="pull-left "><span>Առաքում։ </span><span class="shiptotal">{{$shiptotal}}</span><span> &nbsp;@lang('lang.amd')  </span></div>
    <div class="pull-right "><span class=" price_total">nbsp; {{$total}}</span><span> &nbsp;@lang('lang.amd')</span></div>

</div>

<script>
    $('.item-qty').change(function () {
        alert(1);
    })
</script>
