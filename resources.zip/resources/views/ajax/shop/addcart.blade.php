<div class="btn-show">
    <button style="color: #fff;" class="btn btn-secondary bask" data-toggle="modal" data-target="#myBasket"><i class="fa fa-shopping-cart" aria-hidden="true"> </i><span class="qanak"> {{$count}}</span></button>
</div>
<div class="modal" id="myBasket">
    <div class="modal-dialog">
        <div class="modal-content">


            <!-- Modal body -->
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><i class="fa fa-shopping-basket cartLogo" aria-hidden="true"></i>&nbsp;Իմ պատվերը</h4>
                <hr>
                <aside>

                <!-- Cart submit form -->
                    <form action="{{route('Chekvalidate')}}" method="POST" >
                        @csrf
                        <div class="checkout-section">
                          <p class="text-left"><i style="color: #E9294A;border: 1px solid #E9294A;border-radius:50%;padding: 2px 7px;" class="fa fa-info" aria-hidden="true" ></i>&nbsp;Կարմիրով նշված դաշտերը պարտադիր լրացման ենթակա են</p>

                            <div id="chekout">

<br>
                                <input style="border: 1px solid red;" type="text" id="name" name="own_name" value="{{old('own_name')}}" class="form-control myInpMar" placeholder="@lang('lang.name') @lang('lang.surname')" required="required">
                                <?php $countriesprice = \App\Models\CountryPrice::get();?>
                                <?php $currency=\App\Models\Currency::where('id','1')->first();?>

                                <select class="form-control"  style="display: none"  id="secid" form="catform">

                                    @foreach($countriesprice as $countryprice)
                                        @if(\Illuminate\Support\Facades\Session::has('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                                            @if(session('pricetype')=='USD')
                                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                            @elseif(session('pricetype')=='RUB')
                                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                            @else
                                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo intval($countryprice->price);?></option>

                                            @endif
                                        @else
                                            @if(session('pricetype')=='USD')

                                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                            @elseif(session('pricetype')=='RUB')
                                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                            @else
                                                <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo intval($countryprice->price);?></option>


                                            @endif @endif

                                    @endforeach

                                </select>
                                <select style="border: 1px solid red;" class="form-control myInpMar"  id="catid" form="catform">


                                    <option value="0" class="nullcountry">Ընտրեք տարածաշրջանը</option>

                                    <?php $countries = \App\Models\Country::get();?>
                                    @foreach($countries as $country)
                                        @if(\Illuminate\Support\Facades\Session::has('sessioncounrtyid')&& session('sessioncounrtyid')==$country->id)

                                            <option value="{{$country->id}}" class="{{$country->id}}" selected>{{$country->{'country_'.session('locale')} }} </option>
                                        @else
                                            <option value="{{$country->id}}" class="{{$country->id}}" >{{$country->{'country_'.session('locale')} }} </option>
                                        @endif
                                    @endforeach

                                </select>
                                <?php $countriesprice = \App\Models\CountryPrice::where('country_id',session('sessioncounrtyid'))->get();?>
                                @if(session('sessioncountrysecid')!=null)


                                    <select class="form-control" style="display: block" name="catid" id="township" form="catform">
                                        @else
                                            <select class="form-control" style="display: none;border: 1px solid red;" name="catid" id="township" form="catform">
                                                @endif


                                                @foreach($countriesprice as $countryprice)
                                                    @if(session('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                                                        @if(session('pricetype')=='USD')
                                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                                        @elseif(session('pricetype')=='RUB')
                                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                                        @else
                                                            <option data-itemsecid="{{$countryprice->id}}"  value="{{$countryprice->price}} " class="{{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-{{$countryprice->price}}</option>

                                                        @endif
                                                    @else
                                                        @if(session('pricetype')=='USD')
                                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                                        @elseif(session('pricetype')=='RUB')
                                                            <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                                        @else
                                                            <option data-itemsecid="{{$countryprice->id}}"  value="{{$countryprice->price}} " class="{{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-{{$countryprice->price}}</option>

                                                        @endif
                                                    @endif

                                                @endforeach


                                            </select>

                                <input type="text" id="mail" name="own_email" class="form-control myInpMar" placeholder="@lang('lang.email')" >
                                <input style="border: 1px solid red!important;" type="text" id="street" name="own_street" value="{{old('own_street')}}" class="form-control myInpMar"  placeholder="Փողոց" required="required">
                                <input style="border: 1px solid red;" type="number" id="phone" name="own_phone" value="{{old('own_phone')}}" class="form-control myInpMar"  placeholder="+37400000000" required="required">
                                <div style="display: flex" class="myInpMar">
                                    <input type="text" id="home" name="own_enter" class="form-control" value="{{old('own_enter')}}" placeholder="@lang('lang.logıns')" >&nbsp;
                                    <input type="text" id="home" name="own_floor" class="form-control" value="{{old('own_floor')}}"  placeholder="Հարկ" >&nbsp;
                                    <input style="border: 1px solid red;" type="number" id="home" name="own_home" class="form-control" placeholder="Բնակարան" required="required">
                                </div>

                            </div>
                        </div>
                        <div class=" addcartupade">
                            <div class="list-group sc-cart-item-list  ">

                                @foreach($cart as $cartget)
                                    <div class="sc-cart-item list-group-item del{{$cartget->id}} remow{{$cartget->id}} celeare" data-unique-key="1564504090868">
                                        <button type="button" class="sc-cart-remove" data-removid="{{$cartget->id}}" >×</button>
                                        <img class="img-responsive pull-left" src="{{asset('myproduct/'.$cartget->attributes->images)}}">
                                        <h4 class="list-group-item-heading">{{$cartget->name}}</h4><p class="list-group-item-text"></p>
                                        @if(session('sessioncounrtyid')!=null)

                                            <div style="display: block" class="marketpriceonediv">
                                                Առաքում  + <span data-updateidpricea="{{$cartget->id}}" class="marketpriceone pricechangetype ">{{$cartget->attributes->marketprice}}</span><span class="currency">&nbsp;@lang('lang.amd')</span>
                                            </div>
                                        @else
                                            <div style="display: none" class="marketpriceonediv">
                                                Առաքում  + <span data-updateidpricea="{{$cartget->id}}" class="marketpriceone pricechangetype">{{$cartget->attributes->marketprice}}</span><span class="currency">&nbsp;@lang('lang.amd')</span>
                                            </div>
                                        @endif
                                        <div class="sc-cart-item-summary"><span class="sc-cart-item-price"><span class="currency">AMD</span>&nbsp;<span class="pricechangetype">{{$cartget->price}}</span> </span>

                                            <input type="number" min="1" max="1000" data-updateid="{{$cartget->id}}" class="sc-cart-item-qty myupdate" value="{{$cartget->quantity}}" >

                                            <div class="sc-cart-item-amount summedPrice{{$cartget->id}}"><span class="currency">AMD</span>&nbsp;<span class="pricechangetype">{{$cartget->price*$cartget->quantity}}</span></div>
                                            <!--avelacrel em  -->
                                            @if($cartget->attributes->descriptionproduct=="")

                                                <span class="addproductdesc addproductdesc{{$cartget->id}}" > <a class="add"  title="Add" class="adddescription" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a></span>
                                                <span class="editproductdesc editproductdesc{{$cartget->id}}" style="display: none" >  <a class="edit"  title="Edit"  data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a></span>
                                                <span class="removeproductdesc removeproductdesc{{$cartget->id}}" style="display: none">  <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a></span>
                                                <input type="hidden" class="editproductdescinput"  value="{{$cartget->id}}">
                                                <br>
                                                <textarea  class="main-sc-cart-item-qty descprod" style="width: 435px;display: none" name="description" style="width: 435px;" ></textarea>
                                            @else
                                                <span class="addproductdesc addproductdesc{{$cartget->id}}" style="display: none"> <a class="add"  title="Add" class="adddescription" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a></span>
                                                <span class="editproductdesc editproductdesc{{$cartget->id}}" >  <a class="edit"  title="Edit"  data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a></span>
                                                <span class="removeproductdesc removeproductdesc{{$cartget->id}}">  <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a></span>
                                                <input type="hidden" class="editproductdescinput"  value="{{$cartget->id}}">
                                                <br>
                                                <textarea  class="main-sc-cart-item-qty descprod" style="width: 435px;display: none" name="description" style="width: 435px;" ></textarea>    <!--  <a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a>-->
                                            @endif
                                            <div class="descriptionproductdiv{{$cartget->id}}">{{$cartget->attributes->descriptionproduct}}</div>



                                        </div>
                                        <input type="hidden" name="EDP_LANGUAGE" value="{{app()->getLocale()}}">
                                        <input type="hidden" name="EDP_REC_ACCOUNT_id" value="{{$cartget->id}}">
                                        <input type="hidden" name="EDP_DESCRIPTION" value="Order description">
                                        <input type="hidden" name="qty" value="{{$cartget->quantity}}" class="priceitem">
                                        <input type="hidden" name="EDP_price" value=" {{$cartget->price}}" class="inputprice">
                                    </div>

                                @endforeach
                            </div>


                            <input type="hidden" name="EDP_AMOUNT" value=" {{$total}}" class="inputtotal">

                            <hr>




                            <div id="smartcart" class="total ">
                                <div class="pull-left "><span>Առաքում։ </span><span class="shiptotal pricechangetype">{{$shiptotal}}</span><span class="currency">&nbsp;@lang('lang.amd')</span></div>
                                <div class="pull-right"><span class=" price_total pricechangetype">{{$total}}</span><span class="currency">&nbsp;@lang('lang.amd')</span></div>

                            </div>
                            <img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">
                            <img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="IDram" title="IDram" src ="{{asset('asset/IMAGE/id.png')}}">
                            <img style="width: 25px;" alt="Cash" title="Cash" src ="{{asset('asset/IMAGE/md.png')}}">

                        </div>
                        <div class="sc-cart-toolbar">
                            <button class="btn btn-info sc-cart-checkout" type="button">Պատվիրել</button>
                            <button class="btn btn-danger sc-cart-clear" type="button">Չեղարկել</button>
                        </div>

                    </form>
                </aside>
            </div>
        </div>
    </div>
</div>



<script>
    //avelacrel em naey classer em avelacrel sc-cart-removein jnjel em onclick@
    //avelacrel em
    $('.addproductdesc').on('click',function(){
        let a=$(this).parent().find('.editproductdescinput').val();
        $(this).parent().find('.descprod').show();
        $(this).parent().find('.descprod').val($('.descriptionproductdiv'+a).html());

    });



    $('.descprod').on('focusout',function(){
        $(this).hide();
        $(this).parent().find('.addproductdesc').hide();
        $(this).parent().find('.editproductdesc').show();
        $(this).parent().find('.removeproductdesc').show();

        let a=$(this).parent().find('.editproductdescinput').val();
        let b=$(this).parent().find('.descprod').val();
        $(this).parent().find('.descprod').hide();

        $.ajax({

            type:'get',
            url:'{{url('Cartupdatedesc/')}}/'+a,
            data:{description:b ,id: a},
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            success:function(data){
                if(data['description']==null){
                    $('.addproductdesc'+a).show();
                    $('.editproductdesc'+a).hide();
                    $('.removeproductdesc'+a).hide();
                    $('.descriptionproductdiv'+a).show();
                    $('.descriptionproductdiv'+a).html(data['description']);
                    $('.descriptionproductdiv'+a).hide();



                }else{
                    $('.descriptionproductdiv'+a).show();
                    $('.descriptionproductdiv'+a).html(data['description']);
                }



            }
        });




    });
    $('.editproductdesc').on('click',function(){
        let a=$(this).parent().find('.editproductdescinput').val();
        $(this).parent().find('.descprod').show();
        $(this).parent().find('.descprod').val($('.descriptionproductdiv'+a).html());
        $('.descriptionproductdiv'+a).hide();

    });

    $('.removeproductdesc').on('click',function(){

        $(this).parent().find('.addproductdesc').show();
        $(this).parent().find('.editproductdesc').hide();
        $(this).parent().find('.removeproductdesc').hide();
        $(this).parent().find('.descprod').hide();


        let a=$(this).parent().find('.editproductdescinput').val();
        let b='';
        $.ajax({
            type:'get',
            url:'{{url('Cartupdatedesc/')}}/'+a,
            data:{description:b ,id: a},
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            success:function(data){
                $('.descriptionproductdiv'+a).show();
                $('.descriptionproductdiv'+a).html(data['description']);
                $('.descriptionproductdiv'+a).hide();
            }
        });


    });


    $('.sc-cart-remove').on('click',function () {
        var a=$(this).data('removid');
        $.ajax({

            type:'get',
            url:'{{url('Cartremovedelete/')}}/'+a,
            data:a,
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            success:function(data){
                $('.remow'+a).fadeOut().remove();
                $('.qanak').html(data['datacount']);
                $('.price_total').html(data['total']);
                $('.shiptotal').html(data['shiptotal']);
                $('.inputtotal').val(data['total']);
                for(var i=0;i< $('.marketpriceone').length;i++)

                    $('.marketpriceone').eq(i).html(data['marketpricearr'][i]);
                $('#sc-added-item-'+data['productid']).css('display','none');

                <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                @if(session('pricetype')=='USD')
                $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                for(var i=0;i< $('.marketpriceone').length;i++)

                    $('.marketpriceone').eq(i).html((Number(data['marketpricearr'][i])/Number({{$currency->USD}})).toFixed(2));

                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('$');
                }
                        @elseif(session('pricetype')=='RUB')
                for(var i=0;i< $('.marketpriceone').length;i++)

                    $('.marketpriceone').eq(i).html((Number(data['marketpricearr'][i])/Number({{$currency->RUB}})).toFixed(2));


                $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('₽');
                }
                @endif


            }


        });
    })
</script>



<script>
   <?php $currency=\App\Models\Currency::where('id','1')->first();?>
            @if(session('pricetype')=='USD')

    for(var i=0;i<($('.pricechangetype')).length;i++){
        $('.pricechangetype').eq(i).html((Number($('.pricechangetype').eq(i).html())/Number({{$currency->USD}})).toFixed(2));
    }
    for(var i=0;i<($('.currency')).length;i++){
        $('.currency').eq(i).html('$');
    }
            @elseif(session('pricetype')=='RUB')

    for(var i=0;i<($('.pricechangetype')).length;i++){
        $('.pricechangetype').eq(i).html((Number($('.pricechangetype').eq(i).html())/Number({{$currency->RUB}})).toFixed(2));
    }
    for(var i=0;i<($('.currency')).length;i++){
        $('.currency').eq(i).html('₽');
    }
    @endif

    $('.sc-cart-clear').click(function () {
        $('.celeare').fadeOut();
        $.ajax({

            type:'get',
            url:'{{url('Cart/clear')}}',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            success:function(data){



                $('.price_total').html(data['total']);
                $('.shiptotal').html(data['shiptotal']);
                $('.qanak').html(data['count']);
                $('.sc-added-item').css('display','none');
                $('.inputtotal').val(data['total']);
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                        @if(session('pricetype')=='USD')

                for(var i=0;i<($('.pricechangetype')).length;i++){
                    $('.pricechangetype').eq(i).html((Number($('.pricechangetype').eq(i).html())/Number({{$currency->USD}})).toFixed(2));
                }
                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('$');
                }
                        @elseif(session('pricetype')=='RUB')

                for(var i=0;i<($('.pricechangetype')).length;i++){
                    $('.pricechangetype').eq(i).html((Number($('.pricechangetype').eq(i).html())/Number({{$currency->RUB}})).toFixed(2));
                }
                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('₽');
                }
                @endif


            }
        });
    })



    $('.sc-cart-item-qty').change(function () {
        b= $(this).val();

        let a = $(this).data('updateid');

        console.log(a);
        console.log(b);
        $.ajax({

            type:'get',
            url:'{{url('Cartupdate/')}}/'+a,

            data:{qty:b ,id: a},
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            success:function(data){

                $('.price_total').html(data['total']);
                $('.shiptotal').html(data['shiptotal']);
                $('.inputtotal').val(data['total']);
                $('.inputprice').val(data['summedPrice']);

                $('.summedPrice'+a).html('<span class="currency">AMDs</span>&nbsp;<span class="pricechangetype">'+data['summedPrice']*data['qty']+'</span>');
                <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                @if(session('pricetype')=='USD')
                $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                $('.summedPrice'+a).html('<span class="currency">AMDs</span>&nbsp;<span class="pricechangetype">'+(Number(data['summedPrice']*data['qty'])/Number({{$currency->USD}})).toFixed(2)+'</span>');


                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('$');
                }
                @elseif(session('pricetype')=='RUB')

                $('.summedPrice'+a).html('<span class="currency">AMDs</span>&nbsp;<span class="pricechangetype">'+(Number(data['summedPrice']*data['qty'])/Number({{$currency->RUB}})).toFixed(2)+'</span>');


                $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('₽');
                }
                @endif


                // $('.qanak').html(json['datacount']);
            }
        });
    })


    $('.sc-cart-checkout').click(function(){
        if( Number($('.inputtotal').val())<1000){
            alert('Պատվերի գումարը 1000 դրամից պակաս է');
        }
        else{
            $(this).attr('type','submit');

        }
    })

    $('#catid').change(function() {
        // get the class of the selected option
        var select_class = $("option:selected", this).attr("class");
        // clone all options from the pot select
        var countryprice='0';
        var countryid=$('#catid').val();
        if( $(this).val()>0)
        {
            $('#township').show();

            var $options = $('#secid > option.'+select_class).clone();
            // delete all of the options in the township select and append
            // the new options
            $('#township')
                .find('option')
                .remove()
                .end()
                .append($options);
            countryprice=$('#township').val();
            $('.marketpriceonediv').show();


            var countrysecid= $('#township').children("option:selected").data('itemsecid');

        }
        else{

            $('#township').hide();
            $('.marketpriceonediv').hide();

        }

        var arrmarketprice=[];
        for(var i=0;i<$('.marketpriceone').length;i++)
        {

            if(Number($('.marketpriceone').eq(i).text())>=0){

                arrmarketprice.push($('.marketpriceone').eq(i).data('updateidpricea'));


            }
        }

        $.ajax({

            type:'get',
            url:'{{url('Cartupdateprice')}}',

            data:{countryprice:countryprice,arrmarketprice:arrmarketprice,countrysecid:countrysecid,countryid:countryid },
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

            success:function(data){


                $('.price_total').html(data['total']);
                $('.shiptotal').html(data['shiptotal']);
                $('.inputtotal').val(data['total']);
                for(var i=0;i<$('.marketpriceone').length;i++)
                {

                    for(var j=0;j<data['arrmarketidchange'].length;j++){

                        if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                            $('.marketpriceone').eq(i).text(countryprice);


                        }
                    }

                }
                <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                @if(session('pricetype')=='USD')
                $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                for(var i=0;i<$('.marketpriceone').length;i++)
                {

                    for(var j=0;j<data['arrmarketidchange'].length;j++){

                        if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                            $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->USD}})).toFixed(2));


                        }
                    }

                }

                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('$');
                }
                @elseif(session('pricetype')=='RUB')

                $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                for(var i=0;i<($('.currency')).length;i++){
                    $('.currency').eq(i).html('₽');
                }
                for(var i=0;i<$('.marketpriceone').length;i++)
                {

                    for(var j=0;j<data['arrmarketidchange'].length;j++){

                        if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                            $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->RUB}})).toFixed(2));


                        }
                    }

                }
                @endif

            }

        });


    });


   $('#township').change(function() {



       let countryprice=$('#township').val();
       var arrmarketprice=[];
       $('.marketpriceonediv').show();

       for(var i=0;i<$('.marketpriceone').length;i++)
       {                    @if(session('pricetype')=='USD')

       if(Number($('.marketpriceone').eq(i).text())>0.42)
           @elseif(session('pricetype')=='RUB')
           if(Number($('.marketpriceone').eq(i).text())>27.78)
               @else                if(Number($('.marketpriceone').eq(i).text())>200)
                   @endif

               {

                   arrmarketprice.push($('.marketpriceone').eq(i).data('updateidpricea'));


               }
       }
       var countrysecid= $('#township').children("option:selected").data('itemsecid');
       var countryid=$('#catid').val();


       $.ajax({

           type:'get',
           url:'{{url('Cartupdateprice')}}',

           data:{countryprice:countryprice,arrmarketprice:arrmarketprice ,countrysecid:countrysecid,countryid:countryid },
           headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

           success:function(data){

               $('.price_total').html(data['total']);
               $('.shiptotal').html(data['shiptotal']);
               $('.inputtotal').val(data['total']);
               for(var i=0;i<$('.marketpriceone').length;i++)
               {

                   for(var j=0;j<data['arrmarketidchange'].length;j++){

                       if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                           $('.marketpriceone').eq(i).text(countryprice);


                       }
                   }

               }
               <?php $currency=\App\Models\Currency::where('id','1')->first();?>
               @if(session('pricetype')=='USD')
               $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
               $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
               for(var i=0;i<$('.marketpriceone').length;i++)
               {

                   for(var j=0;j<data['arrmarketidchange'].length;j++){

                       if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                           $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->USD}})).toFixed(2));


                       }
                   }

               }

               for(var i=0;i<($('.currency')).length;i++){
                   $('.currency').eq(i).html('$');
               }
               @elseif(session('pricetype')=='RUB')

               $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
               $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
               for(var i=0;i<($('.currency')).length;i++){
                   $('.currency').eq(i).html('₽');
               }
               for(var i=0;i<$('.marketpriceone').length;i++)
               {

                   for(var j=0;j<data['arrmarketidchange'].length;j++){

                       if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                           $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->RUB}})).toFixed(2));


                       }
                   }

               }
               @endif

           }
       });


   });


</script>

