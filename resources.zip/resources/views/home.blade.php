@extends('layouts.app')

@section('css')
    <style type="text/css">
        [data-toggle="collapse"] .fa:before {
            content: "\f139";
        }

        [data-toggle="collapse"].collapsed .fa:before {
            content: "\f13a";
        }

        .onw-page {
            margin: 25px auto;
        }

        .ownpage-window {
            width: 100%;
            height: auto;
            overflow: hidden;
            color: #444;
        }

        .ownpage-window img {
            height: 200px;
            width: auto;
            display: block;
            margin: 0 auto;
            border-radius: 5px;
        }

        .own-info li {
            margin: 5px 0;
        }
        .card{
            border: none;
        }

        .card-header {
            background-color: #FF5F00;
            border: none;
            transition-duration: .5s;
            margin-top: 25px;
            cursor: pointer;
        }

        .card-header button {
            color: #fff;
            font-weight: 700;
            font-size: 20px;
            transition-duration: .5s;
        }

        .card-header button:focus {
            text-decoration: none;
            color: #b7b7b7;
        }

        .card-header button:hover {
            text-decoration: none;
            color: #91D525;
        }

        .card-body {
            border: 1px solid #ff5f00;
        }

        .alert {
            margin-top: 5px;
        }

        .edit_p_e {
            display: flex;
            width: 100%;
        }

        .inp-window {
            width: 100%;
            height: auto;
            overflow: hidden;
        }

        .e_first {
            width: 98%;
            margin-right: auto;
        }

        .e_second {
            width: 98%;
            margin-left: auto;
        }

        .e-buttons {
            width: 100%;
            height: auto;
            overflow: hidden;
        }

        .e-buttons button {
            margin: 0 10px;
        }

        .f-product {
            width: 100%;
            height: auto;
            overflow: hidden;
        }

        .f-p-window {
            width: 100%;
            height: auto;
            overflow: hidden;
            color: #717171;
            font-weight: 700;
            line-height: 120px;
        }

        .f-p-window img {
            width: auto;
            height: 120px;
            display: block;
            margin: 0 auto
        }

        .e-price {
            color: #e95668;
            font-size: 25px;
        }

        .e-view {
            background: #92d625;
            border-color: #92d625;
            border-radius: 0;
        }

        .e-delete {
            background: #e95668;
            border-color: #e95668;
            border-radius: 0;
        }

        @media (max-width: 576px) {
            .ow-text h2{ text-align: center !important; }
            .ow-text .own-info li{ text-align: center; }
            .f-p-window { line-height: 100%; }
        }

        @media (min-width: 576px) and (max-width: 768px) {
            .f-p-window { line-height: 100%; }
        }
    </style>
    @endsection
@section('content')
    <div class="container-fluid onw-page">
        <div class="row">
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3">
                <div class="ownpage-window">
                    <img  src="{{asset('asset/user/'.auth()->user()->avatar)}}" alt="IMG">
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-8 col-lg-9 col-xl-9">
                <div class="ownpage-window ow-text">
                    <h2 class="text-left">{{\auth()->user()->name}} {{\auth()->user()->surname}}</h2>
                    <hr>
                    <ul class="navbar-nav own-info">
                        <li class="nav-item"><i class="fa fa-envelope" aria-hidden="true"> </i> {{\auth()->user()->email}}</li>
                        <li class="nav-item"><i class="fa fa-phone" aria-hidden="true"></i> {{\auth()->user()->tel}}</li>
                        <li class="nav-item"><i class="fa fa-user" aria-hidden="true"></i> {{\auth()->user()->user_type}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="container-fluid section">
        <div id="accordion">
            <div class="card">
                <div class="card-header" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                        <i class="fa" aria-hidden="true"></i>
                      Փոփոխել էջը
                    </button>
                </div>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">



@if(session('succsess'))
                            <div class="alert alert-success">
                                <h2>  <strong>Հաջողություն!</strong> Պահպանվեց ձեր փոփոխություները.</h2>
                            </div>
    @else
                            <div class="alert alert-info">
                                <h2><strong>Տեղեկատվություն!</strong>Ձեր ազնական տվյալները փոխելիս դաշտը դատարկ չի թույլատրվում թողնել:</h2>
                            </div>
    @endif
                        <hr>
                        <form method="post" action="{{route('userupdateprofile')}}" enctype="multipart/form-data">
                            @csrf
                            <div class="text-left inp-window">
                                <input type="text" class="form-control" name="name" value="{{auth()->user()->name}}" placeholder="Փոփոխել անունը">
                                @error('name')
                                <div class="alert alert-danger">
                                    <strong>Զգուշացում!</strong> This alert box could indicate a dangerous or potentially negative action.
                                </div>
                                @enderror
                            </div>
                            <div class="text-left inp-window">
                                <input type="text" class="form-control" name="surname" placeholder="Փոփոխել ազգանունը" value="{{auth()->user()->surname}}" >

                                @error('surname')
                                <div class="alert alert-danger">
                                    <strong>Զգուշացում!</strong> This alert box could indicate a dangerous or potentially negative action.
                                </div>
                                @enderror
                            </div>
                            <div class="text-left edit_p_e">
                                <div class="inp-window">
                                    <input type="email" class="form-control e_first"  value="{{auth()->user()->email}}" disabled>
                                    <div class="alert alert-danger e_first">
                                        <strong>Զգուշացում!</strong> Ձեր կայքին կցաց փոստը փոփոխման ենթակա չէ.
                                    </div>
                                </div>

                                <div class="inp-window">
                                    <input type="number" class="form-control e_second" value="{{auth()->user()->tel}}" name="tels" placeholder="Հեռ">
                                    @error('tels')
                                    <div class="alert alert-danger">
                                        <strong>Զգուշացում!</strong> This alert box could indicate a dangerous or potentially negative action.
                                    </div>
                                    @enderror
                                </div>

                            </div>

                            <div class="text-left inp-window">
                                <input type="password" class="form-control" name="password_old" placeholder="Հին գաղտանբառ">
                                @if(session('password_old'))
                                <div class="alert alert-danger">
                                    <strong>Զգուշացում!</strong> Հարգելի հաճախորդ ձեր գաղտնաբարը չի համնկնում.
                                </div>
                                @endif
                                @error('password_old')
                                <div class="alert alert-danger">
                                    <strong>Զգուշացում!</strong> This alert box could indicate a dangerous or potentially negative action.
                                </div>
                                @enderror
                            </div>
                            <div class="text-left inp-window">
                                <input type="password" class="form-control" name="password" placeholder="Նոր գաղտանբառ">
                                @error('password')
                                <div class="alert alert-danger">
                                    <strong>Զգուշացում!</strong> This alert box could indicate a dangerous or potentially negative action.
                                </div>
                                @enderror
                            </div>
                            <div class="text-left edit_p_e">
                                <div class="inp-window">
                                    <input type="password" class="form-control e_first" name="password_confirmation" placeholder="Կրկնել գաղտնաբառը">
                                    @error('password_confirmation')
                                    <div class="alert alert-danger">
                                        <strong>Զգուշացում!</strong> This alert box could indicate a dangerous or potentially negative action.
                                    </div>
                                    @enderror
                                </div>

                            </div>
                            <hr>
                            <div class="e-buttons">
                                <button class="btn btn-success pull-right" type="submit">@lang('lang.change')</button>
                                <button class="btn btn-danger pull-right" type="reset">Մաքրել</button>
                                <label for="addImg" class="btn btn-info pull-right" type="button" title="@lang('lang.change')">
                                    <i class="fa fa-picture-o" aria-hidden="true"></i>
                                </label>
                                <input  class="pull-right" hidden type="file" name="avatar" id="addImg">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        <i class="fa" aria-hidden="true"></i>
                      @lang('lang.Favorites')
                    </button>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                    <div class="card-body">
                        @foreach($product as $products)
                        <div class="f-product trash-{{$products->product_id}}">

                            <div class="row">
                                <div class="d-none d-lg-block col-md-3 col-lg-2 col-xl-2">
                                    <div class="f-p-window">
                                        <img src="{{asset('myproduct/'.$products->images)}}" alt="IMG">
                                    </div>
                                </div>
                                <div class="d-none d-lg-block col-lg-2 col-xl-2">
                                    <div class="f-p-window">
                                        <p class="text-left">
                                            @if($products->stars==1)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($products->stars==2)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($products->stars==3)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($products->stars==4)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($products->stars==5)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            @endif
                                        </p>
                                    </div>
                                </div>
                                <div class="col-7 col-sm-5 col-md-6 col-lg-4 col-xl-4">
                                    <div class="f-p-window">
                                        <p class="text-left">
                                            {{$products->{'title_'.session('locale')} }}
                                        </p>
                                    </div>
                                </div>
                                <div class="col-5 col-sm-3 col-md-3 col-lg-2 col-xl-2">
                                    <div class="f-p-window">

                                        <p>
                                            <span class="price-now pricechangetype">{{$products->price_new}}</span>
                                            <span class="price-really pricechangetype">{{$products->price_old}}</span>
                                            <span class="currency">@lang('lang.amd')</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-4 col-md-3 col-lg-2 col-xl-2">
                                    <div class="f-p-window">
                                        <p class="text-right">
                                            <a class="btn btn-success e-view addCarts"  data-itemid="{{$products->product_id}}">
                                                <i class="fa fa-cart-plus" aria-hidden="true"></i>
                                            </a>

                                            <a class="btn btn-success e-view" href="{{route('RestaurantProduct',$products->product_id)}}" tabindex="0">
                                                <i class="fa fa-search-plus" aria-hidden="true"></i>
                                            </a>
                                            <a class="btn btn-danger e-delete trash" data-trash="{{$products->product_id}}">
                                                <i class="fa fa-trash-o" aria-hidden="true"></i>
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <hr>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="headingThree" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        <i class="fa" aria-hidden="true"></i>
               Իմ գնածները
                    </button>
                </div>
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                    <div class="card-body">
                        @foreach($ifuser as $products)
                            <div class="f-product">

                                <div class="row">
                                    <div class="d-none d-lg-block col-md-3 col-lg-2 col-xl-2">
                                        <div class="f-p-window">
                                            <img src="{{asset('myproduct/'.$products->images)}}" alt="IMG">
                                        </div>
                                    </div>
                                    <div class="d-none d-lg-block col-lg-2 col-xl-2">
                                        <div class="f-p-window">
                                            <p class="text-left">
                                                @if($products->stars==1)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($products->stars==2)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($products->stars==3)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($products->stars==4)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($products->stars==5)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                @endif
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-6 col-sm-4 col-md-5 col-lg-3 col-xl-3">
                                        <div class="f-p-window">
                                            <p class="text-left">
                                                {{$products->{'title_'.session('locale')} }}
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-5 col-sm-3 col-md-3 col-lg-2 col-xl-2">
                                        <div class="f-p-window">

                                            <p>
                                                <span class="price-now pricechangetype">{{$products->price_new}}</span>
                                                <span class="price-really pricechangetype">{{$products->price_old}}</span>
                                                <span class="currency">@lang('lang.amd')</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                        <div class="f-p-window">
                                            <p class="text-left">
                                                <span style="font-size: 12px;">Քանակ
                                                {{$products->quantity }}+{{$products->price_new}}=
                                                {{$products->price_new*$products->quantity }} @lang('lang.amd')
                                                </span>
                                            </p>

                                        </div>
                                    </div>


                                    <div class="col-12 col-sm-1 col-md-1 col-lg-1 col-xl-1">
                                        <div class="f-p-window">
                                            <p class="text-right">
                                                <a class="btn btn-success e-view addCarts"  data-itemid="{{$products->product_id}}">
                                                    <i class="fa fa-cart-plus" aria-hidden="true"></i>
                                                </a>
                                                <a class="btn btn-success e-view" href="{{route('RestaurantProduct',$products->product_id)}}" tabindex="0">
                                                    <i class="fa fa-search-plus" aria-hidden="true"></i>
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <hr>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        $('.trash').click(function(){
            var a=$(this).data('trash');
            $.ajax({
                type:'get',
                url:'{{url('user/favorites/trash')}}/'+a,
                data:'_token = <?php echo csrf_token() ?>',
                dataType : 'html',
                contentType: false,
                processData: false,

                success:function(data) {
                    $('.trash-'+data).remove().hide();
                }
            });
        });

    </script>
@endsection
