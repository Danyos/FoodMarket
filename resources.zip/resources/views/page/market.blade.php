@extends('layouts.app')

@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/reasPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/praductPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <style>
        .btn-show {
            display: block;
        }
        .for-all .all-header {
            font-size: 16px;
        }
        @media (max-width: 768px) {
            .bah {
                display: none;
            }
        }
        .adversting {
            display: none;
            width: 70%;
            margin: 0;
        }
    </style>
@endsection
@section('content')


    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-lg-4 col-xl-3">
                <div class="resProd r-resProd">
                    <div id="accordion" class="accordion">
                        <div class="search-resr">
                       @include('include.search')
                        </div>
                        <div class="card mb-0">

                            @foreach($section as $sectionitem)
                            <div class="card-header collapsed" data-toggle="collapse" href="#{{mb_substr($sectionitem->name_en, 0, 3)}}">
                                <a class="card-title">
                                 {{$sectionitem->{'name_'.session('locale')} }}
                                </a>
                            </div>

                            <div id="{{mb_substr($sectionitem->name_en, 0, 3)}}" class="card-body collapse" data-parent="#accordion" >
                                <ul class="navbar-nav subList">
                                    @foreach($sectionitem->menuitem as $sectionmenu)

                                    <li class="nav-item subList-item"><a class="lmenhov" href="{{url('This/Market/'.$sectionmenu->id.'/'.$id)}}">{{$sectionmenu->{'food_name_'.session('locale')} }}</a></li>
                                    @endforeach
                                </ul>
                            </div>
                                <hr style="width: 90%;margin: 0 auto;">
                    @endforeach
                        </div>
                        @include('include.akcia')
                    </div>


                    <div class="bah">

                        @include('include.leftpanel')

                    </div>
                </div>
            </div>
            <div class="col-md-8 col-lg-8 col-xl-9">
                <div class="container-fluid road">
                        <span><a href="{{route('index')}}">Գլխավոր էջ</a></span>
                        <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
                        <span><a href="{{route('Restaurantmarket',$category->cat_id)}}">{{$category->cat_name_am}}</a></span>
                </div>
                <div class="res-wind" style="margin-top: 6px;">
                    <button class="btn btn-light" id='allrest'>Բոլոր {{$category->cat_name_am}} <span>{{count($marketall)}}</span></button>
                </div>

                  <div class="row allrest"  >
                    @foreach($marketall as $foodmarket)
                    <div class="col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="resProd">
                            <div class="text-center resProdView" onclick="location.href='{{route('Restaurant',$foodmarket->market_id)}}'">
{{--                                <button class="btn btn-light fav"><i class="fa fa-heart-o" aria-hidden="true"></i></button>--}}
                                <img src="{{asset('foodname/'.$foodmarket->logo)}}" alt="IMG">
                                <h5 class="text-center">{{$foodmarket->{'market_name_'.session('locale')} }}</h5>
                                <p class="text-center resSecInf"></p>
                                <span class="resTime">

                                       @if($foodmarket->close=='active')

                                            <span class="resTime" style="color: #28a745;">
                                        {{\Carbon\Carbon::createFromFormat('H:i:s',$foodmarket->start_date)->format('H:i')}} - {{\Carbon\Carbon::createFromFormat('H:i:s',$foodmarket->end_date)->format('H:i')}}
                                    </span>

                                        @else
                                         <span class="resTime" style="color:red;">
                                            Փակ է
                                        </span>
                                        @endif
                                  </span>

                                <p class="resProdBotInf">
                                    <span class="orderTime"><i class="fa fa-clock-o" aria-hidden="true"></i> {{$foodmarket->delivery}}</span>
                                    <span class="redDeliver ">Առաքում <span class="pricechangetype">{{$foodmarket->price}}</span><span class="currency">@lang('lang.amd')</span></span>
                                </p>
                            </div>
                        </div>
                    </div>
              @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection


