@extends('layouts.app')

@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/reasPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/praductPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <style>
        .btn-show {
            display: block;
        }
        .for-all .all-header {
            font-size: 16px;
        }
        @media (max-width: 768px) {
            .bah {
                display: none;
            }
        }
        .adversting {
            display: none;
            width: 70%;
            margin: 0;
        }
    </style>
@endsection
@section('content')

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-lg-4 col-xl-3">
                <div class="resProd r-resProd">
                    <div id="accordion" class="accordion">
                        <div class="search-resr">
                            @include('include.search')
                        </div>
                        <div class="card mb-0">

                            @foreach($section as $sectionitem)
                                <div class="card-header collapsed" data-toggle="collapse" href="#{{str_replace(' ', '-',$sectionitem->name_en)}}">
                                    <a class="card-title">
                                        {{$sectionitem->{'name_'.session('locale')} }}
                                    </a>
                                </div>

                                <div id="{{str_replace(' ', '-',$sectionitem->name_en)}}" class="card-body collapse" data-parent="#accordion" >
                                    <ul class="navbar-nav">
                                        @foreach($sectionitem->menuitem as $sectionmenu)

                                            <li class="nav-item"><a href="{{url('This/Market/'.$sectionmenu->id.'/'.$id)}}">{{$sectionmenu->{'food_name_'.session('locale')} }}</a></li>
                                        @endforeach
                                    </ul>
                                </div>
                                <hr style="width: 90%;margin: 0 auto;">
                            @endforeach
                        </div>
                    </div>

                    <div class="bah">
                        @include('include.leftpanel')

            <div class="col-md-8 col-lg-8 col-xl-9">
                <div class="res-wind" style="margin-top: 6px;">
                    <button class="btn btn-light">Open Restaurants <span>15</span></button>
                    <button class="btn btn-light">All <span>35</span></button>
                </div>
                <div class="row">
                    @foreach($market as $foodmarket)
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-3">
                            <div class="resProd">
                                <div class="text-center resProdView" onclick="location.href='{{route('Restaurant',$foodmarket->id)}}'">
                                    <button class="btn btn-light fav"><i class="fa fa-heart-o" aria-hidden="true"></i></button>
                                    <img src="{{asset('foodname/'.$foodmarket->logo)}}" alt="IMG">
                                    <h5 class="text-center">{{$foodmarket->{'market_name_'.session('locale')} }}</h5>
                                    <p class="text-center resSecInf"></p>
                                    <span class="resTime">{{\Carbon\Carbon::createFromFormat('H:i:s',$foodmarket->start_date)->format('H:i')}}-{{\Carbon\Carbon::createFromFormat('H:i:s',$foodmarket->end_date)->format('H:i')}}</span>

                                    <p class="resProdBotInf">
                                        <span class="orderTime"><i class="fa fa-clock-o" aria-hidden="true"></i> {{$foodmarket->delivery}}</span>
                                        <span class="redDeliver">Առաքում {{$foodmarket->price}}</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection
