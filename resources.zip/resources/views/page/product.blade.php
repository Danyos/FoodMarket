@extends('layouts.app')

@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/reasPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/praductPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/dist/css/smart_cart.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/timeTo.css')}}" >
    <style>
        @media (max-width: 768px) {
            .adversting {
                display: none;
            }
        }
        @media (max-width: 576px) {
            .sc-product-item thumbnail sc-added-item h6 {
                font-size: 15px !important;
            }
        }
    </style>
@endsection
@section('meta')
    <meta property="og:url" content="{{url(app()->getLocale().'/RestaurantProduct/'.$product->product_id)}}" />
    <meta property="og:image" content="{{asset('myproduct/'.$product->images)}}" />
    <meta property="og:image:width" content="450"/>
    <meta property="og:image:height" content="298"/>
    <meta property='og:title' content='{{$product->{'title_'.session('locale') } }}' />
    <meta property='og:description' content='{{$product->{'description_'.session('locale') } }}' />




@endsection
@section('content')
    <div class="container-fluid road">
        <div class="container">
            <span><a href="{{route('index')}}">Գլխավոր էջ</a></span>
            <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
            <span><a href="{{route('Restaurantmarket',$category->cat_id)}}">{{$category->cat_name_am}}</a></span>
            <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
            <span><a href="{{route('Restaurant',$mareket->id)}}">{{$mareket->market_name_am}}</a></span>

            <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
            <span>{{$product->{'title_'.session('locale')} }}</span>

        </div>
    </div>

    <div class="image-gallery">
        <button type="button" class="close closeOpImage" data-modal=".image-gallery" onclick="closeMyModal(this.dataset.modal)">×</button>
        <div class="image-wind">
            <img src="{{asset('myproduct/'.$product->images)}}" alt="...">
        </div>
    </div>
    {{-- shat nakrneri hamar
     @foreach($images as $imagess)
      <img src="{{asset('myproduct/'.$imagess->image)}}" alt="...">
    @endif
    --}}
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                @include('include.leftmenu')
                @include('include.leftpanel')

            </div>
            <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                <!--praduct start-->
                <div class="container-fluid" style="margin-top: 15px;">
                    <div class="sc-product-item thumbnail" style="width: 100%;">
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                <div class="product-image-wind">

                                    <div class="for-image">
                                        <div class="zoom-icon">
                                            <a class="zoom-link"><i class="fa fa-search-plus"></i></a>
                                        </div>
                                        <img data-name="product_image" class="mainImg" align="left" src="{{asset('myproduct/'.$product->images)}}" alt="...">
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
                                <h6 data-name="product_name" class="text-left" style="font-size: 20px;">
                                    @auth

                                        @if($product->auth==auth()->user()->id)

                                            <button type="button" class="btn btn-link" onclick="location.href='{{route('favoritesalls')}}'">
                                                <i class="fa fa-heart-o" style="color:red;"  aria-hidden="true"></i></button>

                                        @else
                                            <button type="button"  class="btn btn-link myfavorit color-{{$product->product_id}}" data-favorit="{{$product->product_id}}">
                                                <i class="fa fa-heart-o" aria-hidden="true"></i>
                                            </button>

                                        @endif
                                    @else
                                        <button type="button" class="btn btn-link" onclick="location.href='{{route('login')}}'">
                                            <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                    @endauth
                                    {{$product->{'title_'.session('locale')} }}</h6>
                                <hr>
                                <div class="form-group">
                                    {{--<h4 class="text-left"></h4>--}}
                                    <p style="margin: 0;">
                                        @if($product->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($product->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($product->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($product->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($product->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                    </p>
                                    <br>
                                    <div id="descr">
                                        <span><b>Նկարագրություն: </b></span>
                                        <span>
                        {{$product->{'description_'.session('locale')} }}
                    </span>
                                    </div>
                                    @if($data!=null)
                                        <div id="descr">
                                            <span><b>Ստանդարտավորում: </b></span>
                                            <span>
<select name="" id="" onchange="location.href='{{url('my/Product/show/'.$product->product_id)}}/'+this.value">

    @foreach($data as $datas)
        @if($datas->id==$product->filter_list)
            <option value="{{$datas->id}}" selected hidden>{{$datas->size}}</option>
        @else
            <option value="{{$datas->id}}">{{$datas->size}}</option>
        @endif
    @endforeach

</select>
                    </span>
                                        </div>
                                    @endif
                                    <br>
                                    <div id="shimp">
                                        <p>
                                            <span><b>Առաքում: </b></span>
                                            <span>
                          @lang('lang.vanadzor') <span class="pricechangetype">300 </span>  <span class="currency">@lang('lang.amd')</span>
                        </span>
                                        </p>

                                    </div>
                                    <div class="text-left" style="overflow: hidden;">
                                        <b class="price"><span style="color: #EB4D4D;font-size: 25px;"  class="pricechangetype">{{$product->price_new}} </span>
                                            <b><span style="font-size: 17px;"  class="price-really">{{$product->price_old}} </span>
                                                <span class="currency">@lang('lang.amd')</span></b>
                                            <input name="product_price" value="{{$product->price_new}}" type="hidden" />
                                            <input name="product_id" value="{{$product->product_id}}" type="hidden" />
                                            <br class="new-line">
                                            <label class="label-product-quantity myInpMar" for="product-quantity"> @lang('lang.quality')</label>
                                            <input id="product-quantity" class="main-sc-cart-item-qty qty myInpMar pQuan" name="qty" min="1" value="1" type="number">
                                    </div>
                                </div>
                                <div class="caption">
                                    <form class="addCartlist">
                                        <div>

                                            <hr>
                                            <label for="product-specify"> @lang('lang.moreinformation')</label>
                                            <br>
                                            <textarea  class="main-sc-cart-item-qty  descproduct{{$product->product_id}}" style="width: 100%;" name="description"></textarea>                    <hr>
                                            <div class="pull-left prod-add-control">


                                                <button
                                                    type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$product->product_id}}">
                                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                </button>



                                                <img class="prodBuyInfo" style="margin:0 5px;display: inline;width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">
                                                <img class="prodBuyInfo" style="margin:0 5px;display: inline;width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="IDram" title="IDram" src ="{{asset('asset/IMAGE/id.png')}}">
                                                <img class="prodBuyInfo" style="margin:0 5px;display: inline;width: 25px;" alt="Cash" title="Cash" src ="{{asset('asset/IMAGE/md.png')}}">
                                                <div id="social-links">
                                                    <ul style="float: right">
                                                        <li style="display: inline"><a href="https://www.facebook.com/sharer/sharer.php?u={{url(app()->getLocale().'/RestaurantProduct/'.$product->product_id)}}" class="social-button " target="_blank" id=""><span class="fa fa-facebook-official"></span></a></li>
                                                        <li style="display: inline"><a href="https://twitter.com/intent/tweet?text=my share text&amp;url={{url(app()->getLocale().'/RestaurantProduct/'.$product->product_id)}}" target="_blank" class="social-button " id=""><span class="fa fa-twitter"></span></a></li>
                                                        <li style="display: inline"><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{url(app()->getLocale().'/RestaurantProduct/'.$product->product_id)}}&amp;title=my share text&amp;summary=dit is de linkedin summary" class="social-button " id=""><span class="fa fa-linkedin"></span></a></li>
                                                        <li style="display: inline"><a href="https://wa.me/?text={{url(app()->getLocale().'/RestaurantProduct/'.$product->product_id)}}" class="social-button " target="_blank" id=""><span class="fa fa-whatsapp"></span></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container">
                    <h2 class="simik-p">Նմանատիպ ապրանքներ</h2>
                    <hr>
                    <div class="row">
                        <!-- BEGIN PRODUCTS -->
                        @foreach($mainproduct->take(4) as $main)
                            <div class="col-12 col-sm-6 col-md col-lg-6 col-xl-3 howShow">
                                <div class="sc-product-item thumbnail">
                                    <div class="myCheck">
                                        <input type="checkbox" onclick="unsel({{$main->id}})" class="check-select" id="checl-select-{{$main->id}}">
                                    </div>
                                    <div class="menuShow">
                                        <div class="form-group">
                                            <ul class="navbar-nav">
                                                <li class="nav-item margin-t-b-5">
                                                    <button onclick="sel({{$main->product_id}})" type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$main->product_id}}">
                                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')</button>
                                                </li>
                                                <li class="nav-item btnsCon">
                                                    <a href="{{route('RestaurantProduct',$main->product_id)}}" class="btn btn-success controlBtns"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                                                    <input class="main-sc-cart-item-qty qty" name="product_quantity" min="1" value="1" type="number">

                                                    @auth
                                                        @if($main->auth!=auth()->user()->id)
                                                            <button type="button" class="btn btn-success controlBtns myfavorit color-{{$main->product_id}}" data-favorit="{{$main->product_id}}">
                                                                <i class="fa fa-heart-o"  aria-hidden="true"></i></button>
                                                        @else
                                                            <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                <i class="fa fa-heart-o" style="color:red";  aria-hidden="true"></i></button>
                                                        @endif
                                                    @else
                                                        <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                            <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                    @endauth
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <img class="prodImg" data-name="product_image" src="{{asset('myproduct/'.$main->img)}}" alt="...">
                                    <div class="sc-added-item"  data-removid="{{$main->product_id}}" id='sc-added-item-{{$main->product_id}}' onclick="unsel({{$main->product_id}})"></div>
                                    <div class="all-product-text">
                                        <a href="{{route('RestaurantProduct',$main->product_id)}}">
                                            <h6 class="myIm" data-name="product_name">{{$main->{'title_'.session('locale')} }}</h6>
                                            <span class="text-left mainDesk">{{mb_substr($main->{'description_'.session('locale')}, 0, 100)}}</span>
                                        </a>
                                        @if($main->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($main->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($main->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($main->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($main->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                        <p>
                                            <span class="price price-now pricechangetype">{{$main->price_new}}</span>
                                            <span class="price-really">{{$main->price_old}} </span>
                                            <span class="currency">@lang('lang.amd')</span>
                                            <input name="product_price" value="{{$main->price}}" type="hidden" />
                                            <input name="product_id" value="{{$main->id}}" type="hidden" />
                                        </p>
                                    </div>
                                </div>
                            </div>
                    @endforeach
                    <!-- END PRODUCTS -->
                    </div>
                </div>
                <!--praduct end-->
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.zoom-link').on('click', function(event) {
                event.stopPropagation();
                $('.image-gallery').fadeIn(500);

            });
            $('.image-gallery').on('click', function(event) {
                event.stopPropagation();
                if( event.target.className == 'image-gallery' ) {
                    $('.image-gallery').fadeOut(500);
                }
            });
        });
    </script>
@endsection

