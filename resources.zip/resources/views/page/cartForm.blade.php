@extends('layouts.app')


@section('content')
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <form action="https://money.idram.am/payment.aspx" method="POST">
        <input type="hidden" name="EDP_LANGUAGE" value="EN">
        <input type="hidden" name="EDP_REC_ACCOUNT" value="100000114">
        <input type="hidden" name="EDP_DESCRIPTION" value="Order description">
        <input type="hidden" name="EDP_AMOUNT" value="1900">
        <input type="hidden" name="EDP_BILL_NO" value="1806">
        <input type="submit" value="submit">
    </form>
    @endsection
