@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/reasPage.css')}}">
    <link href="{{asset('asset/dist/css/smart_cart.css')}}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
    <link href="{{asset('asset/CSS/timeTo.css')}}" rel="stylesheet"/>

    <style>


        @media (max-width: 768px) {
            .adversting {
                display: none;
            }
        }
        .adversting {
            width: 70%;
            margin: 20px auto;
        }
        aside {
            position: sticky;
            top: 50px;
            border: 1px solid #eee;
        }

        .card-title {
            font-weight: 700;
        }

        .filter-window {
             background: #fbfbfb;
            padding: 5px;
            margin: 25px 0;
        }
        #s {
            width: 90%;
            margin: 20px auto;
        }
        .price-inputs {
            display: flex;
            width: 100%;
            overflow: hidden;
            align-items: center;
            justify-content: center;
        }

        .price-inputs i {
            margin: 0 10px;
        }

        .noUi-connect {
            background: #92D625;
        }

        .filter-search-button {
            margin: 10px 0;
            width: 100%;
            height: auto;
            overflow: hidden;
        }
        .left-section-header {
            position: relative;
            width: 100%;
            height: auto;
            overflow: hidden;
            padding: 150px 0;
            background: url({{asset('foodname/'.$restoran_name->background)}})no-repeat;
            background-size: cover;
            margin: 0px;
        }
    </style>

@endsection
@section('content')

<div class="left-section-header" style="">
            <div class="rest-info">
                <div style="float:left">
                    <img src="{{asset('foodname/'.$restoran_name->logo)}}" alt="IMG" style="display: block;width: auto;height: 75px;margin: 0 10px;">
                </div>
                <div style="float:left">
                    <div>
                        <h5><i class="fa fa-cutlery" aria-hidden="true"></i> {{ $restoran_name->{'market_name_'.session('locale')} }}</h5>
                    </div>
                    <div>
                        <h5><i class="fa fa-truck" aria-hidden="true"></i>  {{$restoran_name->price}} Դրամ<!--{{ $restoran_name->addres}}--> <span>

                            </span></h5>
                    </div>
                    <p class="text-left">

                                       @if($restoran_name->close=='active')
<i class="fa fa-clock-o" aria-hidden="true"></i>
                                            <span class="resTime" style="color: #28a745;">
                                        {{\Carbon\Carbon::createFromFormat('H:i:s',$restoran_name->start_date)->format('H:i')}} - {{\Carbon\Carbon::createFromFormat('H:i:s',$restoran_name->end_date)->format('H:i')}}
                                    </span>

                                        @else
                                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                                            Փակ է

                                        @endif
                                    </p>
                </div>
            </div>
        </div>
    <section class="container-fluid">

        <div class="row" style="margin-top: 15px;">
            <div class="col-md-12 col-lg-3 col-xl-3">
                @include('include.leftmenu')
                <div class="container-fluid filter-window">
                    <P class="text-center">Փնտրեք ըստ գումարի</P>
                    <div id="s"></div>
                    <form action="{{route('price_filter')}}" method="get">

                    <div class="price-inputs">
                         <input type="hidden"  name="id" value="{{$id}}">
                        <input type="number" class="form-control" id="slider-snap-value-lower" min="0" name="start" placeholder="Սկզբ.">
                        <i class="fa fa-arrows-h" aria-hidden="true"></i>
                        <input type="number" class="form-control" id="slider-snap-value-upper" min="0" name="end" placeholder="Վերջ.">

                    </div>
                    <div class="text-center filter-search-button">
                        <button class="btn btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i> Որոնել</button>
                    </div>
                    </form>
                </div>
                @include('include.leftpanel')
            </div>


{{--

{{--            </ul>--}}

            <div class="col-md-12 col-lg-9 col-xl-9 res">
                <div class="container-fluid road">
                        <span><a href="{{route('index')}}">Գլխավոր էջ</a></span>
                        <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
                        <span><a href="{{route('Restaurantmarket',$category->cat_id)}}">{{$category->cat_name_am}}</a></span>
                        <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
                        <span class="select-cat">{{$restoran_name->market_name_am}}</span>
                    <br>
                </div>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <!-- BEGIN PRODUCTS -->
                            @foreach($restaurant as $restaurants)
                            <div class="col-12 col-sm-4 col-md col-lg col-xl-3 howShow">
                                <div class="sc-product-item thumbnail">
                                    <div class="myCheck">
                                        <input type="checkbox" onclick="unsel({{$restaurants->id}})" class="check-select" id="checl-select-{{$restaurants->id}}">
                                    </div>
                                    <div class="menuShow">
                                        <div class="form-group">
                                            <ul class="navbar-nav">
                                                <form class="addCartlist">
                                                    <li class="nav-item margin-t-b-5">
                                                        <button onclick="sel({{$restaurants->product_id}})" type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$restaurants->product_id}}">
                                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                        </button>
                                                    </li>
                                                    <li class="nav-item btnsCon">
                                                        <a class="btn btn-success controlBtns" href="{{route('RestaurantProduct',$restaurants->product_id)}}">

                                                            <i class="fa fa-search-plus" aria-hidden="true"></i>
                                                        </a>
                                                        <input class="main-sc-cart-item-qty qty" name="product_quantity" min="1" value="1" type="number">
                                                        @auth
                                                            @if($restaurants->auth!=auth()->user()->id)
                                                                <button type="button"  class="btn btn-success controlBtns myfavorit color-{{$restaurants->product_id}}" data-favorit="{{$restaurants->product_id}}">
                                                                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                                </button>
                                                            @else
                                                                <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                    <i class="fa fa-heart-o" style="color:red"  aria-hidden="true"></i></button>

                                                            @endif
                                                        @else
                                                            <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                        @endauth
                                                    </li>
                                                </form>
                                            </ul>
                                        </div>
                                    </div>

                                    <img class="prodImg" data-name="product_image" src="{{asset('myproduct/'.$restaurants->img)}}" alt="...">
                                    <div class="sc-added-item" data-removid="{{$restaurants->product_id}}" id='sc-added-item-{{$restaurants->product_id}}' onclick="unsel({{$restaurants->product_id}})"></div>
                                    <div class="all-product-text">
                                        <h6 class="myIm" data-name="product_name">
                                             <a href="{{route('RestaurantProduct',$restaurants->product_id)}}">{{$restaurants->{'title_'.session('locale')} }}</a></h6>
                                            <span class="text-left mainDesk">{{mb_substr($restaurants->{'description_'.session('locale')}, 0, 100)}}</span>
                                      @if($restaurants->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                        <p>
                                            <span class="price price-now pricechangetype">{{$restaurants->price_new}}</span>
                                            @if($restaurants->price_old>0)
                                            <span class="price-really pricechangetype">{{$restaurants->price_old}}</span>
                                            @endif
                                            <span class="currency">@lang('lang.amd')</span>
                                            <input name="product_price" value="{{$restaurants->price_new}}" type="hidden" />
                                            <input name="product_id" value="{{$restaurants->id}}" type="hidden" />
                                        </p>
                                    </div>
                                </div>
                            </div>
                         @endforeach
                            <!-- END PRODUCTS -->

                        </div>
                    </div>
                </div>
                <div>
                    {{$restaurant->links()}}
                </div>
                           </div>
                       </div>
                   </section>

               @endsection
               @section('jss')
               <script>
                   var s = document.getElementById('s');

                   noUiSlider.create(s, {
                       start: [0, 150000],
                       connect: true,
                       behaviour: 'drag',
                       step: 10,
                       range: {
                           'min':0,
                           'max': 150000
                       }
                   });
                   var snapValues = [
                      document.getElementById('slider-snap-value-lower'),
                    document.getElementById('slider-snap-value-upper')
                   ];

                   s.noUiSlider.on('update', function (values, handle) {

                       snapValues[handle].value = values[handle];
               /*s.prevent.default();*/
                   //     $.ajax({
                   //         type:'get',
                   //         url:'{{url('filt/Folders')}}/'+values,
    //         data:'market_id=<?php echo $id ?>',
    //         dataType : 'html',


    //         success:function(data) {


    //   $(".res").html(data);


    //         }
    //     });

    });

</script>

@endsection
