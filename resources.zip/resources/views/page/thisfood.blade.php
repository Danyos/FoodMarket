

@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{asset('asset/CSS/reasPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/praductPage.css')}}">
    <link rel="stylesheet" href="{{asset('asset/dist/css/smart_cart.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
    <link rel="stylesheet" href="{{asset('asset/CSS/timeTo.css')}}" >
    <style>
        @media (max-width: 992px) {
            .mineAdv {
                display: none;
            }
        }
    </style>
@endsection
@section('content')
    <div class="container-fluid road">
        <div class="container">
            <span><a href="{{route('index')}}">Գլխավոր էջ</a></span>
            <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
            <span><a href="{{route('Restaurantmarket',$category->cat_id)}}">{{$category->cat_name_am}}</a></span>
            <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
            <span>{{$menu->food_name_am}}</span>

        </div>
    </div>
    <section class="container-fluid bg-grey">
        <div class="row" style="margin-top: 15px;">
            <div class="col-md-12 col-lg-4 col-xl-3">
                <div id="accordion" class="accordion">
                    <div class="search-resr">
                        @include('include.search')

                    </div>
                    <div class="card mb-0">
                        @foreach($section as $sectionitem)
                            <div class="card-header collapsed" data-toggle="collapse" href="#{{str_replace(' ', '-',$sectionitem->name_en)}}">
                                <a class="card-title">
                                    {{$sectionitem->{'name_'.session('locale')} }}
                                </a>
                            </div>
                            <hr style="width: 90%;margin: 0 auto;">

                            <div id="{{str_replace(' ', '-',$sectionitem->name_en)}}" class="card-body collapse" data-parent="#accordion" >
                                <ul class="navbar-nav">
                                    @foreach($sectionitem->menuitem as $sectionmenu)

                                        <li class="nav-item"><a href="{{url('This/Market/'.$sectionmenu->id.'/'.$cat_id)}}">{{$sectionmenu->{'food_name_'.session('locale')} }}</a></li>
                                    @endforeach
                                </ul>
                            </div>

                        @endforeach
                    </div>
                </div>

            </div>
            <div class="col-md-12 col-lg-8 col-xl-9">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <!-- BEGIN PRODUCTS -->

                            @foreach($market as $restaurants)
                                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-3 howShow">
                                    <div class="sc-product-item thumbnail">
                                        <div class="menuShow">
                                            <div class="form-group">
                                                <ul class="navbar-nav">
                                                    <li class="nav-item margin-t-b-5">
                                                        <button class="sc-add-to-cart btn btn-success btn-sm addCart"><i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')</button>
                                                    </li>

                                                    <li class="nav-item btnsCon">
                                                        <a class="btn btn-info controlBtns"
                                                           href="{{route('RestaurantProduct',$restaurants->product_id)}}"><i
                                                                class="fa fa-search-plus"
                                                                aria-hidden="true"></i></a>
                                                        <input class="main-sc-cart-item-qty" name="product_quantity" min="1" value="1" type="number">
                                                        @auth

                                                            @if($restaurants->auth==auth()->user()->id)

                                                                <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                    <i class="fa fa-heart-o" style="color:red;"  aria-hidden="true"></i></button>

                                                            @else
                                                                <button type="button"  class="btn btn-success controlBtns myfavorit color-{{$restaurants->product_id}}" data-favorit="{{$restaurants->product_id}}">
                                                                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                                </button>

                                                            @endif
                                                        @else
                                                            <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                        @endauth
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <img class="prodImg" data-name="product_image" src="{{asset('myproduct/'.$restaurants->img)}}" alt="...">
                                        <div class="all-product-text">
                                            <h6 class="myIm" data-name="product_name">{{$restaurants->{'title_'.session('locale')} }}</h6>
                              @if($restaurants->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($restaurants->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                            <p>
                                                <span class="text-left mainDesk">{{mb_substr($restaurants->{'description_'.session('locale')}, 0, 100)}}</span>
                                                <span class="price price-now pricechangetype">{{$restaurants->price_new}}</span>
                                                <span class="price-really pricechangetype">{{$restaurants->price_old}}</span>
                                                <span class="currency">@lang('lang.amd')</span>
                                                <input name="product_price" value="{{$restaurants->price_new}}" type="hidden" />
                                                <input name="product_id" value="{{$restaurants->id}}" type="hidden" />
                                            </p>
                                        </div>
                                    </div>
                                </div>
                        @endforeach
                        <!-- END PRODUCTS -->
                        </div>
                    </div>
                    {{$market->links()}}
                </div>

            </div>
        </div>
    </section>
@endsection
