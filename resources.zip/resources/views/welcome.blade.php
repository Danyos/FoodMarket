@extends('layouts.app')

@section('content')

    <!--slider start-->

    <div class="slid-full">
        <div class="main-slider">
            <div>
                <div class="bg-change"></div>
                <div class="mainSlider" style="background: url({{asset('asset/IMAGE/khor.jpg')}}) center no-repeat;background-size:cover;">
                    <div class="text-header-show">
                        <p class="slidTextFirst" style="font-size: 30px;">Պատվիրեք ամենահամեղ սնունդը</p>
                        <p class="slidTextFirst" style="font-size: 30px;">
                            <span class="van">ՎԱՆԱՁՈՐԻ </span>
                            <span>լավագույն ռեստորաններից</span>
                        </p>
                    </div>
                </div>
            </div>
            <div>
                <div class="mainSlider" style="background: url({{asset('asset/IMAGE/1500x500.jpg')}}) center no-repeat;background-size:cover;">
                    <div class="text-header-show">
                        <p class="slidTextFirst" style="font-size: 30px;">ԸՆԿԵՐՆԵՐ, ԶՎԱՐՃԱՆՔ, ԳԱՐԵՋՈւՐ   ...</p>
                        <p class="slidTextFirst" style="font-size: 30px;">
                            <span>ԼԱՎԱԳՈւՅՆ ԺԱՄԱՆՑ</span>
                        </p>
                    </div>
                </div>
            </div>
            <div>
                <div class="mainSlider" style="background: url({{asset('asset/IMAGE/flou.jpg')}})  no-repeat;background-size:cover;">
                    <div class="text-header-show">
                        <p class="slidTextFirst" style="font-size: 30px;">ԱՅՍՔԱՆ ՔՆՔՇԱՆՔ ՄԻԵՎՆՈւՅՆ ՓՆՋՈւՄ։</p>
                        <p class="slidTextFirst" style="font-size: 30px;">
                            <span>ՆԱ ԴԵՌ ՉԻ ԿԱՐՈՂ ԵՐԵՎԱԿԱՅԵԼ</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="site-info">
            <div class="suport-content srch-div">
                <form action="{{ route('searchcolums')}}" method="post" class="search">
                    @csrf
                    <div class="search-form">
                        <input class="form-control" type="search" name="search" placeholder=" @lang('lang.search')" aria-label="Search">
                        <button class="btn btn-success"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
                    </div>
                </form>
                <div class="searchlist"></div>
            </div>
            <div class="suport-content view-div">
                <p class="text-right quanityord" style="margin: 0;"><!--avelacrel em class=quanityord-->

                    <span class="order-quanity-name">Պատվերներն այսօր</span>
                </p>
            </div>
        </div>
    </div>

    <!--slider end-->

    <div class="container">
        <div class="row">
            <div class="d-none d-md-block col-12 col-sm-12 col-md-4 col-lg-3 col-xl-3">

             @include('include.akcia')
             @include('include.leftpanel')

            </div>
            <div class="col-12 col-sm-12 col-md-8 col-lg-9 col-xl-9">
                <div class="row">
                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                        <div class="adv">
                            <form action="{{ route('searchcolums')}}" method="post" class="search">
                                @csrf
                                <div class="search-form">
                                    <input class="form-control" type="hidden" name="search" placeholder=" @lang('lang.search')" aria-label="Search" value="Խորոված">
                                    <img
                                        src="{{asset('asset/IMAGE/b-1.jpeg')}}"
                                        alt="IMG" onclick="submit()" style="cursor:pointer">
                                </div>
                            </form>


                        </div>
                    </div>
                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                        <div class="adv">
                            <form action="{{ route('searchcolums')}}" method="post" class="search">
                                @csrf
                                <div class="search-form">
                                    <input class="form-control" type="hidden" name="search" placeholder=" @lang('lang.search')" aria-label="Search" value="Շաուրմա">
                                    <img
                                        src="{{asset('asset/IMAGE/b-4.jpeg')}}"
                                        alt="IMG" onclick="submit()" style="cursor:pointer" >
                                </div>
                            </form>


                        </div>
                    </div>

                </div>
                <div class="res-prefend res-prefend-s">
                    <h3>@lang('lang.Preferred Restaurants')
                        <i class="fa fa-angle-right head-name-arrow" aria-hidden="true"></i></h3>
                    <button id="go-prev" class="btn btn-dark go-prev-p">
                        <i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                    <button id="go-next" class="btn btn-dark go-next-p">
                        <i class="fa fa-chevron-right"  aria-hidden="true"></i></button>
                    <div class="preferred">
                        @foreach($PreferredRestaurants as $restaurants)
                            <div>
                                <div class="res-preferd-wind">
                                    <div class="res-preferd-wind-show">
                                        <div class="res-p-w-how-show">
                                            <ul class="navbar-nav" style="padding: 15px;">
                                                <li class="nav-item text-center">
                                                    <a class="viewConrolers"
                                                       href="{{route('Restaurant',$restaurants->market_id)}}"><i
                                                            class="fa fa-search-plus" aria-hidden="true"></i></a>

                                                </li>
                                                <li class="nav-item text-center">
                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i> {{$restaurants->delivery}} րոպե</span>
                                                </li>
                                                <li class="nav-item text-center">
                                                    <span>Առաքման գումար <span class="pricechangetype" >{{$restaurants->price}}</span> </span>
                                                    <span class="currency">@lang('lang.amd')</span>
                                                </li>
                                                <!--<li class="nav-item text-center">-->
                                                <!--    <span class="fa fa-star checked"></span>-->
                                                <!--    <span class="fa fa-star checked"></span>-->
                                                <!--    <span class="fa fa-star checked"></span>-->
                                                <!--    <span class="fa fa-star"></span>-->
                                                <!--    <span class="fa fa-star"></span>-->
                                                <!--</li>-->
                                                <li class="nav-item text-center">
                                                    <a href="{{route('Restaurant',$restaurants->market_id)}}" class="btn btn-light">Ավելին</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <img src="{{asset('foodname/'.$restaurants->logo)}}" alt="IMG" style="width: 100%">
                                    <br>
                                    <h6 class="text-center">{{$restaurants->{'market_name_'.session('locale')} }}</h6>
                                    <p class="text-center">

                                       @if($restaurants->close=='active')

                                            <span class="resTime" style="color: #28a745;">
                                        {{\Carbon\Carbon::createFromFormat('H:i:s',$restaurants->start_date)->format('H:i')}} - {{\Carbon\Carbon::createFromFormat('H:i:s',$restaurants->end_date)->format('H:i')}}
                                    </span>

                                        @else
                                            Փակ է

                                        @endif
                                    </p>
                                </div>
                            </div>

                        @endforeach
                    </div>
                </div>
{{--                @elseif($restaurants->end_date < $restaurants->start_date and $restaurants->end_date > \Illuminate\Support\Carbon::now()->format('H:i:s') and $restaurants->start_date < \Illuminate\Support\Carbon::now()->format('H:i:s') )--}}

                <div class="res-prefend res-all">
                    <h3 class="pr-all">@lang('lang.Restaurants') <i class="fa fa-angle-right head-name-arrow" aria-hidden="true"></i></h3>
                    <div class="row">
                        @foreach($Restaurants as $restaurantsall)

                            <div class="col-6 col-sm-6 col-md-6 col-lg-4 col-xl-3">
                                <div class="res-preferd-wind pr-2">
                                    <div class="res-preferd-wind-show">
                                        <div class="res-p-w-how-show">
                                            <ul class="navbar-nav">
                                                <li class="nav-item text-center">
                                                    <a class="viewConrolers"
                                                       href="{{route('Restaurant',$restaurantsall->market_id)}}"><i class="fa fa-search-plus" aria-hidden="true"></i></a>

                                                </li>
                                                <li class="nav-item text-center">
                                                    <span><i class="fa fa-clock-o" aria-hidden="true"></i> {{$restaurantsall->delivery}} րոպե</span>
                                                </li>
                                                <li class="nav-item text-center">
                                                    <span>Առաքման գումար <span class="pricechangetype">{{$restaurantsall->price}}</span><span class="currency">@lang('lang.amd')</span> </span>
                                                </li>
                                                <!--<li class="nav-item text-center">-->
                                                <!--    <span class="fa fa-star checked"></span>-->
                                                <!--    <span class="fa fa-star checked"></span>-->
                                                <!--    <span class="fa fa-star checked"></span>-->
                                                <!--    <span class="fa fa-star"></span>-->
                                                <!--    <span class="fa fa-star"></span>-->
                                                <!--</li>-->
                                                <li class="nav-item text-center">
                                                    <a href="{{route('Restaurant',$restaurantsall->market_id)}}" class="btn btn-light">Ավելին</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <img src="{{asset('foodname/'.$restaurantsall->logo)}}" alt="IMG"
                                         style="width: 100%">
                                    <br>
                                    <h6 class="text-center"
                                        style="color: #444;">{{$restaurantsall->{'market_name_'.session('locale')} }}</h6>
                                    <p class="text-center">
                                        @if($restaurantsall->close=='active')

                                            <span class="resTime" style="color: #28a745;">
                                        {{\Carbon\Carbon::createFromFormat('H:i:s',$restaurantsall->start_date)->format('H:i')}} - {{\Carbon\Carbon::createFromFormat('H:i:s',$restaurantsall->end_date)->format('H:i')}}
                                    </span>

                                        @else
                                            Փակ է

                                        @endif

                                    </p>
                                </div>
                            </div>

                        @endforeach
                    </div>
                </div>

                <div class="fods-contaier">
                    <div class="right-banner-show">
                        <div class="right-banner-productOne">
                            <div class="prosuctOne-header">
                                <div class="prosuctOne-header-window">Ֆաստ Ֆուդ <i class="fa fa-angle-right head-name-arrow" aria-hidden="true"></i></div>

                            </div>
                            <div class="prosuctOne-body">

                                <div class="panel panel-default">
                                    <div class="tab-content">

                                            <div id="fastfood" class="tab-pane">

                                                <button id="go-prev" class="btn btn-dark go-prev-fastfood"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                                                <button id="go-next" class="btn btn-dark go-next-fastfood"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
                                                <div class="breakfast-slick-fastfood">

                                                    @foreach($fastfood as $foodproduction)


                                                        <div>
                                                            <div class="sc-product-item thumbnail">
                                                                <div class="myCheck">
                                                                        <input type="checkbox" onclick="unsel({{$foodproduction->product_id}})" class="check-select" id="checl-select-{{$foodproduction->product_id}}">
                                                                </div>
                                                                <div class="menuShow">
                                                                    <div class="form-group">
                                                                        <ul class="navbar-nav">
                                                                            <form class="addCartlist">
                                                                            <li class="nav-item margin-t-b-5">
                                                                                <button onclick="sel({{$foodproduction->product_id}})"
                                                                                  type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$foodproduction->product_id}}">
                                                                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                                                </button>
                                                                            </li>
                                                                            <li class="nav-item btnsCon">
                                                                                <a class="btn btn-success controlBtns"
                                                                                   href="{{route('RestaurantProduct',$foodproduction->product_id)}}"><i
                                                                                        class="fa fa-search-plus"
                                                                                        aria-hidden="true"></i></a>
                                                                                        <input class="main-sc-cart-item-qty qty"
                                                                                           name="product_quantity" min="1"
                                                                                           value="1" type="number">

                                                                                @auth
                                                                                    @if($foodproduction->auth!=auth()->user()->id)
                                                                                <button type="button" class="btn btn-success controlBtns myfavorit color-{{$foodproduction->product_id}}" data-favorit="{{$foodproduction->product_id}}">
                                                                                <i class="fa fa-heart-o"  aria-hidden="true"></i></button>
                                                                                        @else
                                                                                        <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                                            <i class="fa fa-heart-o" style="color:red";  aria-hidden="true"></i></button>
                                                                                        @endif
                                                                                    @else
                                                                                    <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                                        <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                                                @endauth
                                                                            </li>
                                                                            </form>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <img class="prodImg" data-name="product_image"
                                                                     src="{{asset('myproduct/'.$foodproduction->img)}}"
                                                                     alt="...">
                                                                <div class="sc-added-item" data-removid="{{$foodproduction->product_id}}" id='sc-added-item-{{$foodproduction->product_id}}' onclick="unsel({{$foodproduction->product_id}})"></div>
                                                                <div class="all-product-text">

                                                                    <h6 class="myIm"
                                                                        data-name="product_name">  <a href="{{route('RestaurantProduct',$foodproduction->product_id)}}">{{$foodproduction->{'title_'.session('locale')} }}</a></h6>
                                                                        <span class="text-left mainDesk">{{mb_substr($foodproduction->{'description_'.session('locale')}, 0, 100)}}</span>
                                       @if($foodproduction->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($foodproduction->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($foodproduction->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($foodproduction->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($foodproduction->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                                                    <p>
                                                                        <span class="price price-now pricechangetype">{{$foodproduction->price_new}} </span>
                                                                        @if($foodproduction->price_old>0)
                                                                        <span class="price-really pricechangetype">{{$foodproduction->price_old}}</span>
                                                                        @endif
                                                                        <span class="currency">@lang('lang.amd')</span>
                                                                        <input name="product_price" value="{{$foodproduction->price_new}}" type="hidden"/>
                                                                        <input name="product_id" value="{{$foodproduction->product_id}}" type="hidden"/>
                                                                    </p>
                                                                </div>
                                                            </div>


                                                        </div>

                                                    @endforeach
                                                </div>

                                            </div>



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- st-->

                <div class="fods-contaier">
                    <div class="right-banner-show">
                        <div class="right-banner-productOne">
                            <div class="prosuctOne-header">
                                <div class="prosuctOne-header-window">@lang('lang.LOADERS') <i class="fa fa-angle-right head-name-arrow" aria-hidden="true"></i></div>

                            </div>
                            <div class="prosuctOne-body">

                                <div class="panel panel-default">
                                    <div class="tab-content">

                                            <div id="kereakratesak"
                                                 class="tab-pane">

                                                <button id="go-prev" class="btn btn-dark go-prev-kereakratesak">
                                                    <i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                                                <button id="go-next" class="btn btn-dark go-next-kereakratesak">
                                                    <i class="fa fa-chevron-right" aria-hidden="true"></i></button>
                                                <div class="breakfast-slick-kereakratesak">

                                                    @foreach($dishe as $dishesproduction)
                                                        <div>
                                                            <div class="sc-product-item thumbnail">
                                                                <div class="myCheck">
                                                                    <input type="checkbox" onclick="unsel({{$dishesproduction->product_id}})" class="check-select" id="checl-select-{{$dishesproduction->product_id}}">
                                                                </div>
                                                                <div class="menuShow">
                                                                    <div class="form-group">
                                                                        <ul class="navbar-nav">
                                                                            <form class="addCartlist">
                                                                                <li class="nav-item margin-t-b-5">
                                                                                    <button onclick="sel({{$dishesproduction->product_id}})"
                                                                                            type="button"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$dishesproduction->product_id}}">
                                                                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                                                    </button>
                                                                                </li>
                                                                                <li class="nav-item btnsCon">
                                                                                    <a class="btn btn-success controlBtns"
                                                                                       href="{{route('RestaurantProduct',$dishesproduction->product_id)}}"><i
                                                                                            class="fa fa-search-plus"
                                                                                            aria-hidden="true"></i></a>
                                                                                    <input class="main-sc-cart-item-qty qty"
                                                                                           name="product_quantity" min="1"
                                                                                           value="1" type="number">
@auth
                                                                                        @if($dishesproduction->auth!=auth()->user()->id)
                                                                                    <button type="button"  class="btn btn-success controlBtns myfavorit color-{{$dishesproduction->product_id}}" data-favorit="{{$dishesproduction->product_id}}">
                                                                                        <i class="fa fa-heart-o" aria-hidden="true"></i></button>
                                                                                    @else
                                                                                            <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                                                <i class="fa fa-heart-o" style="color:red"  aria-hidden="true"></i></button>

                                                                                        @endif
                                                                                    @else
                                                                                        <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                                            <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                                                    @endauth
                                                                                </li>
                                                                            </form>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <img class="prodImg" data-name="product_image"
                                                                     src="{{asset('myproduct/'.$dishesproduction->img)}}"
                                                                     alt="...">
                                                                <div class="sc-added-item" data-removid="{{$dishesproduction->product_id}}" id='sc-added-item-{{$dishesproduction->product_id}}' onclick="unsel({{$dishesproduction->product_id}})"></div>
                                                                <div class="all-product-text">
                                                                    <!--{{$dishesproduction->product_id}} hamar-->
                                                                    <h6 class="myIm"
                                                                        data-name="product_name">  <a href="{{route('RestaurantProduct',$dishesproduction->product_id)}}">{{$dishesproduction->{'title_'.session('locale')} }}</a></h6>
                                                                        <span class="text-left mainDesk">{{mb_substr($dishesproduction->{'description_'.session('locale')}, 0, 100)}}</span>
                                                                             @if($dishesproduction->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($dishesproduction->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($dishesproduction->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($dishesproduction->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($dishesproduction->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif

                                                                    <p>
                                                                        <span
                                                                            class="price price-now pricechangetype">{{$dishesproduction->price_new}}</span>
                                                                            @if($dishesproduction->price_old>0)
                                                                        <span class="price-really pricechangetype">{{$dishesproduction->price_old}}</span>
                                                                        @endif
                                                                        <span class='currency'>@lang('lang.amd')</span>
                                                                        <input name="product_price"
                                                                               value="{{$dishesproduction->price_new}}"
                                                                               type="hidden"/>
                                                                        <input name="product_id"
                                                                               value="{{$dishesproduction->product_id}}"
                                                                               type="hidden"/>
                                                                    </p>
                                                                </div>
                                                            </div>


                                                        </div>
                                                    @endforeach

                                                </div>

                                            </div>



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                        <div class="adv">
                            <form action="{{ route('searchcolums')}}" method="post" class="search">
                                @csrf
                                <div class="search-form">
                                    <input class="form-control" type="hidden" name="search" placeholder=" @lang('lang.search')" aria-label="Search" value="Տորթ">
                                    <img
                                        src="{{asset('asset/IMAGE/b-2.jpeg')}}"
                                        alt="IMG" onclick="submit()" style="cursor:pointer" >
                                </div>
                            </form>


                        </div>
                    </div>
                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                        <div class="adv">
                            <form action="{{ route('searchcolums')}}" method="post" class="search">
                                @csrf
                                <div class="search-form">
                                    <input class="form-control" type="hidden" name="search" placeholder=" @lang('lang.search')" aria-label="Search" value="Գարեջուր">
                                    <img
                                        src="{{asset('asset/IMAGE/b-3.jpeg')}}"
                                        alt="IMG" onclick="submit()" style="cursor:pointer" >
                                </div>
                            </form>


                        </div>
                    </div>
                </div>
                {{--**********************--}}
                <div class="fods-contaier">
                    <div class="right-banner-show">
                        <div class="right-banner-productOne">
                            <div class="prosuctOne-header pr-all">
                                <div class="prosuctOne-header-window">Միրգ և Բանջարեղեն<i class="fa fa-angle-right head-name-arrow" aria-hidden="true"></i></div>
                            </div>

                            <div class="prosuctOne-body">
                                <div class="panel panel-default">
                                    <div class="tab-content">

                                            <div id="mrger" class="tab-pane active">
                                                <button id="go-prev" class="btn btn-dark go-prev-mrger"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                                                <button id="go-next" class="btn btn-dark go-next-mrger"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
                                                <div class="breakfast-slick-mrger">
                                                    @foreach($vegetable as $vegetablesproduction)
                                                        <div>
                                                            <div class="sc-product-item thumbnail">
                                                                <div class="myCheck">
                                                                        <input type="checkbox" onclick="unsel({{$vegetablesproduction->product_id}})" class="check-select" id="checl-select-{{$vegetablesproduction->product_id}}">
                                                                </div>
                                                                <div class="menuShow">
                                                                    <div class="form-group">
                                                                        <ul class="navbar-nav">
                                                                            <form class="addCartlist">
                                                                                <li class="nav-item margin-t-b-5">
                                                                                    <button type="button" onclick="sel({{$vegetablesproduction->product_id}})"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$vegetablesproduction->product_id}}">
                                                                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                                                    </button>
                                                                                </li>
                                                                                <li class="nav-item btnsCon">
                                                                                    <a class="btn btn-success controlBtns" href="{{route('RestaurantProduct',$vegetablesproduction->product_id)}}">
                                                                                        <i class="fa fa-search-plus" aria-hidden="true"></i>
                                                                                    </a>
                                                                                    <input class="main-sc-cart-item-qty qty" name="product_quantity" min="1" value="1" type="number">
                                                                                    @auth
                                                                                        @if($vegetablesproduction->auth!=auth()->user()->id)
                                                                                    <button type="button"  class="btn btn-success controlBtns myfavorit color-{{$vegetablesproduction->product_id}}" data-favorit="{{$vegetablesproduction->product_id}}">
                                                                                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                                                    </button>
                                                                                    @else
                                                                                            <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                                                <i class="fa fa-heart-o" style="color:red"  aria-hidden="true"></i></button>

                                                                                        @endif
                                                                                    @else
                                                                                        <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                                            <i class="fa fa-heart-o"  aria-hidden="true"></i></button>

                                                                                    @endauth
                                                                                </li>
                                                                            </form>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <img class="prodImg" data-name="product_image"
                                                                     src="{{asset('myproduct/'.$vegetablesproduction->img)}}"
                                                                     alt="...">
                                                                     <div class="sc-added-item"  data-removid="{{$vegetablesproduction->product_id}}"  id='sc-added-item-{{$vegetablesproduction->product_id}}' onclick="unsel({{$vegetablesproduction->product_id}})"></div>
                                                                <div class="all-product-text">
                                                                    <h6 class="myIm"
                                                                        data-name="product_name">
                                                                        <a href="{{route('RestaurantProduct',$vegetablesproduction->product_id)}}">{{$vegetablesproduction->{'title_'.session('locale')} }}</a></h6>
                                                                        <span class="text-left mainDesk">{{mb_substr($vegetablesproduction->{'description_'.session('locale')}, 0, 100)}}</span>
                                                                                   @if($vegetablesproduction->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($vegetablesproduction->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($vegetablesproduction->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($vegetablesproduction->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($vegetablesproduction->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                                                    <p>
                                                                        <span
                                                                            class="price price-now pricechangetype">{{$vegetablesproduction->price_new}}</span>
                                                                        {{--<span class="price-really">1900</span>--}}
                                                                        <span class="currency">@lang('lang.amd')</span>
                                                                        <input name="product_price"
                                                                               value="{{$vegetablesproduction->price_new}}"
                                                                               type="hidden"/>
                                                                        <input name="product_id"
                                                                               value="{{$vegetablesproduction->product_id}}"
                                                                               type="hidden"/>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>

                                            </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{--**********************--}}

                {{--**********************--}}
                <div class="fods-contaier">
                    <div class="right-banner-show">
                        <div class="right-banner-productOne">
                            <div class="prosuctOne-header pr-all">
                                <div class="prosuctOne-header-window">@lang('lang.DRINKS') <i class="fa fa-angle-right head-name-arrow" aria-hidden="true"></i></div>

                            </div>
                            <div class="prosuctOne-body">
                                <div class="panel panel-default">
                                    <div class="tab-content">

                                            <div id="drink"
                                                 class="tab-pane">
                                                <button id="go-prev"
                                                        class="btn btn-dark go-prev-drink">
                                                    <i class="fa fa-chevron-left" aria-hidden="true"></i></button>
                                                <button id="go-next"
                                                        class="btn btn-dark go-next-drink">
                                                    <i class="fa fa-chevron-right" aria-hidden="true"></i></button>
                                                <div
                                                    class="breakfast-slick-drink">
                                                    @foreach($drink as $Beerhousesproduction)
                                                        <div>
                                                            <div class="sc-product-item thumbnail">
                                                                <div class="myCheck">
                                                                        <input type="checkbox" onclick="unsel({{$Beerhousesproduction->product_id}})" class="check-select" id="checl-select-{{$Beerhousesproduction->product_id}}">
                                                                </div>
                                                                <div class="menuShow">
                                                                    <div class="form-group">
                                                                        <ul class="navbar-nav">
                                                                            <form class="addCartlist">
                                                                                <li class="nav-item margin-t-b-5">
                                                                                    <button type="button" onclick="sel({{$Beerhousesproduction->product_id}})"  class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$Beerhousesproduction->product_id}}">
                                                                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i> @lang('lang.Add to cart')
                                                                                    </button>
                                                                                </li>
                                                                                <li class="nav-item btnsCon">
                                                                                    <a class="btn btn-success controlBtns" href="{{route('RestaurantProduct',$Beerhousesproduction->product_id)}}">
                                                                                        <i class="fa fa-search-plus" aria-hidden="true"></i>
                                                                                    </a>
                                                                                    <input class="main-sc-cart-item-qty qty" name="product_quantity" min="1" value="1" type="number">
                                                                                  @auth
                                                                                        @if($Beerhousesproduction->auth!=auth()->user()->id)
                                                                                    <button type="button"  class="btn btn-success controlBtns myfavorit color-{{$Beerhousesproduction->product_id}}" data-favorit="{{$Beerhousesproduction->product_id}}">
                                                                                        <i class="fa fa-heart-o" aria-hidden="true"></i>
                                                                                    </button>
                                                                                    @else
                                                                                            <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('favoritesalls')}}'">
                                                                                                <i class="fa fa-heart-o" style="color:red"  aria-hidden="true"></i></button>

                                                                                        @endif
                                                                                    @else
                                                                                        <button type="button" class="btn btn-success controlBtns" onclick="location.href='{{route('login')}}'">
                                                                                            <i class="fa fa-heart-o"   aria-hidden="true"></i></button>

                                                                                    @endauth
                                                                                </li>
                                                                            </form>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <img class="prodImg" data-name="product_image"
                                                                     src="{{asset('myproduct/'.$Beerhousesproduction->img)}}"
                                                                     alt="...">
                                                                     <div class="sc-added-item" data-removid="{{$Beerhousesproduction->product_id}}"  id='sc-added-item-{{$Beerhousesproduction->product_id}}' onclick="unsel({{$Beerhousesproduction->product_id}})"></div>
                                                                <div class="all-product-text">
                                                                    <h6 class="myIm"
                                                                        data-name="product_name">
                                                                        <a href="{{route('RestaurantProduct',$Beerhousesproduction->product_id)}}">{{$Beerhousesproduction->{'title_'.session('locale')} }}</a></h6>
                                                                        <span class="text-left mainDesk">{{mb_substr($Beerhousesproduction->{'description_'.session('locale')}, 0, 100)}}</span>
                                                                                     @if($Beerhousesproduction->stars==1)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($Beerhousesproduction->stars==2)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($Beerhousesproduction->stars==3)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($Beerhousesproduction->stars==4)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star"></span>
                                        @elseif($Beerhousesproduction->stars==5)
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                            <span class="fa fa-star checked"></span>
                                        @endif
                                                                    <p>
                                                                        <span
                                                                            class="price price-now pricechangetype">{{$Beerhousesproduction->price_new}}</span>
                                                                            @if($Beerhousesproduction->price_old>0)
                                                                       <span class="price-really pricechangetype">{{$Beerhousesproduction->price_old}}</span>
                                                                       @endif
                                                                        <span class="currency">@lang('lang.amd')</span>
                                                                        <input name="product_price"
                                                                               value="{{$Beerhousesproduction->price_new}}"
                                                                               type="hidden"/>
                                                                        <input name="product_id"
                                                                               value="{{$Beerhousesproduction->product_id}}"
                                                                               type="hidden"/>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>

                                            </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{--**********************--}}

            </div>
        </div>
    </div>
    <div class="container-fluid hotDo">
        <h1 class="help-header" style="color:#fff;">Ինչպես պատվիրել</h1>
        <hr>

        <div class="row">
            <div class="col-3">
                <a href="">
                    <img class="help-image" src="{{asset('asset/IMAGE/img_1.png')}}" alt="Img">
                    <h4 class="text-center help-text" style="color:#fff;"><!--@lang('lang.Payment methods and terms')-->Ընտրեք ապրանքը</h4>
                </a>
            </div>
            <div class="col-3">
                <a href="">
                    <img class="help-image" src="{{asset('asset/IMAGE/img_2.png')}}" alt="Img">
                    <h4 class="text-center help-text" style="color:#fff;"><!--@lang('lang.Shipping rates and how to order')-->Ավելացրեք զամբյուղում</h4>
                </a>
            </div>
            <div class="col-3">
                <a href="">
                    <img class="help-image" src="{{asset('asset/IMAGE/img_3.png')}}" alt="Img">
                    <h4 class="text-center help-text" style="color:#fff;"><!--@lang('lang.Cancellation of the order')-->Նշեք ձեր հասցեն և հեռախոսահամարը</h4>
                </a>
            </div>
            <div class="col-3">
                <a href="">
                    <img class="help-image" src="{{asset('asset/IMAGE/img_4.png')}}" alt="Img">
                    <h4 class="text-center help-text" style="color:#fff;"><!--@lang('lang.Cancellation of the order')-->Ստացեք  պատվերը 30-60 րոպեի ընթացքում</h4>
                </a>
            </div>
        </div>
    </div>
    <div class="container" style="margin-top: 15px;">
        <div class="right-banner-productOne">
            <ul class="nav nav-tabs myTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link botTabs active" href="#profile" role="tab"
                       data-toggle="tab">@lang('lang.Best selling')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link botTabs" href="#buzz" role="tab" data-toggle="tab">@lang('lang.new')</a>
                </li>

            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane  in active" id="profile">
                    <div class="row">
                        @foreach($best->take(9) as $bestitem)
                            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-4">
                                <div class="all-product">
                                    <div class="all-product-image">
                                        <img src="{{asset('myproduct/'.$bestitem->img)}}" alt="IMG">
                                    </div>
                                    <div class="all-product-text b-p">
                                        <div class="b-p-show">
                                            <p>
                                                <button class="btn btn-link"><i class="fa fa-heart"
                                                                                aria-hidden="true"></i></button>
                                                @if($bestitem->stars==1)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($bestitem->stars==2)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($bestitem->stars==3)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($bestitem->stars==4)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($bestitem->stars==5)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                @endif
                                            </p>
                                            <p class="show-b-p-name">
                                               <a href="{{route('RestaurantProduct',$bestitem->product_id)}}">  {{$bestitem->{'title_'.session('locale')} }}</a>
                                            </p>
                                            <p>
                                                <button type="button" onclick="sel()" class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$bestitem->product_id}}">
                                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i> Ավելացնել
                                                </button>

                                            </p>
                                            <p>
                                                <a class="btn btn-success d-view controlBtns" href="{{route('RestaurantProduct',$bestitem->product_id)}}"><i class="fa fa-search-plus" aria-hidden="true"></i></a>

                                                <span class="price-now  pricechangetype">{{$bestitem->price_new}} </span>
                                                @if($bestitem->price_old>0)
                                                <span class="price-really pricechangetype">{{$bestitem->price_old}}</span>
                                                @endif
                                                <span class="currency">@lang('lang.amd')</span>
                                            </p>
                                        </div>
                                        <a href="{{route('RestaurantProduct',$bestitem->product_id)}}">{{$bestitem->{'title_'.session('locale')} }}</a>
                                        <p>
                                            <span class="price-now pricechangetype">{{$bestitem->price_new}} </span>
                                                @if($bestitem->price_old>0)
                                            <span class="price-really pricechangetype">{{$bestitem->price_old }}</span>
                                            @endif
                                            <span class="currency">@lang('lang.amd')</span>
                                        </p>
                                        <p>
                                            @if($bestitem->stars==1)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($bestitem->stars==2)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($bestitem->stars==3)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($bestitem->stars==4)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($bestitem->stars==5)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            @endif
                                        </p>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="buzz">
                    <div class="row">
                        @foreach($new->take(9) as $newitem)
                            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-4">
                                <div class="all-product">
                                    <div class="all-product-image">
                                        <img src="{{asset('myproduct/'.$newitem->img)}}" alt="IMG">
                                    </div>
                                    <div class="all-product-text b-p">
                                        <div class="b-p-show">
                                            <p>
                                                <button class="btn btn-link"><i class="fa fa-heart"
                                                                                aria-hidden="true"></i></button>
                                                @if($newitem->stars==1)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($newitem->stars==2)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($newitem->stars==3)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($newitem->stars==4)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>
                                                @elseif($newitem->stars==5)
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                @endif
                                            </p>
                                            <p class="show-b-p-name">
                                                {{$newitem->{'title_'.session('locale')} }}
                                            </p>
                                            <p>
                                                <button type="button" onclick="sel()" class="sc-add-to-cart btn btn-success btn-sm addCart addCarts" data-itemid="{{$newitem->product_id}}">
                                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i> Ավելացնել
                                                </button>
                                            </p>
                                            <p>
                                                <a class="btn btn-success d-view controlBtns" href="{{route('RestaurantProduct',$newitem->product_id)}}"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                                                <span class="price-now pricechangetype">{{$newitem->price_new}}</span>
                                                @if($newitem->price_old>0)
                                                <span class="price-really pricechangetype">{{$newitem->price_old}}</span>
                                                @endif
                                                <span class="currency">@lang('lang.amd')</span>
                                            </p>
                                        </div>
                                        <a href="{{route('RestaurantProduct',$newitem->product_id)}}">{{$newitem->{'title_'.session('locale')} }}</a>
                                        <p>
                                            <span class="price-now pricechangetype">{{$newitem->price_new}} </span>
                                            @if($newitem->price_old>0)
                                           <span class="price-really pricechangetype">{{$newitem->price_old}}</span>
                                           @endif
                                           <span class="currency">@lang('lang.amd')</span>
                                        </p>
                                        <p>
                                            @if($newitem->stars==1)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($newitem->stars==2)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($newitem->stars==3)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($newitem->stars==4)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                            @elseif($newitem->stars==5)
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            @endif
                                        </p>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="container" style="display: none;">
        <div class="bottom-slick-header">Our Partners</div>
        <div class="bottom-slick">
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_1.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_2.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_3.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_4.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_5.gif')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_6.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_7.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_8.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_9.png')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_10.gif')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_11.jpg')}}" alt="IMG">
                </div>
            </div>
            <div>
                <div class="part">
                    <img src="{{asset('asset/IMAGE/p_12.png')}}" alt="IMG">
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')

    <script async>
        $(document).ready(function () {

            $(".breakfast-slick-fastfood").slick({
                infinite: true,
                dots: false,
                centerMode: false,
                autoplay: true,
                autoplaySpeed: 3000,
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: $('.go-prev-fastfood'),
                nextArrow: $('.go-next-fastfood'),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });







            $(".breakfast-slick-mrger").slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 3000,
                dots: false,
                centerMode: false,
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: $('.go-prev-mrger'),
                nextArrow: $('.go-next-mrger'),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });

            /*---------------------------------------------------------------------------------------*/
            /*---------------------------------------------------------------------------------------*/

            $(".breakfast-slick-drink").slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 3000,
                dots: false,
                centerMode: false,
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: $('.go-prev-drink'),
                nextArrow: $('.go-next-drink'),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                    // You can unslick at a given breakpoint now by adding:
                    // settings: "unslick"
                    // instead of a settings object
                ]
            });


            $(".breakfast-slick-kereakratesak").slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 3000,
                dots: false,
                centerMode: false,
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: $('.go-prev-kereakratesak'),
                nextArrow: $('.go-next-kereakratesak'),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                    // You can unslick at a given breakpoint now by adding:
                    // settings: "unslick"
                    // instead of a settings object
                ]
            });




            $(".preferred").slick({
                infinite: true,
                autoplay: true,
                autoplaySpeed: 3000,
                dots: false,
                centerMode: false,
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: $('.go-prev-p'),
                nextArrow: $('.go-next-p'),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                            dots: false
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                    // You can unslick at a given breakpoint now by adding:
                    // settings: "unslick"
                    // instead of a settings object
                ]
            });
        });


    </script>
    <script>
        //avelacrel em

        $(window).load(function() {
            //cookie

            $.ajax({
                url: '{{url('visitscount/')}}',
                method: "GET",
                success: function (data) {
                }

            });

            var count=Number('{{\App\Models\VisitsCount::orderBy('id', 'DESC')->first()->visitscount}}') ;

            var l=count;
            var countorder=0;
            var margin=5;
            while(l!=0){
                countorder+=1;

                $('.quanityord').prepend('<span class="order-quanity" style="margin-right:'+margin+'px ">'+l%10+'</span>'
                );
                l=(l-l%10)/10;
            }
            while(countorder<4){

                $('.quanityord').prepend('<span class="order-quanity"style="margin-right:'+margin+'px ">'+0+'</span>');
                countorder+=1;


            }

        });
        //endcookie
        //verj
    </script>



@endsection
