Hi <strong>{{ $name }}</strong>,

<p><a href="{{ $activation_link }}">Click here</a> to activate your account.</p>
