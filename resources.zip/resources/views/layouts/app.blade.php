 <?php
$cart=\Cart::getContent();
?>
<?php
$updatesitems = \Cart::getContent()->all();
$selectitem=[];
foreach( $updatesitems as  $updatesitem) {
    $product = \App\Models\Product::rightJoin('langs', 'products.id', '=', 'langs.product_id')->where('product_id', $updatesitem)->first();
    array_push($selectitem,$product->product_id);

}

?>


<!doctype html>
    <html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="developer" content="Daniel Hambardzumyan">
        @yield('meta')
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
        <script src="{{asset('asset/JS/_JQuery/jquery.js')}}"></script>
        <script src="{{asset('asset/dist/js/ajax.jquery.min.js')}}" type="text/javascript" ></script>

        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

        <link rel="icon" href="{{asset('asset/IMAGE/f.png')}}">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{asset('asset/CSS/bootstrap.min.css')}}">
        <!--font awesome, icons and other libery-->
        <link rel="stylesheet" href="{{asset('asset/CSS/_icons/css/font-awesome.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('asset/CSS/_slick/slick.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('asset/CSS/_slick/slick-theme.css')}}">
        <!--our styles-->
        <link rel="stylesheet" href="{{asset('asset/dist/css/smart_cart.css')}}">
        <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
        <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
        <link rel="stylesheet" href="{{asset('asset/CSS/restourant.css')}}">
        <link rel="stylesheet" href="{{asset('asset/CSS/nouislider.css')}}" >
        <link rel="stylesheet" href="{{asset('asset/CSS/home.css')}}" >
        <link rel="stylesheet" href="{{asset('asset/CSS/index.css')}}">
        <link rel="stylesheet" href="{{asset('asset/CSS/fastFoodStyle.css')}}">
        @yield('css')

        <title>Fastfood.AM Delivery Service Vanadzor</title>


    </head>
    <body>
    @foreach($selectitem as $sitem)

        <style>
            #sc-added-item-<?php echo $sitem ?>{
                display: block;
            }

        </style>
     @endforeach

 @include('include.message')

        <div id="load">
        <div class="container text-center loading">
            <div class="spinner-border text-success"></div>
            <p class="text-center">Loading</p>
        </div>
    </div>

    <div id="write-number">

        <div id="call-back-window">
            <button type="button" class="close closeMyModal" data-modal="#write-number" onclick="closeMyModal(this.dataset.modal)">×</button>
            <h3 class="text-center">Զանգիր ինձ</h3>

            <form action="{{route('ContactAdmin.store')}}" method="post">
                @csrf
            <div class="cb-inps">
                <p class="text-center">
                <input type="text" name="title" class="form-control" placeholder="Ներկայացեք">
            </p>
            <p class="text-center">
                <input type="number" name="tel" class="form-control" placeholder="Հեռախոսահամար">
            </p>
            </div>
            <div class="cb-inps">
                <p class="text-center">
                <button class="btn btn-success" type="submit">Ուղարկել</button>
            </p>
            </div>
            </form>
        </div>
    </div>
    <!--header-start-->
    <header class="container" style="height: 42px;">
        <div class="container-fluid" style="display: flex;padding: 1px 0;">
            <div class="header-menu-list" style="padding: 7px 0;border-right: 1px solid #e6e6e6;margin: 2px 0;"><a href="{{route('index')}}"><img src="{{asset('asset/IMAGE/fast-corel x16.jpg')}}" alt="welocme_img" class="myMainLogo"></a></div>
            <div class="header-menu-list">
                <div class="dropdown">
                    <button class="dropbtn" style='font-size: 14px !important;padding-top: 9px;padding-right: 5px;'><img src="{{asset('asset/IMAGE/'.App()->getLocale().'.png')}}" align="Lang" style="width: 20px;height: 15px;"></button>
                    <div class="dropdown-content mydrop">
                        @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                            <a class="dropdown-item" hreflang="{{ $localeCode }}" href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">
                            <img style="width: 20px;" src="{{asset('asset/IMAGE/'.$properties['native'].'.png')}}" alt="image" title="{{ $properties['native'] }}">
                            {{ $properties['native'] }}</a>

                        @endforeach
                    </div>

                </div>
            </div>
            <div class="header-menu-list">

                <div class="dropdown">
                    @if(session('pricetype')=='USD')
                        <button class="dropbtn dropbtnprice " style='font-size: 14px;padding-top: 10px;padding-left: 5px;'><span></span>&nbsp;USD</button>
                        <div class="dropdown-content mydrop">
                            <a class="dropdown-item amdprice  " href="{{url('pricechange/AMD')}}" ><span></span>&nbsp;AMD</a>
                            <a class="dropdown-item usdprice active " href="{{url('pricechange/USD')}}"><span></span>&nbsp;USD</a>
                            <a class="dropdown-item rubprice "href="{{url('pricechange/RUB')}}" ><span></span>&nbsp;RUB</a>
                        </div>
                    @elseif(session('pricetype')=='RUB')
                        <button class="dropbtn dropbtnprice " style='font-size: 14px;padding-top: 10px;padding-left: 5px;'><span></span>&nbsp;RUB</button>
                        <div class="dropdown-content mydrop">
                            <a class="dropdown-item amdprice  " href="{{url('pricechange/AMD')}}" ><span></span>&nbsp;AMD</a>
                            <a class="dropdown-item usdprice  " href="{{url('pricechange/USD')}}"><span></span>&nbsp;USD</a>
                            <a class="dropdown-item rubprice active " href="{{url('pricechange/RUB')}}" ><span></span>&nbsp;RUB</a>
                        </div>
                    @else
                        <button class="dropbtn dropbtnprice " style='font-size: 14px;padding-top: 10px;padding-left: 5px;'><span></span>&nbsp;AMD</button>
                        <div class="dropdown-content mydrop">
                            <a class="dropdown-item amdprice  active" href="{{url('pricechange/AMD')}}" ><span></span>&nbsp;AMD</a>
                            <a class="dropdown-item usdprice  " href="{{url('pricechange/USD')}}"><span></span>&nbsp;USD</a>
                            <a class="dropdown-item rubprice  " href="{{url('pricechange/RUB')}}" ><span></span>&nbsp;RUB</a>
                        </div>
                        @endif
                </div>
            </div>
            <div class="header-welcome dropbtn">
                <i style="color: #92d625;" id="myColl" class="fa fa-phone" aria-hidden="true"> <span style="color: #7e7e7e;" class="c-b-text">@lang('lang.Call back')</span></i>
            </div>
            <div class="header-welcome dropbtn work-time-info">
                <p class="text-center" style="margin:0;font-family: 'Raleway', sans-serif;font-size: 14px;"><i style="color: #92d625;font-size: 18px;position: relative;top: 2px;" class="fa fa-clock-o" aria-hidden="true" style="font-size: larger;"></i> 10:00-22:00</p>
            </div>
            <div class="header-welcome dropbtn" style="padding-right: 5px;">
                <?php $fastfoodshop=\App\Models\Category::where('cat_id',19)->first() ?>
{{--                <a href="{{route('fastfoodshop',$fastfoodshop->cat_id)}}">--}}
                <a href="">
                    <p class="text-center ff-shopBtn"><i style="color: #E9294A;font-size: 15px !important;position: relative;font-size: larger;" class="fa fa-shopping-bag" aria-hidden="true"></i><span class="ff-shop">&nbsp;{{$fastfoodshop->cat_name_en }}</span></p>
                </a>
            </div>
            <div class="acount-control">
                @if (Route::has('login'))

                        @auth
                        <div class="dropbtn signUp" id="signIn">
                            <div id="signUpHover" onclick="location.href='{{route('home')}}'">
                                <div class="signUpHover"><i class="fa fa-home" aria-hidden="true"></i> </div>
                                <div class="signUpHover" id="sgIn">  @lang('lang.Mypage')</div>
                            </div>
                        </div>  <div class="dropbtn signUp" id="signIn">
                            @if(Auth()->user()->rolle=='user')
                            <div id="signUpHover" onclick="location.href='{{route('logoutuser')}}'">
                                @elseif(Auth()->user()->rolle=='company')
                                    <div id="signUpHover" onclick="location.href='{{route('logoutcompany')}}'">
                                @elseif(Auth()->user()->rolle=='admin')
                                            <div id="signUpHover" onclick="location.href='{{route('logout')}}'">
                                                @endif
                                <div class="signUpHover"><i class="fa fa-sign-out" aria-hidden="true"></i> </div>
                                <div class="signUpHover" id="sgIn">  Դուրս գալ</div>

                            </div>
                        </div>
                        <div class="callMe">
                            <span>+374 (93) 84-85-81</span>
                            <a id="collMeModal">@lang('lang.Order online')</a>
                        </div>
                        @else
                            <div class="dropbtn signUp" id="signIn" data-toggle="modal" data-target="#ll">
                                <div id="signUpHover">
                                    <div class="signUpHover"><i class="fa fa-user" aria-hidden="true"></i> </div>
                                    <div class="signUpHover" id="sgIn">  @lang('lang.logıns')</div>
                                </div>
                            </div>
                            @if (Route::has('register'))
                                <div class="dropbtn signUp" id="signUp" data-toggle="modal" data-target="#ModalRegistrationForm">
                                    <div id="signUpHover">
                                        <div class="signUpHover"><i class="fa fa-lock signIcon" aria-hidden="true"></i></div>
                                        <div class="signUpHover" id="sgUp"> @lang('lang.registeration')</div>
                                    </div>

                                </div>
                                <div class="callMe">
                                    <span>+374 (93) 84-85-81</span>
                                    <a id="collMeModal">@lang('lang.Order online')</a>
                                </div>
                            @endif
                        @endauth

                @endif


                </div>
                <div class="dropbtn signUp">
                    <div id="signUpHover">
                        @auth
                            <span class="countfav">
                            <?php  $favoritecount=\App\Models\Favorites::where('auth',\Illuminate\Support\Facades\Auth::user()->id)->get()->count()?>
                            <div class="signUpHover"><a href="{{route('favoritesalls')}}"><i class="fa fa-heart" aria-hidden="true"></i><span id="favQuantity">{{$favoritecount}}</span></a></div>
                           </span>
                            @else


                        <div class="signUpHover"><a href="{{route('favoritesalls')}}"><i class="fa fa-heart" aria-hidden="true"></i><span id="favQuantity">0</span></a></div>
                            @endauth
                    </div>
                </div>
           <!-- /.modal -->
            @if (Route::has('login'))

                @auth
                @else

                <div id="ll" class="modal fade">
                    <div class="modal-dialog login-dialog"  role="document" >
                        <div class="modal-content">
                            <div class="modal-body">
                                <button type="button" class="close" data-dismiss="modal">×</button>
                                <!-- LOGIN FORM -->
                                <div class="text-center" style="padding:20px 0">
                                    <div class="logo"><i class="fa fa-user logregIcon" aria-hidden="true"></i>&nbsp;@lang('lang.logıns')</div>

                                    <div class="login-form-1">
                                        <form id="login-form" class="text-left"  role="form" method="POST" action="{{ route('login') }}">
                                            {{ csrf_field() }}
                                            <div class="login-form-main-message" style="margin: 0;"></div>
                                            <div class="main-login-form">
                                                <div class="login-group">
                                                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                                        <label for="lg_username" class="sr-only">@lang('lang.email')</label>
                                                        <input type="text" class="form-control" id="lg_username" name="email" value="{{ old('email') }}" placeholder="@lang('lang.email')">
                                                    </div>
                                                    <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }} ">
                                                        <label for="lg_password" class="sr-only">@lang('lang.password')</label>
                                                        <input type="password" class="form-control" id="lg_password"  name="password"  placeholder="@lang('lang.password')">
                                                        @if ($errors->has('password'))
                                                            <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group login-group-checkbox">
                                                        <input type="checkbox" id="lg_remember" name="remember" {{ old('remember') ? 'checked' : '' }}>
                                                        <label for="lg_remember">@lang('lang.remember')</label>
                                                    </div>
                                                </div>
                                                </div>
                                                <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>


                                            <div class="etc-login-form">
                                                <p><a href="{{ route('password.request') }}">@lang('lang.ForgotYourPassword')</a></p>
                                                <p><a class="btn btn-link" id="regInSig" data-toggle="modal" data-target="#ModalRegistrationForm">@lang('lang.newaccount')</a></p>
                                            </div>
                                        </form> </div>
                                    <!-- end:Main Form -->
                                </div>
                            </div>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                    @if (Route::has('register'))
                        <div id="ModalRegistrationForm" class="modal fade">
                            <div class="modal-dialog reg-dialog" role="document" >
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <button type="button" class="close" data-dismiss="modal">×</button>
                                        <!-- REGISTRATION FORM -->
                                        <div class="text-center" style="padding:20px 0">
                                            <div class="logo"><i class="fa fa-lock logregIcon" aria-hidden="true"></i>&nbsp;@lang('lang.registeration')</div>
                                            <!-- Main Form -->
                                            <div class="login-form-1">
                                                <form id="register-form" class="text-left" method="POST" action="{{ route('register') }}">
                                                    @csrf
                                                    <div class="login-form-main-message" style="margin: 0"></div>
                                                    <div class="main-login-form">
                                                        <div class="login-group">
                                                            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                                                <label for="reg_username" class="sr-only">@lang('lang.name')</label>
                                                                <input type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="@lang('lang.name')" required>
                                                                @if($errors->has('name'))
                                                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                                                @endif
                                                            </div>
                                                            <div class="form-group{{ $errors->has('surname') ? ' has-error' : '' }}">
                                                                <label for="reg_fullname" class="sr-only">@lang('lang.surname')</label>
                                                                <input type="text" class="form-control" id="reg_fullname"  name="surname" value="{{ old('surname') }}" placeholder="@lang('lang.surname')">
                                                                @if ($errors->has('surname'))
                                                                    <span class="help-block">
                                        <strong>{{ $errors->first('surname') }}</strong>
                                    </span>
                                                                @endif
                                                            </div>
                                                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                                                <label for="reg_password" class="sr-only">@lang('lang.password')</label>
                                                                <input type="password" class="form-control" id="reg_password" name="password" placeholder="@lang('lang.password')" required>
                                                                @if ($errors->has('password'))
                                                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                                                @endif
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="reg_password_confirm" class="sr-only">@lang('lang.chekpassword')</label>
                                                                <input type="password" class="form-control" id="reg_password_confirm" name="password_confirmation" placeholder="@lang('lang.chekpassword')" required>
                                                            </div>

                                                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                                                <label for="reg_email" class="sr-only">@lang('lang.email')</label>
                                                                <input type="email" class="form-control" id="reg_email" name="email" value="{{ old('email') }}" placeholder="@lang('lang.email')" required>
                                                                @if($errors->has('email'))
                                                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                                                @endif
                                                            </div>

                                                            <div class="form-group{{ $errors->has('tel') ? ' has-error' : '' }}">

                                                                <input type="number" class="form-control" id="reg_email" name="tel" value="" placeholder="+374 00 000 000" required>
                                                                @if($errors->has('tel'))
                                                                    <span class="help-block">
                                        <strong>{{ $errors->first('tel') }}</strong>
                                    </span>
                                                                @endif
                                                            </div>

                                                            <div class="form-group{{ $errors->has('reg_gender') ? ' has-error' : '' }} login-group-checkbox">
                                                                <input type="radio" class="" name="user_type" id="male" value="company" placeholder="@lang('lang.company')" required>
                                                                <label for="male">@lang('lang.company')</label>

                                                                <input type="radio" class="" name="user_type" id="female" value="man" placeholder="@lang('lang.man')" required>
                                                                <label for="female">@lang('lang.man')</label>
                                                                @if($errors->has('reg_gender'))
                                                                    <span class="help-block">
                                        <strong>{{ $errors->first('reg_gender') }}</strong>
                                    </span>
                                                                @endif
                                                            </div>

                                                            <div class="form-group login-group-checkbox">
                                                                <input type="checkbox" class="" id="reg_agree" name="reg_agree" value="active">
                                                                <label class="lang_agree" for="reg_agree"><a href="#">@lang('lang.Iagree')</a></label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>


                                                    <div class="etc-login-form">
                                                        @if (Route::has('password.request'))
                                                            <a class="btn btn-link" href="{{ route('password.request') }}">
                                                                @lang('lang.ForgotYourPassword')
                                                            </a>
                                                            <a class="btn btn-link" id="sigInReg" data-toggle="modal" data-target="#ll"> Մուտք գործել</a>
                                                        @endif
                                                    </div>
                                                </form>
                                            </div>
                                            <!-- end:Main Form -->
                                        </div>
                                    </div>
                                </div><!-- /.modal-content -->
                            </div><!-- /.modal-dialog -->
                        </div>
                    @endif
                @endauth

            @endif

            </div>
        </div>
    </header>
     <div id="collMeWindow">

        <div id="call-me-window">
            <button type="button" class="close closeMyModal" data-modal="#collMeWindow" onclick="closeMyModal(this.dataset.modal)">×</button>
            <h5 class="text-left">Հետադարձ կապ</h5>
            <h6 class="text-left">Ինչով կարող ենք օգնել Ձեզ</h6>

            <form action="{{route('addstores')}}" method="post" enctype="multipart/form-data">
                @csrf

                <p class="text-left">
                    <label class="lebs" for='who'>Ներկայացեք<span style="color: red;">*</span></label>
                    <input id='who' type="text" name="title" class="form-control" value="{{old('title')}}">
                </p>

                <p class="text-left">
                    <label class="lebs" for="coms">Թողեք Ձեր մեկնաբանությունը<span style="color: red;">*</span></label>
                    <textarea id="coms" class="form-control" name="msg"> {{old('msg')}}</textarea>
                </p>

                <p class="text-left" style="margin: 0;">
                    <input onchange="chooseFile(this)" type="file" name="pdf" hidden id="upload_file" multiple="multiple">
                    <label class="attach_file" for="upload_file">Կցել ֆայլ</label>&nbsp;<span style="font-size: 10px;">( <i class="fa fa-angle-left" aria-hidden="true"></i> 2Մբ, .pdf .docx, .jpg)</span>
                    <ul id="file_info" class="navbar-nav">
                        <li class="nav-item" id="f_name">Անուն: <span id="f_name_value"></span></li>
                        <li class="nav-item" id="f_size">Չափսը <span id="f_size_value"></span></li>
                        <li class="nav-item" id="f_type">Տիպը <span id="f_type_value"></span></li>
                    </ul>
                </p>
                <p class="text-left">
                    <label class="lebs" for="telp">Հեռախոսահամար</label>
                    <input id="telp" type="number" name="tel" class="form-control" value="{{old('tel')}}">
                </p>
                <p class="text-left">
                    <input type="checkbox" name="chek" value="active" id="i_argree">
                    <label for="i_argree">Համաձայն եմ <a href="">օգտատիրոջ պայմաններին</a></label>
                </p>
                <p class="text-left" style="margin: 0">
                    <button class="btn btn-success" type="submit">Ուղարկել</button>
                </p>
            </form>
        </div>
    </div>
    <div class="mainMenu" style="top: 0 !important;margin-top: 5px;">
        <nav class="navbar navbar-expand-lg navbar-dark bg-orange" style="width: 100%;padding: 0;">
            <div class="container">
                <div class="row justify-content-xl-left" style="width: 100%;margin: 0;">
<!--es qani hatic qani hat uxarki-->
                    <?php $category=\App\Models\Category::where('chek','active')->offset(0)
                        ->limit(8)->get() ?>
                    <?php $category_open=\App\Models\Category::where('chek','active')->offset(5)
                        ->limit(25)->get() ?>
                    @foreach($category as $categories)
                        <div class="col col-sm col-md col-lg col-xl nav-item myNewMenu h-s myTopMen one-m">
                            <a class="nav-link text-center" href="{{route('Restaurantmarket',$categories->cat_id)}}">
                                <img src="{{asset('myitem/'.$categories->img)}}" alt="menu_image">
                                <p>{{$categories->{'cat_name_'.session('locale')} }}</p>
                            </a>
                        </div>
                    @endforeach


                        <br>
                        <!--hayko es texna-->

                    <div class="col col-sm col-md col-lg col-xl nav-item myNewMenu h-s  myTopMen">
                        <a class="nav-link text-center" data-toggle="collapse" data-target="#stil">
                            <img src="{{asset('myitem/2019/08/265201946402.png')}}" alt="menu_image">
                            <p>@lang('lang.learnmore')</p>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
    <div id="stil" class="collapse">
        <nav class="navbar navbar-expand-lg navbar-dark bg-orange" style="width: 100%;padding: 0;margin-top: 15px;">
            <div class="container">
                <div class="row justify-content-xl-left" style="width: 100%;margin: 0;">
                     @foreach($category_open as $categoriess)
                        <div class="col-3 col-sm-2 col-md-2 col-lg-2 col-xl-2 nav-item myNewMenu h-s myTopMen two-m">
                            <a class="nav-link text-center" href="{{route('Restaurantmarket',$categoriess->cat_id)}}">
                                <img src="{{asset('myitem/'.$categoriess->img)}}" alt="menu_image">
                                <p>{{$categoriess->{'cat_name_'.session('locale')} }}</p>
                            </a>
                        </div>
                    @endforeach

                </div>
            </div>
        </nav>
    </div>
    </div>


@yield('content')
    <div class="paralax"></div>
    <footer class="nb-footer">
        <div class="container-fluid" style="overflow: hidden;padding: 30px 0;">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <p>
                            <img class="img1" style="width: 100px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">
                            <img class="img2" style="width: 100px;" alt="IDram" title="IDram3" src ="{{asset('asset/IMAGE/id.png')}}">
                            <img class="img" style="width: 30px;" alt="Cash" title="Cash" src ="{{asset('asset/IMAGE/md.png')}}">
                        </p>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="social-media text-right">
                            <ul class="list-inline">
                                <li><a class="text-center" target="_blank" href="https://www.facebook.com/fastfoodhayastan/" title=""><i style="color: #0000d6;" class="fa fa-facebook"></i></a></li>
                                <li><a class="text-center" target="_blank" href="https://www.instagram.com/fastfood.am" title=""><i style="color: #904e15;" class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                <li><a class="text-center" target="_blank" href="https://www.youtube.com/channel/UC9e5vAxsPhmrv5t_ACpHu6g"><i style="color: #fff;" class="fa fa-youtube yt"></i></a></li>
                                <li><a class="text-center" target="_blank" href="#" title=""><i style="color: #a10707;" class="fa fa-google-plus"></i></a></li>
                                <li><a class="text-center" target="_blank" href="#" title=""><i style="color: purple;" class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                                <li><a class="text-center" target="_blank" href="#" title=""><i style="color: green" class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="footer-info-single">
                        <h2 class="title">ԸՆԿԵՐՈՒԹՅԱՆ ՄԱՍԻՆ</h2>
                        <hr style="background: #303030;">
                        <ul class="list-unstyled">

                            <li><a href="{{route('AboutUs')}}" title="">Մեր մասին</a></li>
                            <li><a href="{{route('PrivacyPolicy')}}" title="">Գաղտնիության քաղաքականություն</a></li>
                        </ul>
                    </div>
                </div>

                <div class="d-none d-sm-block col-md-3 col-sm-6">
                    <div class="footer-info-single">
                        <h2 class="title">ՍՊԱՍԱՐԿՈՒՄ</h2>
                        <hr style="background: #303030;">
                        <ul class="list-unstyled">
                            <li><a href="{{route('Jobs')}}" title="">Աշխատատեղեր</a></li>

                            <li><a href="{{route('CorporateClients')}}" title="">Կորպորատիվ հաճախորդներ</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="footer-info-single">
                        <h2 class="title">ՎՃԱՐՈՒՄ ԵՒ ԱՌԱՔՈՒՄ</h2>
                        <hr style="background: #303030;">
                        <ul class="list-unstyled">
                            <li><a href="{{route('DeliveryPrices')}}" title="">Առաքման գները և պայմանները</a></li>
                            <li><a href="{{route('Paymentmethods')}}" title="">Վճարման եղանակները և պայմանները</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="footer-info-single">
                        <h2 class="title">ԿՈՆՏԱԿՏԱՅԻՆ ՏՎՅԱԼՆԵՐ</h2>
                        <hr style="background: #303030;">
                        <ul class="list-unstyled">
                            <li><a title="" style="color: #fff;"><i class="fa fa-home" aria-hidden="true" style="color: #E95668;"></i>Տիգրան  Մեծի 18, Վանաձոր, Լոռի, Հայաստան</a></li>
                            <li><a title="" style="color: #25A3B1;"><i class="fa fa-envelope-o" aria-hidden="true" style="color: #E95668;"></i> info@fastfood.am</a></li>
                            <li><a title="" style="color: #fff;">
                                    +374 (95) 84-85-81
                                    <br>
                                    +374 (91) 84-85-81
                                </a>
                            </li>
                            <li><span style="color: #fff;">Copyright © 2019. fastfood.am</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="addcart">
    <div class="btn-show">
        <button style="color: #fff;" class="btn btn-secondary bask" data-toggle="modal" data-target="#myBasket"><i class="fa fa-shopping-cart" aria-hidden="true"> </i><span class="qanak"> {{$cart->count()}}</span></button>
    </div>
    <div class="modal" id="myBasket">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal body -->
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-shopping-basket cartLogo" aria-hidden="true"></i>&nbsp;Իմ պատվերը</h4>
                    <hr>
                    @include('include.cart')
                </div>
            </div>
        </div>
    </div>
    </div>
    <div id="goUp" class="text-center"><i class="fa fa-arrow-up" aria-hidden="true"></i></div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!--library-->


    <script src="{{asset('asset/JS/_Popper/popper.js')}}"></script>
    <script src="{{asset('asset/JS/bootstrap.min.js')}}"></script>
    <script src="{{asset('asset/JS/_Slick/slick.js')}}"></script>


    <!--our script-->
    <script src="{{asset('asset/JS/mySlick.js')}}"></script>
    <script src="{{asset('asset/JS/fastFoodScript.js')}}"></script>
    <script src="{{asset('asset/JS/nouislider.js')}}"></script>

    <script>
        $('.header-list').find('.nav-item:first').addClass('active');
        $('.panel').find('.tab-pane:first').addClass('active');
    </script>
    <script>

        var x = new Date($('.this-time').data("timin"));
        var x_1 = new Date($('.this-time-1').data("timin"));
        var x_2 = new Date($('.this-time-2').data("timin"));
        var y = new Date();
        var res = x-y;
        var res_1 = x_1-y;
        var res_2 = x_2-y;


        function hotTimer(y) {
            let d;
            let arr = [];
            let result = [];

            let ind = [];
            let dTime = document.getElementsByClassName('this-time');
            for(let i = 0; i < dTime.length; i++ ) {
                arr[i] = new Date(dTime[i].dataset.timin);
                result[i] =  arr[i] - y;
                ind[i] = dTime[i].dataset.indefikator;

            }

            for(let i = 0; i < dTime.length; i++ ) {
                let d = Math.floor(result[i] / (1000 * 60 * 60 * 24));
                let h = Math.floor((result[i] % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                let m = Math.floor((result[i] % (1000 * 60 * 60)) / (1000 * 60));
                let s = Math.floor((result[i] % (1000 * 60)) / 1000);



                if (d > 0 || h > 0 || m > 0 || s > 0) {
                    $('#' + ind[i]+'-s').html(s);
                    $('#' + ind[i]+'-m').html(m);
                    $('#' + ind[i]+'-h').html(h);
                    $('#' + ind[i]+'-d').html(d);

                    let timer = setInterval(function() {
                        if (s != 0) {
                            s--;
                            $('#' + ind[i]+'-s').html(s);
                            $('#' + ind[i]+'-m').html(m);
                            $('#' + ind[i]+'-h').html(h);
                            $('#' + ind[i]+'-d').html(d);
                        }
                        else {
                            s = 59;
                            if (m != 0) {
                                m -= 1;
                                $('#' + ind[i]+'-s').html(s);
                                $('#' + ind[i]+'-m').html(m);
                                $('#' + ind[i]+'-h').html(h);
                                $('#' + ind[i]+'-d').html(d);
                            }
                            else {
                                m = 59;
                                if (h != 0) {
                                    h -= 1;
                                    $('#' + ind[i]+'-s').html(s);
                                    $('#' + ind[i]+'-m').html(m);
                                    $('#' + ind[i]+'-h').html(h);
                                    $('#' + ind[i]+'-d').html(d);
                                }
                                else {
                                    h = 23
                                    if (d != 0) {
                                        d -= 1;
                                        $('#' + ind[i]+'-s').html(s);
                                        $('#' + ind[i]+'-m').html(m);
                                        $('#' + ind[i]+'-h').html(h);
                                        $('#' + ind[i]+'-d').html(d);
                                    }
                                    else {
                                        clearInterval(timer);
                                        alert("Alert!!! timer end");
                                    }
                                }
                            }
                        }
                    },1000);
                }
            }
        }
        hotTimer(y);
    </script>
    <script>
        $(document).ready(function () {

            $(window).scroll(function () {
                if ($('html,body').scrollTop() > 300) {
                    $('#goUp').css('bottom', '25px');
                }
                else  {
                    $('#goUp').css('bottom', '-55px');
                }
            });

            $('#goUp').click(function () {
                $('html,body').animate({scrollTop: '0'});
            });
        });

    </script>
    <script>
        var b=1;
        $('.sc-cart-item-qty').change(function () {
            b= $(this).val();
            let a = $(this).data('updateid');
           $.ajax({

                type:'get',
                url:'{{url('Cartupdate/')}}/'+a,

                data:{qty:b ,id: a},
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

                success:function(data){


                    $('.price_total').html(data['total']);
                    $('.shiptotal').html(data['shiptotal']);
                    $('.inputtotal').val(data['total']);
                    $('.inputprice').val(data['summedPrice']*data['qty']);

                    $('.summedPrice'+a).html('<span class="currency">AMDs</span>&nbsp;<span class="pricechangetype">'+data['summedPrice']*data['qty']+'</span>');

                    // $('.qanak').html(json['datacount']);
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')
                    $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                    $('.summedPrice'+a).html('<span class="currency">AMDs</span>&nbsp;<span class="pricechangetype">'+(Number(data['summedPrice']*data['qty'])/Number({{$currency->USD}})).toFixed(2)+'</span>');


                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('$');
                    }
                    @elseif(session('pricetype')=='RUB')

                    $('.summedPrice'+a).html('<span class="currency">AMDs</span>&nbsp;<span class="pricechangetype">'+(Number(data['summedPrice']*data['qty'])/Number({{$currency->RUB}})).toFixed(2)+'</span>');


                    $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('₽');
                    }
                    @endif

                }
            });

        });
    </script>
    <script>

        //avelacrel em naey classer em avelacrel sc-cart-removein jnjel em onclick@
        //avelacrel em
        $('.addproductdesc').on('click',function(){
            let a=$(this).parent().find('.editproductdescinput').val();
            $(this).parent().find('.descprod').show();
            $(this).parent().find('.descprod').val($('.descriptionproductdiv'+a).html());

        });
        $('.descprod').on('focusout',function(){
            $(this).hide();
            $(this).parent().find('.addproductdesc').hide();
            $(this).parent().find('.editproductdesc').show();
            $(this).parent().find('.removeproductdesc').show();

            let a=$(this).parent().find('.editproductdescinput').val();
            let b=$(this).parent().find('.descprod').val();
            $(this).parent().find('.descprod').hide();

            $.ajax({

                type:'get',
                url:'{{url('Cartupdatedesc/')}}/'+a,
                data:{description:b ,id: a},
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success:function(data){
                    if(data['description']==null){
                        $('.addproductdesc'+a).show();
                        $('.editproductdesc'+a).hide();
                        $('.removeproductdesc'+a).hide();
                        $('.descriptionproductdiv'+a).show();
                        $('.descriptionproductdiv'+a).html(data['description']);
                        $('.descriptionproductdiv'+a).hide();



                    }else{
                        $('.descriptionproductdiv'+a).show();
                        $('.descriptionproductdiv'+a).html(data['description']);
                    }



                }
            });




        });
        $('.editproductdesc').on('click',function(){
            let a=$(this).parent().find('.editproductdescinput').val();
            $(this).parent().find('.descprod').show();
            $(this).parent().find('.descprod').val($('.descriptionproductdiv'+a).html());
            $('.descriptionproductdiv'+a).hide();

        });

        $('.removeproductdesc').on('click',function(){

            $(this).parent().find('.addproductdesc').show();
            $(this).parent().find('.editproductdesc').hide();
            $(this).parent().find('.removeproductdesc').hide();
            $(this).parent().find('.descprod').hide();


            let a=$(this).parent().find('.editproductdescinput').val();
            let b='';
            $.ajax({
                type:'get',
                url:'{{url('Cartupdatedesc/')}}/'+a,
                data:{description:b ,id: a},
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success:function(data){
                    $('.descriptionproductdiv'+a).show();
                    $('.descriptionproductdiv'+a).html(data['description']);
                    $('.descriptionproductdiv'+a).hide();
                }
            });


        });

    </script>
    <script>
        $('.sc-cart-remove').on('click',function () {
            var a=$(this).data('removid');

            $.ajax({

                type:'get',
                url:'{{url('Cartremovedelete/')}}/'+a,
                data:a,
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success:function(data){
                    $('.remow'+a).fadeOut().remove();
                    $('.qanak').html(data['datacount']);
                    $('.inputtotal').val(data['total']);
                    $('.price_total').html(data['total']);
                    $('.shiptotal').html(data['shiptotal']);

                    for(var i=0;i< $('.marketpriceone').length;i++)

                        $('.marketpriceone').eq(i).html(data['marketpricearr'][i]);


                    $('#sc-added-item-'+data['productid']).css('display','none');
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')
                    $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                    for(var i=0;i< $('.marketpriceone').length;i++)

                        $('.marketpriceone').eq(i).html((Number(data['marketpricearr'][i])/Number({{$currency->USD}})).toFixed(2));

                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('$');
                    }
                            @elseif(session('pricetype')=='RUB')
                    for(var i=0;i< $('.marketpriceone').length;i++)

                        $('.marketpriceone').eq(i).html((Number(data['marketpricearr'][i])/Number({{$currency->RUB}})).toFixed(2));


                    $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('₽');
                    }
                    @endif

                }


            });
        })
    </script>
    <script>
        var b=1;
        $('.qty').change(function () {
            b= $(this).val();

        });
        $('.desc').change(function () {
            b= $(this).val();

        });

        $('.addCarts').click(function () {
            let a = $(this).data('itemid');

            //avelacrel em popoxakan
            let des = $('.descproduct'+a+'').val();

            $('#sc-added-item-'+a).show();
            $.ajax({

                type:'get',
                url:'{{url('cartadd/')}}/'+a,
                data:{ descriptionproduct: des ,qty:b ,id: a,},
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success:function(data){
if(data['inactive']=='inactive'){
    alert('Այս ռեստորանը փակ է');
                    $('#sc-added-item-'+a).hide();}
else{

    $('.addcart').html(data);
    $('#sc-added-item-'+a).show();
    b=1;
}



                }

            });

        });

    </script>
    <script>
        $('.sc-cart-clear').click(function () {
            $('.celeare').fadeOut();
            $.ajax({

                type:'get',
                url:'{{url('Cart/clear')}}',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success:function(data){



                    $('.price_total').html(data['total']);
                    $('.shiptotal').html(data['shiptotal']);
                    $('.qanak').html(data['count']);
                    $('.sc-added-item').css('display','none');
                    $('.inputtotal').val(data['total']);
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')
                    $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));


                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('$');
                    }
                    @elseif(session('pricetype')=='RUB')

                    $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('₽');
                    }
                    @endif


                }

            });
        })
    </script>
    <!--avelacrel em-->
    <script>
$('.addCartsRest').click(function () {
            b= $(this).parent().parent().find('.qty').val();

            let a = $(this).data('itemid');
            $.ajax({

                type:'get',
                url:'{{url('cartaddrest/')}}/'+a,

                data:{qty:b ,id: a},
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

                success:function(data){


                    $('.addcartrest').html(data);
                    $('#sc-added-item-'+a).css('display','block');


                }
            });

        });
    </script>
    <!--verj-->
    <script>
        $('#sigInReg').click(function() {
            $('#ModalRegistrationForm').modal('hide');
        });
        $('#regInSig').click(function() {
            $('#ll').modal('hide');
        });
    </script>

    <script>
        $(window).load(function() {
            for(let ind = 4; ind< $('.one-m').length; ind++ ) {
                $('.one-m').eq(ind).addClass('d-none').addClass('d-lg-block');
            }

            for(let ind = 0; ind< 3; ind++ ) {
                $('.two-m').eq(ind).addClass('d-block').addClass('d-lg-none');
            }

            $('.one-m').eq(4).addClass('d-sm-block');
        });





    </script>

    <script>
        $('.sc-added-item').click(function(){

            var a=$(this).data('removid');
            $.ajax({

                type:'get',
                url:'{{url('Cartremovedelete/')}}/'+a,
                data:a,
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                success:function(data){
                    $('.remow'+a).fadeOut().remove();
                    $('.qanak').html(data['datacount']);
                    $('.price_total').html(data['total']);
                    $('.shiptotal').html(data['shiptotal']);
                    $('.inputtotal').val(data['total']);
                    $('#sc-added-item-'+a).hide();
                    for(var i=0;i< $('.marketpriceone').length;i++)

                        $('.marketpriceone').eq(i).html(data['marketpricearr'][i]);
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')
                    $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                    for(var i=0;i< $('.marketpriceone').length;i++)

                        $('.marketpriceone').eq(i).html((Number(data['marketpricearr'][i])/Number({{$currency->USD}})).toFixed(2));

                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('$');
                    }
                            @elseif(session('pricetype')=='RUB')
                    for(var i=0;i< $('.marketpriceone').length;i++)

                        $('.marketpriceone').eq(i).html((Number(data['marketpricearr'][i])/Number({{$currency->RUB}})).toFixed(2));


                    $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('₽');
                    }
                    @endif
                }
            });

        })

        $('.sc-cart-checkout').click(function(){
            if( Number($('.inputtotal').val())<1000){
                alert('Պատվերի գումարը 1000 դրամից պակաս է');
            }
            else{
                $(this).attr('type','submit');

            }
        })



        $('#catid').change(function() {
            // get the class of the selected option
            var select_class = $("option:selected", this).attr("class");
            // clone all options from the pot select
            var countryprice='0';
            var countryid=$('#catid').val();
            if( $(this).val()>0)
            {
                $('#township').show();

                var $options = $('#secid > option.'+select_class).clone();
                // delete all of the options in the township select and append
                // the new options
                $('#township')
                    .find('option')
                    .remove()
                    .end()
                    .append($options);
                countryprice=$('#township').val();
                $('.marketpriceonediv').show();

                var countrysecid= $('#township').children("option:selected").data('itemsecid');

            }
            else{

                $('#township').hide();
                $('.marketpriceonediv').hide();

            }

            var arrmarketprice=[];
            for(var i=0;i<$('.marketpriceone').length;i++)
            {

                if(Number($('.marketpriceone').eq(i).text())>=0){

                    arrmarketprice.push($('.marketpriceone').eq(i).data('updateidpricea'));


                }
            }

            $.ajax({

                type:'get',
                url:'{{url('Cartupdateprice')}}',

                data:{countryprice:countryprice,arrmarketprice:arrmarketprice,countrysecid:countrysecid,countryid:countryid },
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

                success:function(data){


                    $('.price_total').html(data['total']);
                    $('.shiptotal').html(data['shiptotal']);
                    $('.inputtotal').val(data['total']);
                    for(var i=0;i<$('.marketpriceone').length;i++)
                    {

                        for(var j=0;j<data['arrmarketidchange'].length;j++){

                            if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                                $('.marketpriceone').eq(i).text(countryprice);


                            }
                        }

                    }
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')
                    $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                    for(var i=0;i<$('.marketpriceone').length;i++)
                    {

                        for(var j=0;j<data['arrmarketidchange'].length;j++){

                            if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                                $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->USD}})).toFixed(2));


                            }
                        }

                    }

                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('$');
                    }
                    @elseif(session('pricetype')=='RUB')

                    $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('₽');
                    }
                    for(var i=0;i<$('.marketpriceone').length;i++)
                    {

                        for(var j=0;j<data['arrmarketidchange'].length;j++){

                            if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                                $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->RUB}})).toFixed(2));


                            }
                        }

                    }
                    @endif

                }

            });


        });


        $('#township').change(function() {



            let countryprice=$('#township').val();
            var arrmarketprice=[];
            $('.marketpriceonediv').show();

            for(var i=0;i<$('.marketpriceone').length;i++)
            {                    @if(session('pricetype')=='USD')

            if(Number($('.marketpriceone').eq(i).text())>0.42)
                    @elseif(session('pricetype')=='RUB')
                if(Number($('.marketpriceone').eq(i).text())>27.78)
                @else                if(Number($('.marketpriceone').eq(i).text())>200)
                @endif

                {

                    arrmarketprice.push($('.marketpriceone').eq(i).data('updateidpricea'));


                }
            }
            var countrysecid= $('#township').children("option:selected").data('itemsecid');
            var countryid=$('#catid').val();


            $.ajax({

                type:'get',
                url:'{{url('Cartupdateprice')}}',

                data:{countryprice:countryprice,arrmarketprice:arrmarketprice ,countrysecid:countrysecid,countryid:countryid },
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},

                success:function(data){

                    $('.price_total').html(data['total']);
                    $('.shiptotal').html(data['shiptotal']);
                    $('.inputtotal').val(data['total']);
                    for(var i=0;i<$('.marketpriceone').length;i++)
                    {

                        for(var j=0;j<data['arrmarketidchange'].length;j++){

                            if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                                $('.marketpriceone').eq(i).text(countryprice);


                            }
                        }

                    }
                    <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')
                    $('.price_total').html((Number(data['total'])/Number({{$currency->USD}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->USD}})).toFixed(2));
                    for(var i=0;i<$('.marketpriceone').length;i++)
                    {

                        for(var j=0;j<data['arrmarketidchange'].length;j++){

                            if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                                $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->USD}})).toFixed(2));


                            }
                        }

                    }

                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('$');
                    }
                    @elseif(session('pricetype')=='RUB')

                    $('.price_total').html((Number(data['total'])/Number({{$currency->RUB}})).toFixed(2));
                    $('.shiptotal').html((Number(data['shiptotal'])/Number({{$currency->RUB}})).toFixed(2));
                    for(var i=0;i<($('.currency')).length;i++){
                        $('.currency').eq(i).html('₽');
                    }
                    for(var i=0;i<$('.marketpriceone').length;i++)
                    {

                        for(var j=0;j<data['arrmarketidchange'].length;j++){

                            if($('.marketpriceone').eq(i).data('updateidpricea')==data['arrmarketidchange'][j]){

                                $('.marketpriceone').eq(i).text((Number(countryprice)/Number({{$currency->RUB}})).toFixed(2));


                            }
                        }

                    }
                    @endif

                }
            });


        });


    </script>
    <script>
        $(document).ready(function () {
                <?php $currency=\App\Models\Currency::where('id','1')->first();?>
                    @if(session('pricetype')=='USD')

            for(var i=0;i<($('.pricechangetype')).length;i++){
                $('.pricechangetype').eq(i).html((Number($('.pricechangetype').eq(i).html())/Number({{$currency->USD}})).toFixed(2));
            }
            for(var i=0;i<($('.currency')).length;i++){
                $('.currency').eq(i).html('$');
            }
                    @elseif(session('pricetype')=='RUB')

            for(var i=0;i<($('.pricechangetype')).length;i++){
                $('.pricechangetype').eq(i).html((Number($('.pricechangetype').eq(i).html())/Number({{$currency->RUB}})).toFixed(2));
            }
            for(var i=0;i<($('.currency')).length;i++){
                $('.currency').eq(i).html('₽');
            }
            @endif




        });


    </script>



    @yield('js')
    <script>
        $('.myfavorit').click(function(){
            var a=$(this).data('favorit');
            $('.color-'+a).css('color','red');
            $.ajax({
                type:'get',
                url:'{{url('user/favorites')}}/'+a,
                data:'_token = <?php echo csrf_token() ?>',
                dataType : 'html',
                contentType: false,
                processData: false,

                success:function(data) {


                    $('.countfav').html(data);

                }
            });
        });

    </script>
    @yield('jss')
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-146804538-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-146804538-1');
    </script>
    <script>
        $('#changeaddress').click(function () {
            $('.addressdiv').hide();
            $('.changeaddressdiv').show();
            $(this).hide();


        })
    </script>
    <script>
        function hideAlert(e) {
            let wind = e.dataset.window;
            $(wind).fadeOut(200);
        }
    </script>
    </body>
</html>


