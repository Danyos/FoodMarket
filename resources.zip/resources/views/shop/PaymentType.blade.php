@extends('layouts.app')
@section('css')

@endsection
@section('content')
    <?php $total = \Cart::getSubTotal();
    $shiptotal = 0;
    if (\Illuminate\Support\Facades\Session::has('sessioncounrtyid')) {
        $updatesitems = \Cart::getContent()->all();
        $arrmarketid = [];
        $arrmarketprice = [];

        foreach ($updatesitems as $updatesitem) {
            $countequal = 0;

            $product = \App\Models\Product::rightJoin('langs', 'products.id', '=', 'langs.product_id')->where('product_id', $updatesitem)->first();
            for ($i = 0; $i < count($arrmarketid); $i++) {
                if ($product->food_market_id == intval($arrmarketid[$i])) {
                    $countequal += 1;
                }
            }
            if ($countequal == 0) {
                array_push($arrmarketid, $product->food_market_id);
                array_push($arrmarketprice, $updatesitem->attributes->marketprice);
            }
            //

        }

        for ($i = 0; $i < count($arrmarketprice); $i++) {
            $total += intval($arrmarketprice[$i]);
            $shiptotal += intval($arrmarketprice[$i]);
        }

    }

    ?>


    <div class="container-fluid finished-order">


        <div class="row">

            <div class="col-md-6 col-lg-6 col-xl-6">
                <div class="ord-window scrollbar">
                    <div class="fo-header ">
                        <h4 class="text-left">Վճարման և առաքման հասցեն</h4>
                        <hr>
                        <div class='changeaddressdiv' style="display: none;">
                            <form  action="{{route('chakecartForm')}}" >
                                <div class="checkout-section">
                                    <div id="chekout">
                                        <div style="display: flex">
                                            <div style="width: 49%;margin-right: auto;">
                                                <input style="border: 1px solid red;" type="text" id="name"
                                                       name="own_name" class="form-control myInpMar "
                                                       value="{{$request->own_name??old('own_name')}}" required="required" placeholder="Անուն Ազգանուն">
                                            </div>
                                            <div style="width: 49%;margin-left: auto;">
                                                <input type="text" id="mail" name="own_email"
                                                       class="form-control myInpMar" value="{{$request->own_email}}"
                                                       placeholder="Փոստ">
                                            </div>
                                        </div>
                                        <div style="display: flex">
                                            <div style="width: 49%;margin-right: auto;">
                                                <input style="border: 1px solid red;" type="number" id="phone"
                                                       name="own_phone" class="form-control myInpMar"
                                                       value="{{$request->own_phone}}" required="required" placeholder="Հեռ">
                                            </div>
                                            <div style="width: 49%;margin-left: auto;">
                                                <input style="border: 1px solid red!important;" type="text" id="street"
                                                       name="own_street" class="form-control myInpMar"
                                                       value="{{$request->own_street}}" required="required" placeholder="Փողոց">
                                            </div>
                                        </div>

                                        <?php $countriesprice = \App\Models\CountryPrice::get();?>

                                        <?php $currency=\App\Models\Currency::where('id','1')->first();?>

                                        <select class="form-control"  style="display: none"  id="secid" form="catform">

                                            @foreach($countriesprice as $countryprice)
                                                @if(\Illuminate\Support\Facades\Session::has('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                                                    @if(session('pricetype')=='USD')
                                                        <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                                    @elseif(session('pricetype')=='RUB')
                                                        <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                                    @else
                                                        <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class=" selectoption {{$countryprice->country_id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo intval($countryprice->price);?></option>

                                                    @endif
                                                @else
                                                    @if(session('pricetype')=='USD')

                                                        <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                                    @elseif(session('pricetype')=='RUB')
                                                        <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                                    @else
                                                        <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="{{$countryprice->country_id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo intval($countryprice->price);?></option>


                                                    @endif @endif

                                            @endforeach

                                        </select>
                                        <select style="border: 1px solid red;" class="form-control myInpMar"  id="catid" form="catform">


                                            <option value="0" class="nullcountry">Ընտրեք տարածաշրջանը</option>

                                            <?php $countries = \App\Models\Country::get();?>
                                            @foreach($countries as $country)
                                                @if(\Illuminate\Support\Facades\Session::has('sessioncounrtyid')&& session('sessioncounrtyid')==$country->id)

                                                    <option value="{{$country->id}}" class="{{$country->id}}" selected>{{$country->{'country_'.session('locale')} }} </option>
                                                @else
                                                    <option value="{{$country->id}}" class="{{$country->id}}" >{{$country->{'country_'.session('locale')} }} </option>
                                                @endif
                                            @endforeach

                                        </select>
                                        <?php $countriesprice = \App\Models\CountryPrice::where('country_id',session('sessioncounrtyid'))->get();?>
                                        @if(session('sessioncountrysecid')!=null)


                                            <select class="form-control" style="display: block" name="catid" id="township" form="catform">
                                                @else
                                                    <select class="form-control" style="display: none;border: 1px solid red;" name="catid" id="township" form="catform">
                                                        @endif


                                                        @foreach($countriesprice as $countryprice)
                                                            @if(session('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                                                                @if(session('pricetype')=='USD')
                                                                    <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                                                @elseif(session('pricetype')=='RUB')
                                                                    <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                                                @else
                                                                    <option data-itemsecid="{{$countryprice->id}}"  value="{{$countryprice->price}} " class="{{$countryprice->country_id}} {{$countryprice->id}}" selected>{{$countryprice->{'city_name_'.session('locale')} }}-{{$countryprice->price}}</option>

                                                                @endif
                                                            @else
                                                                @if(session('pricetype')=='USD')
                                                                    <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->USD),2);?></option>
                                                                @elseif(session('pricetype')=='RUB')
                                                                    <option data-itemsecid="{{$countryprice->id}}" value="{{$countryprice->price}} " class="  {{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-<?php echo round(intval($countryprice->price)/intval($currency->RUB),2);?></option>
                                                                @else
                                                                    <option data-itemsecid="{{$countryprice->id}}"  value="{{$countryprice->price}} " class="{{$countryprice->country_id}} {{$countryprice->id}}" >{{$countryprice->{'city_name_'.session('locale')} }}-{{$countryprice->price}}</option>

                                                                @endif
                                                            @endif

                                                        @endforeach


                                                    </select>




                                                    <div style="display: flex" class="myInpMar ">
                                                        <input class="form-control" type="text" id="home"
                                                               name="own_enter" value="{{$request->own_enter}}" placeholder="Մուտք">&nbsp;
                                                        <input class="form-control" type="text" id="home"
                                                               name="own_floor" value="{{$request->own_floor}}" placeholder="Հարկ">&nbsp;
                                                        <input class="form-control" style="border: 1px solid red;"
                                                               type="text" id="home" name="own_home"
                                                               value="{{$request->own_home}}" required="required" placeholder="Բնակարան">
                                                    </div>

                                    </div>
                                </div>

                                <input type="hidden" name="EDP_AMOUNT" value=" {{$total}}" class="inputtotal">

                                <input type="submit" value='Պահպանել հասցեն' class="btn btn-success">

                            </form>

                        </div>


                        <div class='addressdiv'>
                            <ul class="navbar-nav adr-list">
                                <li class="nav-item">{{$request->own_name}}</li>
                                <li class="nav-item">{{$request->own_email}}</li>
                                <li class="nav-item">{{$request->own_phone}}</li>

                                <?php $countries = \App\Models\Country::get();?>
                                @foreach($countries as $country)
                                    @if(\Illuminate\Support\Facades\Session::has('sessioncounrtyid')&& session('sessioncounrtyid')==$country->id)

                                        <li class="nav-item">{{$country->{'country_'.session('locale')} }} </li>
                                    @endif
                                @endforeach

                                <?php $countriesprice = \App\Models\CountryPrice::where('country_id', session('sessioncounrtyid'))->get();?>

                                @foreach($countriesprice as $countryprice)
                                    @if(session('sessioncountrysecid')&& session('sessioncountrysecid')==$countryprice->id)
                                        <li class="nav-item">{{$countryprice->{'city_name_'.session('locale')} }}</li>
                                    @endif
                                @endforeach


                                <li class="nav-item">{{$request->own_street}}/
                                    {{$request->own_floor}}/
                                    {{$request->own_enter}}/
                                    {{$request->own_home}}</li>
                            </ul>
                        </div>
                        <p class="text-left">
                            <button class="btn btn-success" id='changeaddress'>Փոխել հասցեն</button>
                        </p>
                    </div>

                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-6">
                <div class="ord-window">
                    <div class="fo-header">
                        <h4 class="text-left">Վճարում և առաքում</h4>
                        <hr>
                        <ul class="navbar-nav pay-type">
                            <li class="nav-item"><input id="pos" type="radio" name="payment-type"><label for="pos">POS
                                    տերմինալ (Շուտով)</label></li>
                            <li class="nav-item"><input id="back-cart" type="radio" name="payment-type"><label
                                    for="back-cart">Բանկային քարտ (Շուտով)</label></li>
                            <li class="nav-item"><input id="iDram" type="radio" name="payment-type"><label for="iDram">iDram
                                    (Շուտով)</label></li>
                            <li class="nav-item"><input id="before" type="radio" name="payment-type"><label
                                    for="before">Առաքումից հետո</label></li>
                        </ul>
                        <p class="text-left">
                            <input type="checkbox" id="agree" name="agree">
                            <label for="agree"><b>Ես կարդացել և ընդունում եմ <a href="">գաղտնոիության քաղաքականությունը</a></b></label>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="price-info">
            <h4 class="text-left">Վճարման ենթակա գումարը</h4>
            <hr>
            <div class="row">
                <div class="col-sm-7 col-md-8 col-lg-8 col-xl-8">
                    <table class="table">
                        <tr>
                            <td>Պատվերի գինը՝</td>
                            <td> <span class= " pricechangetype">{{\Cart::getSubTotal()}}</span><span class="currency">@lang('lang.amd')</span></td>
                        </tr>
                        <tr>
                            <td>Առաքման արժեքը</td>
                            <td><span class= " pricechangetype shiptotal">{{$shiptotal}}</span> <span class="currency">@lang('lang.amd')</span></td>
                        </tr>
                        <tr>
                            <td>Ընդհամենը</td>
                            <td><b><span ><span class= "price_total pricechangetype">{{$total}}</span></span></b><span class="currency">@lang('lang.amd')</span></td>
                        </tr>
                    </table>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">

                    <form id="CashPayment" action="{{route('CashPayment')}}" method="get">

                        <input type="hidden" name="own_name" value="{{$request->own_name}}">
                        <input type="hidden" name="own_email" value="{{$request->own_email}}">
                        <input type="hidden" name="own_floor" value="{{$request->own_floor}}">
                        <input type="hidden" name="own_home" value="{{$request->own_home}}">
                        <input type="hidden" name="own_enter" value="{{$request->own_enter}}">


                        <input type="hidden" name="own_street" value="{{$request->own_street}}">
                        <input type="hidden" name="own_phone" value="{{$request->own_phone}}">
                        <input type="hidden" name="total" value="{{$request->EDP_AMOUNT}}">


                        <p class="text-right">
                            <input type="button" class="btn btn-success paymentbutton" value="Ավարտել վճարումը">
                        </p>


                    </form>
                </div>
            </div>
        </div>
    </div>


    {{--    idram--}}

    {{--    <form action="https://web.idram.am/payment.aspx" method="POST">--}}
    {{--        <input type="hidden" name="EDP_LANGUAGE" value="{{app()->getLocale()}}">--}}
    {{--        <input type="hidden" name="EDP_REC_ACCOUNT" value="100000977">--}}
    {{--        <input type="hidden" name="EDP_DESCRIPTION" value="Order description">--}}
    {{--        <input type="hidden" name="EDP_AMOUNT" value="{{$request->EDP_AMOUNT}}">--}}
    {{--        <input type="hidden" name="EDP_BILL_NO" value="{{$request->EDP_BILL_NO}}">--}}
    {{--        <input type="hidden" name="EDP_PRECHECK" value="YES">--}}
    {{--        <button type="submit" ><img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="IDram" title="IDram" src ="{{asset('asset/IMAGE/id.png')}}"></button>--}}



    {{--        <img style="width: 80px;background: #6b6b6b;padding: 0 5px;border-radius: 5px;" alt="Visa or Arca" title="Visa or Arca" src ="{{asset('asset/IMAGE/va.png')}}">--}}


    {{--    </form>--}}
    {{--end idram--}}




@endsection
@section('jss')
    <script>

        $('.paymentbutton').click(function () {
           if($('#agree').prop("checked") == true && $('#before').is(':checked')){
               $(this).attr('type','submit');

           }
           else{
               alert('Վճարման եղանակը ընտրեք "Առաքումից հետո"տարբերակը և նշեք "Ես կարդացել և ընդունում եմ գաղտնոիության քաղաքականությունը" ' );
           }
        })
    </script>
    <script>
        $('#changeaddress').click(function () {
            $('.addressdiv').hide();
            $('.changeaddressdiv').show();
            $(this).hide();


        })
    </script>
    <script>
        function hideAlert(e) {
            let wind = e.dataset.window;
            $(wind).fadeOut(200);
        }
    </script>
@endsection
