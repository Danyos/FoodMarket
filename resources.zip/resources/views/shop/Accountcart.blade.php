<?php echo "Account" ?>


<h1>Ձեր գումարը</h1>

<form action="{{route('Cartsuccsess')}}" method="get">
    @csrf
    <label for="account"></label>
    <input type="number" id="account" name="account">
    <label for="day"></label>
    <input type="number" id="day" name="day">
    <label for="year"></label>
    <input type="number" id="year" name="year">

    <input type="submit" >
</form>
