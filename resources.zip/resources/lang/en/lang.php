<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'location' => 'Location',
    'chooseregion' => 'Choose region',
    'HOT PROPOSALS' => 'HOT PROPOSALS',

    'ALL FOR ARRIVES' => 'All for arrives',
    'new' => 'New',
    'Best selling' => 'Best selling',
    'forbusiness' => 'For business',
    'Messages' => 'Messages',
    'Vegetables and fruit' => 'Vegetables and fruit',
    'Favorites' => 'Favorites',
    'search' => 'Search',
    'Preferred Restaurants' => 'Preferred Restaurants',
    'Restaurants' => 'show more',
    'SWEATHER' => 'SWEATHER',
    'DRINKS' => 'DRINKS',
    'Helpcenter' => 'Help center',
    'LOADERS' => 'LOADERS',
    'Shipping rates and how to order' => 'Стоимость доставки и как сделать заказ',
    'Cancellation of the order' => 'Отмена заказа',
    'Shipping rates and how to order' => 'Shipping rates and how to order',
    'Cancellation of the order' => 'Cancellation of the order',
    'Call back' => 'Call back',
    'Order online' => 'Order online',
    'Add to cart' => 'Add to cart',
    'Payment methods and terms' => 'Payment methods and terms',
    'SearchApps' => 'Search Apps',
    'Mypage' => 'My page',
    'Myannouncement' => 'My announcement',
    'instants' => 'Instants',
    'announcements' => 'All announcements',
    'learnmore' => 'To learn more',
    'top' => 'Top Ads',
    'Advantage' => 'Advantage',
    'ads' => 'Announcements',
    'top active' => 'Active',
    'top inactive' => 'Inactiv',
    'registeration' => 'Check in',
    'logıns' => 'Sign in',
    'AddaStatement' => 'Add a Statement',
    'Add' => 'Add',
    'myannouncements' => 'My announcements',
    'topannouncements' => 'Top announcements',
    'Standardannouncements' => 'Standard announcements',
    'nothavetopads' => 'You do not have top announcements',
    'name' => 'name',
    'surname' => 'Surname',
    'password' => 'password',
    'chekpassword' => 'Confirm password',
    'email' => 'Mail address',
    'company' => 'Company',
    'man' => 'man',
    'Iagree' => 'I agree conditions',
    'close' => 'Close',
    'ForgotYourPassword' => 'Forgot Your Password',
    'newaccount' => 'Create a new account',
    'logout'=>'Logout',
    'change'=>'Change',
    'nothave' => 'You do not have to',
    'send'=>'Submit',
    'add'=>'Add',
    'addimg'=>'Add photos',
    'quickly'=>'Quickly',
    'remember' => 'Remember',

    'sort'=>'Sort',
    'search day'=>'Search for days',
    'To date'=>'To date',
    'day'=>'day',
    'week'=>'Week',
    'month'=>'Month',
    'type'=>'Type',
    'Nothing was found'=>'Nothing was found',
    'Posted by'=>'Posted by',
    'Show number'=>'Show numbers',
    'Yes'=>'Yes',
    'No'=>'No',
     'All announcements By sum'=>'All announcements By sum',
      'advertising information'=>'Advertising information',
      'This'=>'This',
      'Edit'=>'Edit',
'delete'=>'Delete',
'Top'=>'Top',
'tel'=>'Phone',
'country'=>'Country',
'title'=>'Title',
'description'=>'Description',
'price'=>'price',



 'city'=> 'City',
 'tumanyan'=>'Tumanyan',

];
