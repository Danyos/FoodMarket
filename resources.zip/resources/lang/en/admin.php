<?php
return[
    'alians'=>'Search Keyword:',
    'Use' => 'Use',
'Signup' => 'Sign up',
'Today' => 'Todays announcements',
 'Weekly'=>'Weekly announcements',
'Basic Part' => 'Todays Record',
'mainpart' => 'Basic Part',
'home' => 'Home',
'category' => 'Category',
'Sections' => 'Sections',
'Announcements' => 'Announcements',
'Registered' => 'Todays Registered Users',
'Allentries' => 'All entries',
'Staff' => 'Staff',
    'market'=>'Market',
  
    'users'=>'Users',
    'settings'=>'settings',

    'title_es'=>'Title Ispania',
    'title_en'=>'Title English',
    'title_am'=>'Title Armenia',
    'title_ru'=>'Title Russia',















];
