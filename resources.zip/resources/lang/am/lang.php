<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'location' => 'Որտեղից',
    'amd' => 'Դրամ',
    'chooseregion' => 'Ընտրել տարածաշրջոն',
    'HOT PROPOSALS' => 'Թեժ առաջարկներ',
    'ALL FOR ARRIVES' => 'Բոլոր առիթների համար',
    'Best selling' => 'Լավագույն վաճառք',
    'new' => 'Նոր',
    'Vegetables and fruit' => 'Բանջարեղեն եւ պտուղ',
    'Preferred Restaurants' => 'Նախընտրելի ռեստորաններ',
    'Restaurants' => 'Տեսնել ավելին',
    'LOADERS' => 'ԿԵՐԱԿՐԱՏԵՍԱԿՆԵՐ',
    'DRINKS' => 'ԽՄԻՉՔՆԵՐ',
    'SWEATHER' => 'ՔԱՂՑՐԱՎԵՆԻՔՆԵՐ',
    'Messages' => 'Հաղորդագրություններ',
    'Helpcenter' => 'Օգնություն կենտրոն',
    'Payment methods and terms' => 'Վճարման եղանակները եւ պայմանները',
    'Shipping rates and how to order' => 'Առաքման տոկոսադրույքները եւ ինչպես պատվիրել',
    'Cancellation of the order' => 'Պատվերի չեղարկում',
    'Call back' => 'Զանգիր ինձ',
    'Order online' => 'Հետադարձ կապ',
    'Favorites' => '  Հավանած ապրանքներ',
    'Add to cart' => 'Ավելացնել',
    'search' => 'Որոնել',
    'SearchApps' => 'Որոնել հավելվածներ',
    'Mypage' => 'Իմ էջ',
    'Myannouncement' => 'Իմ հայտարարությունը',
    'instants' => 'Շտապ',
    'announcements' => 'Բոլոր հայտարարությունները',
    'ads' => 'Հայտարարությունները',
    'learnmore' => 'Ավելին',
    'top' => 'Լավագույն գովազդը',
    'Advantage' => 'ԱՌԱՎԵԼՈՒԹՅՈՒՆ',
    'top active' => 'Ակտիվ',
    'top inactive' => 'ոչ ակտիվ',

    'logıns' => 'Մուտք',
    'registeration' => 'Գրանցվել',
  'AddaStatement' => 'Ավելացնել հայտարարություն',
  'Add' => 'Ավելացնել',
    'myannouncements' => 'Իմ հայտարարությունները',
    'topannouncements' => 'Թոփ հայտարարություներ',
    'Standardannouncements' => 'Ստանդարտ հայտարարություներ',
    'todayannouncements' => 'Այսօրվա հայտարարություները',
    'nothavetopads' => 'Դուք չունեք թոփ հայտարարություներ',
    'name' => 'Անունը',
    'surname' => 'Ազգանունը',
    'password' => 'Գաղտնաբառը',
    'chekpassword' => 'Կրկնել գաղտնաբառը',
    'email' => 'Էլ. հասցե',
    'company' => 'Ընկերություն',
    'man' => 'Անհատ',
    'Iagree' => 'Ես համաձայն եմ պայմաններին',
    'remember' => 'Հիշել',

    'close' => 'փակել',
    'ForgotYourPassword' => 'Մոռացել եք Ձեր գաղտնաբառը',

    'newaccount' => 'Ստեղծել նոր Էջ',

    'city'=> 'Տարածաշրջանը',
    'address'=> 'Հասցե',
    'tumanyan'=>'Թումանյան',

    'nothave' => 'Դուք չունեք',
    'logout'=>'Դուրս գալ',
    'change'=>'Փոփոխել',
    'send'=>'Ուղարկել',
    'addimg'=>'Ավելացնել Լուսանկար',

    'quickly'=>'Շտապ',

    'sort'=>'Տեսակավորել',
    'search day'=>'Որոնել օրով',
    'To date'=>'մինչեւ օրս',
    'day'=>'օրվա',
    'week'=>'շաբաթվա',
    'month'=>'ամսվա',
    'type'=>'Տեսակը',
    'Nothing was found'=>'Չի գտնվել ոչինչ',
    'Posted by'=>'Տեղադրվել է',
    'Show number'=>'Ցուցադրել համարները',
    'Yes'=>'Այո',
    'No'=>'Ոչ',
 'All announcements By sum'=>'Բոլոր հայտարարություները Գումարով',
 'advertising information'=>'գովազդային տեղեկատվություն',


'This'=>'Այս',
'Edit'=>'Փոփոխել',
'delete'=>'Ջնջել',
'Top'=>'Թոփ',
'tel'=>'Հեռ',
'country'=>'Քաղաք',
'title'=>'Վերնագիր',
'description'=>'Նկարագրություն',
'price'=>'Գին',



'vanadzor'=>'Վանաձոր',
'quality'=>'Քանակ',
'moreinformation'=>'Հավելյալ ինֆորմացիա',






];
