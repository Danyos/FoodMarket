 <?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Այս հավատարմագրերը չեն համապատասխանում',
    'throttle' => 'Չափազանց շատ մուտքի փորձեր: Կրկին փորձեք `վայրկյան վայրկյան:',
    'reset' => 'Վերականգնել գաղտնաբառը',

    'alert'=>'Երբ դուք լրացրեք ձեր գրանցված էլ-փոստի հասցեն, ձեզ կուղարկվեն ձեր գաղտնաբառը գաղտնաբառի վերականգնման վերաբերյալ հրահանգներ:',

];
