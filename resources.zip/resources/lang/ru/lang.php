<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'location' => 'Местоположение:',
    'chooseregion' => 'Выберите регион',
    'promocode' => 'Промокод',
    'HOT PROPOSALS' => 'ГОРЯЧИЕ ПРЕДЛОЖЕНИЯ',
    'ALL FOR ARRIVES' => 'Все для прибитя',
    'forbusiness' => 'Для бизнеса',
    'Messages' => 'Сообщения',
    'new' => 'новый',
    'Vegetables and fruit' => 'Овощи и фрукты',
    'Preferred Restaurants' => 'Предпочитаемые рестораны',
    'Restaurants' => 'показать еще',
    'Helpcenter'=>'Справочный центр',
    'Shipping rates and how to order' => 'Стоимость доставки и как сделать заказ',
    'Call back' => 'Перезвоните',
    'Order online' => 'Заказать онлайн',
    'LOADERS' => 'БЛЮДА',
    'SWEATHER' => 'конфеты',
    'DRINKS' => 'НАПИТКИ',
    'Add to cart' => 'Добавить в корзину',
    'Payment methods and terms' => 'Способы оплаты и условия',
    'Help center' => 'Help center',
    'Best selling' => 'Лучшие продажи',
    'Favorites' => 'Избранное',
    'search' => 'Поиск',
    'SearchApps' => 'Поиск приложений:',
    'Mypage' => 'Моя страница',
    'Myannouncement' => 'Мое объявление',
    'announcements' => 'Все объявления',
    'learnmore' => 'узнать больше ',
    'top' => 'Топ объявления',
    'top active' => 'активный',
    'ads' => 'Объявления',
    'Advantage' => 'преимущество',
    'top inactive' => 'Неактивный',
    'registeration' => 'Регистрация',
    'logıns' => 'войти в систему',
    'AddaStatement' => 'Добавить заявление',
    'myannouncements' => 'Мои объявления',
    'topannouncements' => 'Топ объявления',
    'nothavetopads' => 'У вас нет Топ объявления',
    'Standardannouncements' => 'Стандартные объявления',
    'name' => 'имя',
    'surname' => 'Фамилия',
    'password' => 'пароль',
    'chekpassword' => 'подтвердить пароль',
    'email' => 'Эл. адрес',
    'company' => 'Компания',
    'man' => 'челавек',
    'Iagree' => 'я согласен условиями',
    'Add' => 'добавлять',
    'close' => 'Закрыть',
    'ForgotYourPassword' => 'Забыли пароль',
    'newaccount' => 'создать новый аккаунт',

'logout'=>'Выход',
    'change'=>'Изминить',
    'nothave' => 'У вас нет',
    'send'=>'послать',
    'add'=>'добавлять',
    'addimg'=>'Добавить фото',
    'quickly'=>'срочно',
    'remember' => 'запомнить',


    'sort'=>'Сортировать',
    'search day'=>'Поиск по дням',
    'To date'=>'по дату ',
    'day'=>'день',
    'week'=>'На неделю',
    'month'=>'ежемесячно',
    'type'=>'тип',
    'Nothing was found'=>'Ничего не было найдено',
    'Posted by'=>'Автор',
    'Show number'=>'Показать номер',
    'Yes'=>'Да',
    'No'=>'Нет',
    'All announcements By sum'=>'Все объявления По сумме',
    'advertising information'=>'рекламная информация',
'delete'=>'удалять',
'Edit'=>'Редактировать',
'This'=>'это',
'Top'=>'верхний',
'tel'=>'Телефон',
'country'=>'Страна',
'title'=>'заглавие',
'description'=>'Описание',
'price'=>'цена',



 'city'=> 'Город',
 'tumanyan'=>'Туманян',
];
